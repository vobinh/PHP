-- Status:29:4851:MP_0:nathan_az:php:1.24.4::5.1.73:1:::utf8:EXTINFO
--
-- TABLE-INFO
-- TABLE|administrator|6|2612|2014-07-23 22:47:00|MyISAM
-- TABLE|answer|3757|191488|2014-08-13 21:45:15|MyISAM
-- TABLE|articles|3|6376|2014-07-23 22:47:09|MyISAM
-- TABLE|author|3|16384||InnoDB
-- TABLE|authorizenet_config|1|1100|2014-07-23 22:47:09|MyISAM
-- TABLE|banner|0|1024|2014-07-23 22:47:09|MyISAM
-- TABLE|category|18|16384||InnoDB
-- TABLE|data_template|8|4456|2014-07-23 22:47:10|MyISAM
-- TABLE|emails|0|1024|2014-07-23 22:47:10|MyISAM
-- TABLE|emails_detail|0|1024|2014-07-23 22:47:11|MyISAM
-- TABLE|languages|3|3168|2014-07-23 22:47:11|MyISAM
-- TABLE|mailing|0|1024|2014-07-23 22:47:11|MyISAM
-- TABLE|mailing_group|0|1024|2014-07-23 22:47:11|MyISAM
-- TABLE|member|0|1024|2014-07-23 22:53:37|MyISAM
-- TABLE|menu_categories|31|3648|2014-07-23 22:47:13|MyISAM
-- TABLE|menu_categories_description|55|3724|2014-07-23 22:47:15|MyISAM
-- TABLE|payment|0|1024|2014-07-23 22:53:13|MyISAM
-- TABLE|payments_method|1|2076|2014-07-23 22:47:17|MyISAM
-- TABLE|promotion|0|1024|2014-07-23 22:54:21|MyISAM
-- TABLE|questionnaires|941|196608||InnoDB
-- TABLE|sessions|5|7784|2014-08-13 21:45:16|MyISAM
-- TABLE|site|1|2264|2014-07-23 22:47:52|MyISAM
-- TABLE|temp_answer|0|1024|2014-07-23 22:47:52|MyISAM
-- TABLE|temp_questionnaires|0|1024|2014-07-23 22:47:52|MyISAM
-- TABLE|test|17|3176|2014-08-13 21:45:16|MyISAM
-- TABLE|testing|0|1024|2014-07-23 22:51:34|MyISAM
-- TABLE|testing_category|0|32768||InnoDB
-- TABLE|testing_detail|0|1024|2014-07-23 22:51:00|MyISAM
-- TABLE|version|1|2084|2014-07-23 22:49:40|MyISAM
-- EOF TABLE-INFO
--
-- Dump by MySQLDumper 1.24.4 (http://mysqldumper.net)
/*!40101 SET NAMES 'utf8' */;
SET FOREIGN_KEY_CHECKS=0;
-- Dump created: 2014-08-13 21:45

--
-- Create Table `administrator`
--

DROP TABLE IF EXISTS `administrator`;
CREATE TABLE `administrator` (
  `administrator_id` tinyint(11) NOT NULL AUTO_INCREMENT,
  `administrator_username` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `administrator_pass` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `administrator_fname` varchar(20) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `administrator_lname` varchar(255) DEFAULT NULL,
  `administrator_email` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `administrator_level` tinyint(1) NOT NULL DEFAULT '2' COMMENT '1 : super administrator | 2 : administrator 3: author',
  `administrator_status` tinyint(1) NOT NULL DEFAULT '0',
  `administrator_status_online` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1 : Online | 0 : Offline',
  `administrator_date_created` int(30) NOT NULL,
  `administrator_login_last` int(20) NOT NULL DEFAULT '0',
  `administrator_active_last` int(20) NOT NULL DEFAULT '0',
  `administrator_log_sessid` varchar(100) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`administrator_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Data for Table `administrator`
--

/*!40000 ALTER TABLE `administrator` DISABLE KEYS */;
INSERT INTO `administrator` (`administrator_id`,`administrator_username`,`administrator_pass`,`administrator_fname`,`administrator_lname`,`administrator_email`,`administrator_level`,`administrator_status`,`administrator_status_online`,`administrator_date_created`,`administrator_login_last`,`administrator_active_last`,`administrator_log_sessid`) VALUES ('1','admin','71f6d058afaa4e7ff673546f3cad8361','Trung Tran','','sonata@techknowledge.vn','1','1','0','0','0','0','');
INSERT INTO `administrator` (`administrator_id`,`administrator_username`,`administrator_pass`,`administrator_fname`,`administrator_lname`,`administrator_email`,`administrator_level`,`administrator_status`,`administrator_status_online`,`administrator_date_created`,`administrator_login_last`,`administrator_active_last`,`administrator_log_sessid`) VALUES ('4','admin1','d557fd4686821b5d8b927cdfe6e67d21','Ken','test','sonata.techknowledge@gmail.com','1','0','1','0','1383280441','0','opn5gkedvrn19anbgeh0195lq6');
INSERT INTO `administrator` (`administrator_id`,`administrator_username`,`administrator_pass`,`administrator_fname`,`administrator_lname`,`administrator_email`,`administrator_level`,`administrator_status`,`administrator_status_online`,`administrator_date_created`,`administrator_login_last`,`administrator_active_last`,`administrator_log_sessid`) VALUES ('5','xulanh00@gmail.com','e10adc3949ba59abbe56e057f20f883e','huy','le','xulanh00@gmail.com','3','0','0','1383549864','0','0','');
INSERT INTO `administrator` (`administrator_id`,`administrator_username`,`administrator_pass`,`administrator_fname`,`administrator_lname`,`administrator_email`,`administrator_level`,`administrator_status`,`administrator_status_online`,`administrator_date_created`,`administrator_login_last`,`administrator_active_last`,`administrator_log_sessid`) VALUES ('6','tikaylee@tikay.com','e10adc3949ba59abbe56e057f20f883e','Tikay','Lee','tikaylee@tikay.com','3','1','0','1385437365','0','0','');
INSERT INTO `administrator` (`administrator_id`,`administrator_username`,`administrator_pass`,`administrator_fname`,`administrator_lname`,`administrator_email`,`administrator_level`,`administrator_status`,`administrator_status_online`,`administrator_date_created`,`administrator_login_last`,`administrator_active_last`,`administrator_log_sessid`) VALUES ('8','Admin','5f4dcc3b5aa765d61d8327deb882cf99','kyung','yi','kyungyi.caleb@gmail.com','2','1','0','1385534775','0','0','');
INSERT INTO `administrator` (`administrator_id`,`administrator_username`,`administrator_pass`,`administrator_fname`,`administrator_lname`,`administrator_email`,`administrator_level`,`administrator_status`,`administrator_status_online`,`administrator_date_created`,`administrator_login_last`,`administrator_active_last`,`administrator_log_sessid`) VALUES ('9','tikay','220616d0958210f69ee8a8316a5cbd61','Tikay','Lee','tikaylee@gmail.com','2','1','0','1394836303','0','0',NULL);
/*!40000 ALTER TABLE `administrator` ENABLE KEYS */;


--
-- Create Table `answer`
--

DROP TABLE IF EXISTS `answer`;
CREATE TABLE `answer` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `questionnaires_uid` int(11) NOT NULL,
  `answer` text,
  `images` varchar(255) NOT NULL,
  `type` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=12663 DEFAULT CHARSET=utf8;

--
-- Data for Table `answer`
--

/*!40000 ALTER TABLE `answer` DISABLE KEYS */;
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7490','413','Cattail','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7489','413','Smartweed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7488','413','Spatterdock','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7487','412','Water Buttercup','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7486','412','Spatterdock','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7485','412','Cattail','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7483','411','Spatterdock','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7484','412','Bulrush','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7482','411','Water lily','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7481','411','Smartweed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7479','410','Spatterdock','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7480','411','American Pondweed','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7477','410','Water lily','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7478','410','Purple Loosestrife','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7476','410','American Lotus','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7475','409','Spatterdock','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7474','409','Bulrush','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7473','409','Water lily','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7472','409','Common Duckweed','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7471','408','Bulrush','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7470','408','Water lily','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7469','408','American Lotus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7468','408','Curlyleaf Pondweed','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7467','407','Bulrush','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7466','407','Water lily','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7465','407','American Lotus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7463','406','Cattail','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7464','407','Leafy Pondweed','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7462','406','Leafy Pondweed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7460','406','Brittle Naiad','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7461','406','Water lily','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7459','405','Purple Loosestrife','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7458','405','Spike rush','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7457','405','Spatterdock','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7456','405','Water Buttercup','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7455','404','Surface area divided by the average depth of the water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7454','404','Surface area  divided by total depth of the water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7453','404','Surface area multiplied by the total depth of the water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7452','404','Surface area multiplied by the average depth of the water','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7451','403','Sunlight and time of day','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7450','403','Turbidity of the body of water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7449','403','Square footage of the bank area.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7448','403','Water volume of the site','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7447','402','There are excessive photics in the photic zone','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7446','402','Clouds shade the site during application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7445','402','Insect larvae are treated in flowing water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7444','402','Vegetation is treated and decomposes resulting in oxygen depletion','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7443','401','Active ingredient','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7442','401','Environment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7441','401','Chemistry','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7440','401','Both Chemistry and Environment','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7439','400','The temperature of the body of water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7438','400','The availability of application devices','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7437','400','Cost of the herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7436','400','The present use of the body of water','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7435','399','Phosphorus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7434','399','Nitrogen','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7433','399','Carbon','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7432','399','Oxygen','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7430','398','Wind','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7431','398','Water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7429','398','Animals','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7427','397','Chemical','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7428','398','Humans','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7426','397','Mechanical','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7425','397','Preventative','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7424','397','Cultural','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7423','396','Temperature','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7422','396','Nutrients','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7420','396','Shallowness','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7421','396','Sunlight','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7419','395','Water lily','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7418','395','Duckweed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7416','395','Cattail','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7417','395','Pondwood','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7415','394','Cattail','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7414','394','Duckweed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7412','394','Water Lily','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7413','394','Pondwood','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7411','393','Cattail','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7410','393','Water lily','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7409','393','Pondwood','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7408','393','Duckweed','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7407','392','Cattail','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7406','392','Water lily','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7405','392','Duckweed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7404','392','Pondweed','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7403','391','The draining of a body of water to expose aquatic weeds','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7402','391','The biological process which oxidizes organic substances','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7401','391','The structure where equipment and pesticides are stored','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7400','391','The drainage area of any body of water','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7399','390','Sterile reproductive bodies in flowering plants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7353','379','6.6 gallons','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7354','379','2.2 gallons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7355','379','4.4 gallons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7356','379','8.8 gallons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7357','380','4 ppm','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7358','380','3 ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7359','380','5 ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7360','380','6 ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7361','381','16.2 pounds','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7362','381','12.2 pounds','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7363','381','14.2 pounds','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7364','381','18.2 pounds','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7365','382','2.5 ppm','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7366','382','4.5 ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7367','382','6.5 ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7368','382','8.5 ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7369','383','1.5 gallons','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7370','383','1 gallon','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7371','383','2 gallons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7372','383','2.5 gallons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7373','384','21.6 ounces','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7374','384','7.6 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7375','384','14.6 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7376','384','28.6 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7377','385','The correct identification of the target species','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7378','385','The selection of the application equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7379','385','The selection of the most potent pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7380','385','The correct calculation of the treatment area','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7381','386','Algae and flowering plants','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7382','386','Algae and non-flowering plants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7383','386','Flowering algae and non-flowering plants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7384','386','Algae and plants without roots','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7385','387','All or most of its vegetative tissue below the surface water','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7386','387','All or most of its vegetative tissue above the water surface','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7387','387','None of its vegetative tissues below the surface water surface','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7388','387','None of its vegetative tissue in the soil','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7389','388','Floats freely on or beneath the water surface','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7390','388','Is rooted in the bottom sediment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7391','388','Extends from underground rhizomes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7392','388','Is rooted to the bank','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7393','389','Extends above the surface and is rooted at depths of 2 to 3 feet','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7394','389','Grows with all of its vegetative tissue beneath the water surface','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7395','389','Floats freely on or beneath the water surface','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7396','389','Is rooted to the bank','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7397','390','Any substance injurious or lethal to plants','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7398','390','A pesticide used to kill or control fish populations','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7491','413','Bulrush','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7492','414','Purple Loosestrife','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7493','414','Leafy Pondweed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7494','414','Water Buttercup','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7495','414','Bulrush','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7496','415','American Water Willow','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7497','415','Brittle Naiad','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7498','415','American Lotus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7499','415','Bulrush','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7500','416','Smartweed','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7501','416','Bulrush','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7502','416','Water lily','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7503','416','American Pondweed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7504','417','Spike rush','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7505','417','Leafy Pondweed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7506','417','Purple Loosestrife','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7507','417','American Lotus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7508','418','Eurasian water milfoil','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7509','418','American Lotus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7510','418','Smartweed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7511','418','Water lily','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7512','419','1,000,000','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7513','419','980','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7514','419','1,000','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7515','419','100,000','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7516','420','7.5','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7517','420','8.0','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7518','420','10.0','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7519','420','12.5','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7520','421','5.4','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7521','421','13.5','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7522','421','54.0','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7523','421','135.0','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7524','422','Thermal stratification','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7525','422','Temperature zones','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7526','422','Photic layering','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7527','422','Eutrophication','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7528','423','Emergent','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7529','423','Exotic','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7530','423','Hygroscopic','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7531','423','Xerophytic','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7532','424','Flowing water','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7533','424','Static water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7534','424','Brackish water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7535','424','Salty water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7536','425','Is limited by the very few pesticides registered for this purpose','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7537','425','The most dangerous type of pest control for humans','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7538','425','Almost always requires the draining of bodies of water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7539','425','Is most often undertaken with aquatic weed control treatments','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7540','426','Duck potato','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7541','426','Naiad','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7542','426','Pondweeds','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7543','426','Hydrilla','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7544','427','Mixable and remains mixed','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7545','427','Reduces water to a low point','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7546','427','Usable on growing plants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7547','427','Improves the killing action of a pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7548','428','Zooplankton','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7549','428','Algae','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7550','428','Chara','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7551','428','Flowering aquatic weeds','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7552','429','All species of leeches may be harmful to humans','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7553','429','Leeches dwell in twig and leaf accumulations on lake bottoms','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7554','429','Reducing amounts of organic debris can help reduce leech populations','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7555','429','Leeches are the preferred prey of bluegills and bass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7556','430','Phosphorus','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7557','430','Iron','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7558','430','Potassium','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7559','430','Calcium','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7560','431','White sucker','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7561','431','Black crappie','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7562','431','Trout','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7563','431','Black bullhead','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7564','432','Biological control','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7565','432','Mechanical control','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7566','432','Chemical control','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7567','432','Submerged control','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7568','433','0.46','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7569','433','3.00','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7570','433','2.50','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7571','433','1.43','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7572','434','Has been relatively harmless since arriving','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7573','434','A mature female can produce up to 40,000 eggs in one season','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7574','434','The young, microscopic larvae are called veligers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7575','434','As larvae they must attach to a firm surface','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7576','435','Oxygen depletion','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7577','435','Fish-toxic pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7578','435','Uneven pesticide distribution','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7579','435','Increased water turbidity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7580','436','10.2 acre feet','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7581','436','5.1 acre feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7582','436','15.5 acre feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7583','436','20.2 acre feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7584','437','Reducing fish populations','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7585','437','Removing earthen dams','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7586','437','Lining the shore with rock','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7587','437','Reducing emergent plants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7588','438','20.25 lbs','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7589','438','6.00 lbs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7590','438','36.45 lbs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7591','438','40.50 lbs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7592','439','Bluegill','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7593','439','Worms','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7594','439','Slugs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7595','439','Muscles','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7596','440','None of these','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7597','440','Filamentous','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7598','440','Chara','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7599','440','Blue-green','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7600','441','Dilution','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7601','441','Soil absorption','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7602','441','Microbial degeneration','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7603','441','Photodegradation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7604','442','7','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7605','442','4','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7606','442','8','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7607','442','10','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7608','443','An undetermined','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7609','443','A very serious','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7610','443','An occasional','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7611','443','Not a','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7612','444','43,560','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7613','444','5,280','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7614','444','10,000','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7615','444','24,430','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7616','445','Are nontoxic to farm animals such as swine','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7617','445','Interfere with cellular respiration','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7618','445','Toxicity is influenced by species, size or water temperature','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7619','445','Will not harm aquatic vegetation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7620','446','Leeches','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7621','446','Mussels','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7622','446','Snails','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7623','446','Mosquito larvae','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7624','447','Triple rinsed, punctured and sent for disposal in a sanitary landfill','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7625','447','Placed in a sealed container and returned for recycling','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7626','447','Wrapped in newspaper and discarded in a sanitary landfill','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7627','447','Triple rinsed and re-used to hold only pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7628','448','4.840','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7629','448','1.279','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7630','448','0.0012','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7631','448','12.02','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7632','449','2.00','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7633','449','0.25','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7634','449','1.00','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7635','449','1.50','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7636','450','Biological pesticide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7637','450','Broad-spectrum pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7638','450','Ready-to-use pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7639','450','General aquatic pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7640','451','Bacillus Thuringiensis','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7641','451','Colloidal Fluoride','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7642','451','Orthobiotic Bacillus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7643','451','Aqueous Suspension','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7644','452','Hit only the target pest','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7645','452','Apply only to a labeled site','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7646','452','Operate equipment safely','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7647','452','Ensure active pest presence','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7648','453','Never use more pesticide than the label allows','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7649','453','Use higher than label rates of pesticides only when necessary','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7650','453','Never apply herbicides close to a body of water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7651','453','Use low pressure, low volume when applying pesticides on saturated soils','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7652','454','All of them','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7653','454','Mixing and loading','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7654','454','Equipment cleaning','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7655','454','Disposal of containers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7656','455','Elevated threshold','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7657','455','Biological control.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7658','455','Mechanical control.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7659','455','Improved Sanitation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7660','456','Delivering the proper amount of pesticide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7661','456','The rate of pesticide application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7662','456','The concentration of active ingredient','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7663','456','Carefully measuring mixture ingredients','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7664','457','Are much cheaper than liquids','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7665','457','Typically applied by spreader','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7666','457','Release from the water bottom','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7667','457','Ease of application uniformity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7668','458','Assists in cuticle penetration','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7669','458','Releases the active ingredient','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7670','458','Increases the pesticide’s toxicity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7671','458','Provides for enhanced persistence','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7672','459','Triple rinsed, punctured and sent for disposal in a sanitary landfill','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7673','459','Placed in a sealed container and returned for recycling','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7674','459','Wrapped in newspaper and discarded in a sanitary landfill','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7675','459','Triple rinsed and re-used to hold only pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7676','460','67.68','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7677','460','4.23','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7678','460','6.76','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7679','460','42.34','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7680','461','10.40','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7681','461','0.60','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7682','461','1.30','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7683','461','4.80','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7684','462','Contact herbicide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7685','462','Broad-spectrum pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7686','462','Highly toxic herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7687','462','Pre-emergent aquatic pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7688','463','Dipotassium endothall','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7689','463','Colloidal Fluoride','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7690','463','Dicarboxylic acid','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7691','463','7-oxabicyclo heptane','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7692','464','2.0','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7693','464','1.5','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7694','464','2.5','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7695','464','3.0','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7696','465','4.50','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7697','465','0.75','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7698','465','1.50','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7699','465','3.00','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7700','466','6.5','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7701','466','1.0','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7702','466','2.0','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7703','466','12.0','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7704','467','4581-204','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7705','467','4581-MI-1','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7706','467','5-C102S-04 HO','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7707','467','8004249300','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7708','468','The applicator is certified to use aquatic pesticides','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7709','468','The product is registered with the Arizona Department of Agriculture','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7710','468','Any additional required use permits have been acquired','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7711','468','The target pest is present in the treatment area','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7712','469','Making pond edges steeper','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7713','469','Baiting with avian toxicants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7714','469','Elimination of food sources','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7715','469','Elimination of nesting foliage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7716','470','Generally toxic to mammals and birds at labeled fish control rates','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7717','470','Impedes cellular respiration as the mode of action','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7718','470','Species, size and water temperature influence toxicity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7719','470','Generally non-toxic to aquatic vegetation at labeled fish control rates','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7720','471','Black Bullhead','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7721','471','Rainbow Trout','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7722','471','Speckled Crappie','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7723','471','White Sucker','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7724','472','Diptera','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7725','472','Anoplurae','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7726','472','Bioptera','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7727','472','Coleoptera','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7728','473','Small streams','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7729','473','Large streams','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7730','473','Large Lakes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7731','473','Small ponds','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7732','474','Bacteria','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7733','474','Virus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7734','474','Protozoa','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7735','474','Spirochaets','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9929','1064','Juvenile inhibitors','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9765','1023','Typically cause little or no irritation','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9766','1023','May be caused by rubbing eyes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9767','1023','May be caused by pouring granular formulations','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9768','1023','May be caused by applying pesticides in windy weather','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9769','1024','The chemical formulas and reactivity of pesticides','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9770','1024','Pesticide toxicity to humans','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9771','1024','Common pesticide exposure routes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9772','1024','The use of protective clothing and equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9773','1025','Hazards from use of the pesticide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9774','1025','The transportation of the pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9775','1025','The target pests for the pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9776','1025','The mixing of the pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9777','1026','Read the entire label','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9778','1026','Determine if the pesticide is restricted','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9779','1026','Identify the target pest','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9780','1026','Consider weather conditions','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9781','1027','Built to prevent run-off','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9782','1027','Placed on level ground','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9783','1027','Completely enclosed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9784','1027','Posted with an inventory of contents','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9785','1028','Mix only during the day','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9786','1028','Keep below head level','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9787','1028','Always wear eye protection','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9788','1028','Wash hands after exposure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9789','1029','Hazard','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9790','1029','Warning','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9791','1029','Danger','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9792','1029','Caution','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9793','1030','Minimum finished product concentration','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9794','1030','Endangered species information','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9795','1030','Allowable application site','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9796','1030','First Aid specifications for exposure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9797','1031','Contact','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9798','1031','Control','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9799','1031','Contain','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9800','1031','Clean-up','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9801','1032','Rubber','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9802','1032','Leather','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9803','1032','Plastic','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9804','1032','Vinyl','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9805','1033','Giving first aid to a person poisoned by the pesticide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9806','1033','Using the proper equipment to treat for a specific pest','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9807','1033','Application of the pesticide to get the best possible results','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9808','1033','Determining the proper application site for the pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9809','1034','Apply at label concentration two batches of 6 gallons','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9810','1034','Increase the concentration and use only 10 gallons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9811','1034','Decrease the application rate and use only 10 gallons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9812','1034','Double the concentration and apply only 6 gallons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9813','1035','At the conclusion of each day','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9814','1035','At the conclusion of each job','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9815','1035','When changing pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9816','1035','Prior to entry to customer homes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9817','1036','Using only general use pesticides','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9818','1036','Storing only pesticides currently used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9819','1036','Mixing only the amount that will be used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9820','1036','Purchasing only annually usable quantities','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9821','1037','Wearing  short pants','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9822','1037','Tucking shirt sleeves inside of gloves for overhead work','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9823','1037','Wearing of clothing made from tightly knit fabric','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9824','1037','Wearing a liquid-proof apron','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9825','1038','When permitted by the label','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9826','1038','When used as a service container','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9827','1038','When the pesticide is not restricted','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9828','1038','When the container has a tightly-sealing lid','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9829','1039','Movement of a pesticide off-target by wind','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9830','1039','Movement of a pesticide off-target by chemical reaction','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9831','1039','Movement of a pesticide off- target by run-off','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9832','1039','All of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9833','1040','Added to the tank for application','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9834','1040','Disposed of in a landfill','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9835','1040','Applied directly to the application site','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9836','1040','Stored for return to the manufacturer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9837','1041','decrease total pesticide usage','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9838','1041','make spill clean-up easier','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9839','1041','prevent pesticide run-off','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9840','1041','reduce pesticide waste','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9841','1042','Pesticidal residue','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9842','1042','Human exposure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9843','1042','Environmental contamination','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9844','1042','Pest resistance','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9845','1043','Bioaccumulation','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9846','1043','Acute contagion','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9847','1043','Asystal philopathy','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9848','1043','Eco-contamination','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9849','1044','The ambient temperature of the skin','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9850','1044','The condition of the skin','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9851','1044','The pesticide formulation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9852','1044','The pesticide carrier','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9853','1045','Applicator body weight','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9854','1045','Type of formulation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9855','1045','Length of exposure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9856','1045','Application technique','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9857','1046','Chronic','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9858','1046','Lethal','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9859','1046','Accumulated','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9860','1046','Residual','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9861','1047','Is more likely for high-concentration mixtures','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9862','1047','Can occur after application is complete','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9863','1047','Can result in increased pesticide volatilization','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9864','1047','Is a spill and must be cleaned up','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9865','1048','The safe use of multiple pesticides together','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9866','1048','The increased effectiveness of mixed pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9867','1048','The accumulated efficacy of re-treatments','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9868','1048','The chemical relatedness of pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9869','1049','Immediately flush the site with water to dilute the spill','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9870','1049','Read the label and MSDS for clean-up instructions','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9871','1049','Call the manufacturer for additional information, if needed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9872','1049','Use spill absorption material to contain the spill','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9873','1050','Refill smaller containers from bulk pesticide containers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9874','1050','Use pesticides packaged in soluble packaging','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9875','1050','Return empty containers for reconditioning','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9876','1050','Acquire only the amount of pesticide needed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9877','1051','Hyper activity','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9878','1051','Nauseated feeling','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9879','1051','Sudden dizziness','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9880','1051','Muscle Cramps','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9881','1052','Increased persistence over individual  pesticides','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9882','1052','Increased ineffectiveness on the target pest','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9883','1052','Increased toxicity to the applicator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9884','1052','Increased surface reactivity and marring','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9885','1053','Manufacturer’s corporate headquarters address','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9886','1053','Manufacturer’s world-wide web address','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9887','1053','Manufacturer’s emergency phone number','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9888','1053','Manufacturer’s state identification number','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9889','1054','May target unintended species','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9890','1054','Is limited to treatment for ants, roaches, and termites','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9891','1054','Is limited to interior placement','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9892','1054','Is always a part of an effective treatment regime','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9893','1055','On every pesticide label','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9894','1055','In place of the signal word on some labels','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9895','1055','Only on restricted-use pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9896','1055','On the door of a lawful pesticide storage shed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9897','1056','The rinsate is not from a restricted-use pesticide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9898','1056','If the rinsate is labeled for the future target site','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9899','1056','The finished mixture does not exceed label concentration','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9900','1056','The rinsate is used as a diluent for the same pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9901','1057','The size of the storage area','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9902','1057','A securely locking door','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9903','1057','Pesticide storage signage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9904','1057','Adequate ventilation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9905','1058','The applicator is sensitized','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9906','1058','The pesticide is highly toxic','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9907','1058','The  applicator is chronically injured','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9908','1059','Wettable powder','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9909','1059','Pesticidal dust','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9910','1059','Granular pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9911','1059','Emulsifiable concentrate','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9912','1060','The primary pesticide dispersant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9913','1060','Carcinogenic and highly toxic','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9914','1060','The same for a specific formulation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9915','1060','Identical to a pesticide surfactant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9916','1061','Suspension','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9917','1061','Solution','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9918','1061','Emulsion','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9919','1061','Solvent','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9920','1062','Approximately 6.0','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9921','1062','Above 8.0','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9922','1062','Between 6.5 and 7.5','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9923','1062','Below 5.0','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9924','1063','Granules often need moisture to start pesticidal action','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9925','1063','Dust formulations are always water soluble','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9926','1063','Dust formulations are more effective pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9927','1063','Granules are typically less toxic to pets','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9928','1064','Growth regulators','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9764','1022','Re-entering a treated area too soon','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7995','560','Nuisance','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7996','560','Disease','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7997','560','Parasitic','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7998','560','Environmental','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('7999','561','Mammals','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('8000','561','Fish','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('8001','561','Birds','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('8002','561','Insects','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('8003','562','Temporary control agents','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('8004','562','Cultural control agents','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('8005','562','Environmental control agents','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('8006','562','Biological control agents','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('8007','563','Use a synergist when available','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('8008','563','Increase the frequency of applications to ensure eradication','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('8009','563','Treat broadly and generally to maximize effectiveness','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('8010','563','Avoid the use of toxic pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9763','1022','Using an old filter, canister or cartridge','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9762','1022','Handling pesticides without proper protective equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9761','1022','Smoking','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9305','908','90','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9306','908','10','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9307','908','30','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9308','908','60','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9309','909','Read the label and labeling instructions','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9310','909','Calibrate you equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9311','909','Contact your pesticide dealer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9312','909','Select the application equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9313','910','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9314','910','The company','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9315','910','The Qualifying Party','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9316','910','The certified applicator and registered employees','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9317','911','Occurs over a long period of time','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9318','911','Occurs almost immediately','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9319','911','Refers to highly toxic pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9320','911','Refers to non-toxic pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9321','912','Chemical that controls the target pest and has toxicity','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9322','912','Primary material used to allow a pesticide to be dispersed effectively','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9323','912','Mixture of two or more liquids that are not soluble','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9324','912','None of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9325','913','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9326','913','Insecticide.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9327','913','Herbicide.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9328','913','Insect growth regulator. (IGR)','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9329','914','Aids humans, animals, or desirable plants in structures','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9330','914','Competes with humans, animals, or desirable plants for food','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9331','914','Spreads disease to humans, animals, or desirable plants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9332','914','A nuisance to humans affecting daily living or comfort','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9333','915','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9334','915','A basic knowledge of pests and pest problems','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9335','915','The ability to choose the right pesticide and equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9336','915','Knowledge of proper methods of application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9337','916','Pump','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9338','916','Tank','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9339','916','Hose','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9340','916','Agitator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9341','917','Never use more pesticide than the label allows','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9342','917','Use higher than label rates of pesticides only when necessary','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9343','917','Never apply herbicides to herbs close to a body of water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9344','917','Use low pressure, low volume when applying pesticides on saturated soils','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9345','918','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9346','918','Mixing and loading of pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9347','918','Equipment cleaning','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9348','918','Disposal of pesticides and containers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9349','919','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9350','919','Under dosing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9351','919','Overdosing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9352','919','Leftover mixture','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9353','920','1.2 ounces per gallon','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9354','920','0.12 ounces per gallon','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9355','920','12.0 ounces per gallon','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9356','920','12.1 ounces per gallon','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9357','921','3.6 ounces','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9358','921','0.36 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9359','921','36.0 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9360','921','36.3 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9361','922','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9362','922','Amount of finished product needed to complete the job','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9363','922','Rate of application for used equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9364','922','The size of the treatment site','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9365','923','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9366','923','Personal protective equipment as required by the product label for all pesticides on the service vehicle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9367','923','Measuring and pouring devices for the pesticides stored, transported or used on the service vehicle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9368','923','A specimen label and MSDS for each pesticide transported or stored on the service vehicle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9369','924','Keep the fill-hose above the level of the mixture in the tank','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9370','924','Use the garden hose at the customer’s house','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9371','924','Fill only at official pesticide mixing-loading stations','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9372','924','All of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9373','925','Accurate identification of the pest','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9374','925','Choosing the least expensive treatment method','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9375','925','Eradication of all outdoor pests','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9376','925','All of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9377','926','Elevated threshold','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9378','926','Host resistance','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9379','926','Cultural practices','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9380','926','Improved sanitation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9381','927','Product safety','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9382','927','Advanced first aid','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9383','927','Alternative treatments','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9384','927','Specific inert ingredients','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9385','928','Spill containment','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9386','928','Signs of exposure recovery','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9387','928','Advanced medical treatments','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9388','928','Alternative treatments','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9389','929','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9390','929','Before purchasing a pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9391','929','Before mixing a pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9392','929','Before disposing of a pesticide container','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9393','930','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9394','930','Front and face protection','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9395','930','Protection from dusts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9396','930','Protection from vapors','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9397','931','The pesticide’s active ingredient','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9398','931','Effectiveness of the pesticide application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9399','931','Possible effects on the environment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9400','931','Possible effects on the applicator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9401','932','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9402','932','Professional-use insecticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9403','932','Ready-to-use herbicides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9404','932','Insect growth regulators','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9405','933','One gallon','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9406','933','Two gallons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9407','933','Three gallons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9408','933','Five gallons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9409','934','Compressed-air sprayer','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9410','934','Power sprayer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9411','934','Granular applicator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9412','934','Insecticide duster','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9413','935','How acutely toxic the product is','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9414','935','The risk of chronic or allergic effects','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9415','935','The level of certification required for use','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9416','935','If the product is a restricted-use product','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9417','936','The only sites at which the pesticide may be used','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9418','936','The only application equipment that may be used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9419','936','The only pests for which the pesticide may be used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9420','936','A cost calculator for establishing treatment cost','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9421','937','The requirements for safe handling and storage of the pesticide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9422','937','If the pesticide can be used safely under the application conditions','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9423','937','If there are any restrictions on the re-sale of the pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9424','937','The quantity of active ingredient needed to eradicate the target pest','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9425','938','The quantity of active ingredient needed to eradicate the target pest','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9426','938','If the pesticide can be used safely under the application conditions','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9427','938','When to apply the pesticide for maximum effectiveness','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9428','938','Instructions for safe disposal of empty containers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9429','939','The phone number for local response in case of a spill','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9430','939','Requirements to ensure the security of the pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9431','939','Where and how to dispose of excess pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9432','939','How to decontaminate and dispose of the pesticide container','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9433','940','Pesticide mixture droplet or particle size','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9434','940','Wind speed of 5 miles per hour or greater at the airport','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9435','940','Low pressure, low volume application technique','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9436','940','The percentage of active ingredient in the pesticide mixture','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9437','941','Stop the source of the pesticide exposure as quickly as possible','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9438','941','Remove the victim even if exposing yourself to the pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9439','941','Induce vomiting and then replenish lost fluids','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9440','941','Slowly give diluting liquids even if the victim is unconscious','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9441','942','Will protect the body from contact with pesticides or residues','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9442','942','Will protect against all types of pesticides for prolonged exposure times','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9443','942','Is often just an ordinary shirt, pants and shoes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9444','942','Is quite expensive because of its technical nature','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9445','943','Neoprene boots','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9446','943','Long-sleeved shirt','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9447','943','Sunglasses','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9448','943','Leather gloves','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9449','944','Formulation','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9450','944','Price','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9451','944','Target pest','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9452','944','Active ingredient','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9453','945','Target pest identification','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9454','945','Health effects','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9455','945','Environmental hazard','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9456','945','Ultimate effectiveness','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9457','946','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9458','946','Wasted material','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9459','946','Adverse effects to property','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9460','946','Fines, as well as legal action charging the applicator with liability for damages.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9461','947','Easy to get an even distribution','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9462','947','Usually ready to use, with no mixing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9463','947','Effective in hard-to-reach places','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9464','947','Easily drift off target during application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9465','948','Persistence is of limited duration','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9466','948','Ready to use without mixing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9467','948','Entire area need not be covered','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9468','948','Can be attractive to children and pets','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9469','949','Not practical for very limited uses','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9470','949','Ready to use','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9471','949','Easily stored','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9472','949','Difficult to confine to target site','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9473','950','Does not cause unwanted harm to plants','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9474','950','Relatively easy to handle, transport, and store','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9475','950','Easily absorbed through skin of humans and animals','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9476','950','Insoluble in water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9477','951','Is not hazardous to non-target species','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9478','951','Drift hazard is low, and particles settle quickly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9479','951','May need to be incorporated into soil or planting medium','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9480','951','Ready to use, no mixing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9481','952','Non-clogging to equipment nozzles and screens','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9482','952','Inhalation hazard to applicator while mixing the concentrate','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9483','952','Require good and constant agitation in the spray tank','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9484','952','Abrasive to many pumps and nozzles, causing them to wear out quickly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9485','953','Provides exceptional persistence for continued control','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9486','953','A single treatment usually will kill most pests in a treated area','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9487','953','The target site must be enclosed to prevent the gas from escaping','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9488','953','Highly toxic to humans and all other living organisms','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9489','954','Too high a concentration','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9490','954','Poorly timed treatments','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9491','954','Pesticide runoff','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9492','954','Drift from target site','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9493','955','72 hours in advance of any pesticide application','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9494','955','24 hours in advance of any pesticide application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9495','955','36 hours in advance of any pesticide application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9496','955','48 hours in advance of any pesticide application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9497','956','The date and time of application','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9498','956','Name and certification number of applicator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9499','956','Completed signage for the schools to post','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9500','956','Record of most recent pesticide treatment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9501','957','The concentration of the pesticide required by the label','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9502','957','Signage for the school to post','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9503','957','Name of the applicator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9504','957','Record of most recent pesticide treatment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9505','958','6','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9506','958','12','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9507','958','18','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9508','958','24','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9509','959','Triple-rinse and recycle or dispose of','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9510','959','Do not reuse except as a service container','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9511','959','Do not contaminate application equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9512','959','Store in an open, well-ventilated area','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9513','960','Whether the product can be mixed with other often-used products','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9514','960','During which hours of the day the product should be applied','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9515','960','Basic entomology information for various target pests','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9516','960','An overview of toxicity and pesticide hazard to humans','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9517','961','Remains in the environment following an application','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9518','961','Is the site or target toward which control measures are being directed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9519','961','Is the immediate environment where pesticides are mixed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9520','961','Is the water beneath the earth’s surface in soil or rock','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9521','962','Dusts and wettable powders','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9522','962','Large spray droplets','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9523','962','Granules and pellets','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9524','962','All of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9525','963','Add the rinsate to your pesticide mixture','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9526','963','Dump the container with the rinsate in the trash','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9527','963','Return the container with the rinsate to the manufacturer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9528','963','Save the rinsate and dispose of it back at the storage area','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9529','964','Increases the risk of inhalation exposure','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9530','964','Ensures accurate delivery of the pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9531','964','Can be performed with lesser concentrations of pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9532','964','Is really no different than applying pesticides outdoors','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9533','965','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9534','965','Deliver the pesticide to the target','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9535','965','Avoid nontarget organisms and surfaces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9536','965','Operate equipment safely','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9537','966','Ensuring equipment delivers the proper amount of pesticide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9538','966','The application rate at which the applicator is applying pesticides.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9539','966','The percentage of active ingredient in the finished mixture','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9540','966','A measuring device filled with pesticide when the container is tilted','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9541','967','None of the answers are true','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9542','967','The pesticide is “ready to use”','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9543','967','When applying granular formulations','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9544','967','When applying dust formulations','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9545','968','The pest toward which control is directed','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9546','968','Any unwanted plant or animal','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9547','968','Assessing numbers of pests and the damage they cause','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9548','968','Natural predators of insect pests','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9549','969','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9550','969','Physical characteristics of the damage they cause','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9551','969','The development and biology of pests','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9552','969','If a pest is a continuous, sporadic, or a potential pest','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9553','970','The pest population at which control should be undertaken','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9554','970','The clearance level between the door and the doorjamb','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9555','970','The intent to reduce pest numbers to an acceptable level of harm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9556','970','The level of certification required for use of restricted-use pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9557','971','A survey of the situation','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9558','971','Identifying the pests','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9559','971','Developing a management strategy','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9560','971','A pesticide reduction strategy','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9561','972','Gives instructions on proper mixing and disposal','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9562','972','Is the law and must always be followed precisely','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9563','972','Explains alternatives to pesticide use','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9564','972','Should be read completely each time a pesticide is used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9565','973','Possible hazards from use of the pesticide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9566','973','Restricted status assigned by EPA','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9567','973','The pests which the pesticide may be effectively used for','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9568','973','Other printed materials attached to the pesticide container','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9569','974','Spilling the pesticide on clothes','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9570','974','Not washing hands before smoking','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9571','974','Accidentally applying pesticides to food.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9572','974','Mistaking the pesticide for food or drink.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9573','975','Breathing pesticide vapors during use','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9574','975','Not washing hands after handling pesticides or their containers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9575','975','Splashing or spraying pesticides on unprotected skin or eyes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9576','975','Wearing pesticide contaminated gloves and/or clothing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9577','976','Ingesting contaminated food or drink','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9578','976','Breathing vapors, dust or mist while handling the pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9579','976','Using a respirator that fits improperly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9580','976','Inhaling pesticide vapors present immediately after application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9581','977','Inhaling vapors or dust while handling pesticides','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9582','977','Applying pesticides in windy weather','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9583','977','Rubbing eyes with contaminated hands','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9584','977','Pouring granule formulations without protection','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9585','978','General or restricted use','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9586','978','Dangerous or poisonous','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9587','978','Organics or inorganics','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9588','978','Non of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9589','979','Snails','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9590','979','Vertebrates','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9591','979','Rodents','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9592','979','Arachnids','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9593','980','417.0 pounds','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9594','980','4.1 pounds','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9595','980','5.0 pounds','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9596','980','467.0 pounds','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9597','981','an organism that causes harm to people, plants, animals, or property','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9598','981','an organism that will control itself if no pesticide is used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9599','981','a non-mammal causing danger or harm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9600','981','any plant not controlled by natural means','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9601','982','Caution','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9602','982','Warning','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9603','982','Danger','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9604','982','Hazard','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9605','983','Distributor identification','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9606','983','Product name','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9607','983','Active ingredients','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9608','983','EPA registration number','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9609','984','Mites','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9610','984','Birds','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9611','984','Insects','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9612','984','Rodents','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9613','985','Potentiation','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9614','985','Resurgence','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9615','985','Inflation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9616','985','Compatibility','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9617','986','Accessible only during daylight hours','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9618','986','Secure from unauthorized entry','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9619','986','Posted with warning signs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9620','986','Secure from injury to domestic animals and birds','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9621','987','When the label requires it','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9622','987','When using any restricted use pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9623','987','When conditions for drift are present','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9624','987','When mixing and pouring pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9625','988','When the label requires it','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9626','988','When applying restricted use pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9627','988','When using dusts, fumigants and fine mists','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9628','988','When applying any pesticide in a confined space','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9629','989','Name of applicator','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9630','989','Time application is to occur','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9631','989','Concentration of application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9632','989','Pesticide use restrictions','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9633','990','Name of applicator','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9634','990','The brand name of pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9635','990','Date application is to occur','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9636','990','The pesticide label','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9637','991','Prior to opening the office for business','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9638','991','Within 10 days of opening for business','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9639','991','Within 30 days of opening for business','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9640','991','Within 60 days of opening for business','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9641','992','$100,000.00 for property damage and public liability, each separately','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9642','992','$50,000.00 for property damage and public liability, each separately','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9643','992','$300,000.00 for property damage and public liability, each separately','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9644','992','$500,000.00 for property damage and public liability, each separately','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9645','993','Register with the Commission within ten days of beginning work and become certified within ninety days','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9646','993','Register with the Commission within ten days of beginning work and become certified within thirty days','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9647','993','Register with the Commission prior to beginning work and become certified within ninety days','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9648','993','Register with the Commission within thirty days of beginning work and become certified within ninety days','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9649','994','A de minimis violation','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9650','994','Making fraudulent records','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9651','994','False advertising','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9652','994','Conviction for a felony','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9653','995','A business licensee','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9654','995','A qualifying party','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9655','995','A certified applicator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9656','995','A supervised employee','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9657','996','Three years','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9658','996','One year','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9659','996','Two years','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9660','996','Five years','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9661','997','Price','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9662','997','Name and address of customer and site of application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9663','997','Trade name or common name of the materials used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9664','997','Amount of finished product used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9665','998','Pesticide application equipment acquisitions','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9666','998','Pesticides purchased or otherwise acquired','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9667','998','Pesticide inventory, including disposal and lost pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9668','998','Pest control service vehicle acquisitions','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9669','999','Price','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9670','999','Written inspection reports','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9671','999','Insurance','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9672','999','Personnel actions for employees','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9673','1000','Three years of the alleged act or omission','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9674','1000','One year of the alleged act or omission','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9675','1000','Four years of the alleged act or omission','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9676','1000','Five years of the alleged act or omission','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9677','1001','20 days after it receives notice of the complaint from the Commission','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9678','1001','10 days after it receives notice of the complaint from the Commission','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9679','1001','30 days after it receives notice of the complaint from the Commission','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9680','1001','Within 60 days after it receives notice of the complaint from the Commission','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9681','1002','Cosmetics','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9682','1002','Tobacco','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9683','1002','Food','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9684','1002','Drugs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9685','1003','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9686','1003','Medically confirmed illness of a pet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9687','1003','Contamination of a water supply','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9688','1003','Contamination of the environment requiring evacuation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9689','1004','According to the product labeling and manufacturer’s recommendations','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9690','1004','As rapidly as possible','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9691','1004','By following the clean-up recommendations of local authorities','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9692','1004','After calling SPCC for instructions','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9693','1005','Absorbent material for spills of five gallons','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9694','1005','Potable water usable for washing and drinking','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9695','1005','A change of clothing in case of contamination','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9696','1005','Measuring devices for all on-vehicle pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9697','1006','Be kept under lock while in an unattended vehicle','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9698','1006','Be inventoried and recorded in business records','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9699','1006','Be re-sealed in the manufacturer’s or distributor’s original packaging','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9700','1006','Be usable as service containers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9701','1007','Accessible only during daylight hours','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9702','1007','Secure from unauthorized entry','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9703','1007','Posted with warning signs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9704','1007','Secure from injury to domestic animals and birds.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9705','1008','Provide hand and body washing facilities','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9706','1008','Have complete labeling for each pesticide stored therein','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9707','1008','Provide emergency anti-toxin in the first aid kit','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9708','1008','Have an emergency communications device','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9709','1009','Inhalation, dermal and oral','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9710','1009','Dermal, oral and ocular','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9711','1009','Poor sanitation, drift and rinsate','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9712','1009','Gloves, coveralls and canvas shoes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9713','1010','When the label requires it','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9714','1010','When using any restricted use pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9715','1010','When conditions for drift are present','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9716','1010','When mixing and pouring pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9717','1011','The life-stage of the exposed organism','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9718','1011','The type of pesticide involved','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9719','1011','The mode of action of the pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9720','1011','The surface condition where applied','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9721','1012','Phytotoxic to some plants','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9722','1012','Ease in mixing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9723','1012','Little agitation required','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9724','1012','Little or no visible residue','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9725','1013','Quickly dissolve in water','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9726','1013','Marginal phytotoxicity hazard','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9727','1013','Reduced skin and eye absorption risk','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9728','1013','Leaves residue on porous surfaces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9729','1014','Promote even surface distribution','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9730','1014','Are typically ready to use, with no mixing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9731','1014','Are effective in hard-to-reach places','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9732','1014','Easily drift off target during application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9733','1015','Negligible residual','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9734','1015','Toxicant is mixed with food','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9735','1015','Reduced application area','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9736','1015','May be a solid or liquid formulation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9737','1016','Consist of pure active ingredient','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9738','1016','Low drift hazard','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9739','1016','Easily clean-up if spilled','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9740','1016','Difficult to confine to target site or pest','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9741','1017','When the label requires it','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9742','1017','When applying restricted use pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9743','1017','When using dusts, fumigants and fine mists','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9744','1017','When applying any pesticide in a confined space','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9745','1018','Emulsifiable concentrates','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9746','1018','Wettable powders','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9747','1018','Dusts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9748','1018','Granules','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9749','1019','Excellent residual properties','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9750','1019','Arthropod toxicity via spiracles','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9751','1019','High human and animal toxicity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9752','1019','Excellent kill rate from single treatment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9753','1020','Absorption is more rapid than for inhalation','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9754','1020','May be caused by smoking','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9755','1020','May be caused by food storage near pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9756','1020','May be caused by residue on hands','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9757','1021','Eating contaminated food','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9758','1021','Failure to wash hands after handling pesticide containers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9759','1021','Laundering application clothing with other clothes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9760','1021','Splashing or spraying pesticides on applicator’s clothing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9930','1064','Life-cycle depressors','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9931','1064','Hormone disruptors','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9932','1065','Easily move to non-target sites','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9933','1065','Adhere to the surface where placed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9934','1065','Must be mixed with a wettable powder','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9935','1065','Effectively reach pest harborages','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9936','1066','Are pesticide particles encased in plastic','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9937','1066','Release pesticide rapidly after application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9938','1066','Act like a water soluble powder formulation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9939','1066','Have increased human and pet toxicity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9940','1067','To increase general effectiveness and safety','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9941','1067','To increase the pesticidal effect against vertebrate pests','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9942','1067','To equalize the disbursement of dust formulations','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9943','1067','To decrease adherence to treated plants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9944','1068','They disrupt an insect’s waxy coating','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9945','1068','They absorb ambient moisture','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9946','1068','They are easily inhaled by insects','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9947','1068','They increase pesticidal persistence','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9948','1069','Directly on indoor pests to provide quick knock-down','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9949','1069','For treatment of greenhouses and other confined spaces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9950','1069','As a flushing agent in the treatment of large outdoor areas','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9951','1069','To provide increased pesticidal residue effectiveness','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9952','1070','The United States Environmental Protection Agency','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9953','1070','The Arizona Structural Pest Control Commission','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9954','1070','The Arizona Department of Agriculture','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9955','1070','The Arizona Department of Environmental Quality','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9956','1071','Relate specifically to applications of restricted pesticides','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9957','1071','Must be created and maintained for each application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9958','1071','Must be available for inspection by SPCC and the public','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9959','1071','Provide evidence that a treatment was properly performed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9960','1072','Strict adherence to the label','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9961','1072','A licensed applicator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9962','1072','A qualifying party','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9963','1072','The least toxic method available','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9964','1073','1','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9965','1073','6','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9966','1073','9','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9967','1073','12','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9968','1074','20','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9969','1074','5','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9970','1074','10','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9971','1074','30','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9972','1075','1,000','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9973','1075','500','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9974','1075','250','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9975','1075','100','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9976','1076','June 30','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9977','1076','May 1','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9978','1076','May 30','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9979','1076','June 1','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9980','1077','Arizona Department of Agriculture','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9981','1077','National Pest Management Association','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9982','1077','Arizona Structural Pest Control Commission','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9983','1077','Arizona Department of Environmental Quality','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9984','1078','Heightened tolerance of pests','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9985','1078','Establishing a pest threshold','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9986','1078','Making mechanical repairs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9987','1078','Appropriate pesticide use','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9988','1079','Are best treated through improved mechanical controls','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9989','1079','Defy monitoring making IPM ineffective','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9990','1079','Comprise a nuisance requiring immediate pesticide treatment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9991','1079','May be treated effectively through improved sanitation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9992','1080','Sand, silt, and clay','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9993','1080','Fine, medium, and coarse','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9994','1080','Loam, compost, and mulch','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9995','1080','Arid, damp, and saturated','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9996','1081','Form a vital part of any pest management plan','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9997','1081','Often fail requiring synthetic pest management','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9998','1081','Refers to predation within the insect kingdom','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('9999','1081','Are best restored through using broad-spectrum pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10000','1082','Vaporization','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10001','1082','Absorption','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10002','1082','Efficacy','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10003','1082','Degradation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10004','1083','40 oz','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10005','1083','10 oz','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10006','1083','20 oz','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10007','1083','30 oz','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10008','1084','1.0%','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10009','1084','2.5%','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10010','1084','0.25%','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10011','1084','0.025%','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10012','1085','Reducing concentration','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10013','1085','Mixing the finished solution','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10014','1085','Final preparation for spraying','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10015','1085','The amount of active ingredient','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10016','1086','290 sq. ft.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10017','1086','170 sq. ft.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10018','1086','230 sq. ft.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10019','1086','1,000 sq. ft.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10020','1087','Minor fluctuations in site temperature','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10021','1087','A less than label rate application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10022','1087','A greater than label rate application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10023','1087','Inadequate agitation of the finished mix','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10024','1088','Feeding only on deteriorating, moldy grain','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10025','1088','Feeding only on cracked or broken grain','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10026','1088','Feeding only on whole, unbroken grain','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10027','1088','Feeding as larvae within whole-kernel grain','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10028','1089','6.5 lbs.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10029','1089','3.25 lbs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10030','1089','9.75 lbs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10031','1089','13.00 lbs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10032','1090','Mitigating environmental concerns','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10033','1090','Calculation of the Half Loss Time (HLT)','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10034','1090','Ensuring a successful fumigation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10035','1090','Reducing fumigant use','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10036','1091','The positive pressure activation sequence','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10037','1091','The type of seal required','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10038','1091','The type of fumigant to use','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10039','1091','The location of utilities shut-offs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10040','1092','Fumigant dosage estimator','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10041','1092','MSDS fact sheet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10042','1092','Medical response instructions','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10043','1092','Target pest identifier','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10044','1093','Ambient temperature','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10045','1093','Rate of breathing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10046','1093','Type of fumigant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10047','1093','Concentration of fumigant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10048','1094','Improperly fitted introduction tube','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10049','1094','Breathing vapors, dust or mist without appropriate protective equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10050','1094','Using a respirator that fits improperly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10051','1094','Re-entering a fumigated structure too soon','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10052','1095','Read the label','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10053','1095','Attend product-specific training','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10054','1095','Notify the Structural Pest Control Commission','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10055','1095','Post product MSDS on the placard','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10056','1096','Decrease','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10057','1096','Increase','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10058','1096','Fluctuate','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10059','1096','Remain unchanged','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10060','1097','Slabs','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10061','1097','Turf','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10062','1097','Grade changes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10063','1097','Vegetation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10064','1098','Draeger tube','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10065','1098','Halide detector','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10066','1098','Davis detector','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10067','1098','Interscan gas analyzer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10068','1099','Fumigant introduction and Aeration','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10069','1099','Fumigant introduction','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10070','1099','Aeration','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10071','1099','Maintain constant temperature','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10072','1100','Relative humidity','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10073','1100','Wind speed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10074','1100','Tarp condition','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10075','1100','Type of under-seal','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10076','1101','On each level of the structure','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10077','1101','In the air stream of a fan','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10078','1101','Between the tarps and the structure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10079','1101','In the attic of the structure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10080','1102','18,500 cu.ft.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10081','1102','1850 cu.ft','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10082','1102','9,250 cu.ft.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10083','1102','92,500 cu.ft.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10084','1103','Equal concentrations of fumigant throughout the fumigated structure','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10085','1103','Consistent air temperature throughout a structure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10086','1103','The average relative humidity throughout a structure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10087','1103','The rate of fumigant dispersion throughout a structure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10088','1104','Fumigation is conducted under vacuum conditions rather that at normal atmospheric pressure','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10089','1104','Fumigation is conducted at normal atmospheric pressures after the vacuuming is completed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10090','1104','Vacuum fumigations require additional monitoring','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10091','1104','Vault fumigations require less monitoring','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10092','1105','Interrupt the life cycles of insects','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10093','1105','Fumigate large quantities of commodities','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10094','1105','Reduce Half Loss Time to Quarter Loss Time','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10095','1105','Provide a residual pesticidal effect','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10096','1106','Cockroaches','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10097','1106','Stored food pests','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10098','1106','Rodents','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10099','1106','Termites','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10100','1107','Accurate identification of the pest','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10101','1107','Choosing the least invasive treatment method','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10102','1107','Eradication of all outdoor pests','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10103','1107','Customer Education','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10104','1108','8,000 cubic feet.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10105','1108','70 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10106','1108','4000 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10107','1108','80,000 cubic feet.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10108','1109','Pocket Gopher','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10109','1109','Ground Squirrel','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10110','1109','Chipmunk','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10111','1109','Packrat','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10112','1110','Indian Meal Moth','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10113','1110','Mediterranean Flour Moth','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10114','1110','Webbing Clothes Moth','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10115','1110','Wool Moth','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10116','1111','Drywood Termite damage','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10117','1111','Old House Borer damage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10118','1111','Long-Horned Beetle damage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10119','1111','Powderpost Beetle damage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10120','1112','Packrat','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10121','1112','Deer Mouse','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10122','1112','House Mouse','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10123','1112','Chipmunk','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10124','1113','Powderpost Beetle damage','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10125','1113','Old House Borer damage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10126','1113','Drywood Termite damage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10127','1113','Long-Horned Beetle damage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10128','1114','Ground Squirrel','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10129','1114','Deer Mouse','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10130','1114','Gopher','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10131','1114','Chipmunk','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10132','1115','Kangaroo Rat','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10133','1115','Deer Mouse','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10134','1115','Packrat','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10135','1115','Chipmunk','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10136','1116','Red Flour Beetle','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10137','1116','Darkling Beetle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10138','1116','Cigarette Beetle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10139','1116','Black Carpet Beetle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10140','1117','Mediterranean Flour Moth','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10141','1117','Indian Meal Moth','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10142','1117','Webbing Clothes Moth','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10143','1117','Wool Moth','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10144','1118','Drywood Termite fecal pellets and frass','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10145','1118','Formosan Termite fecal pellets and frass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10146','1118','Dampwood Termite fecal pellets and frass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10147','1118','Subterranean Termite fecal pellets and frass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10148','1119','Carpenter Ant frass','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10149','1119','Harvester Bee frass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10150','1119','Sugar Ant frass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10151','1119','Long-Horned Beetle frass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10152','1120','Black Carpet Beetle and larva','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10153','1120','Darkling Beetle and larva','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10154','1120','Powderpost Beetle and larva','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10155','1120','Old House Borer and larva','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10156','1121','Dampwood Termites','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10157','1121','Drywood Termites','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10158','1121','Subterranean Termites','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10159','1121','Formosan Termites','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10160','1122','A residue of the fumigant continues to control pests','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10161','1122','A single treatment will kill most pests in treated area','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10162','1122','The target site must be enclosed or covered to prevent the gas from escaping','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10163','1122','Fumigants are highly toxic to humans and all other living organisms','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10164','1123','Maintain proper fumigant concentration','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10165','1123','Trap pests within the structure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10166','1123','Prevent unauthorized entry to the structure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10167','1123','Maintain positive pressure throughout the structure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10168','1124','The structure is constructed with wood siding','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10169','1124','Short-term, high concentrations are needed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10170','1124','Labor considerations are a factor','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10171','1124','Cost considerations are a factor','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10172','1125','Solid, Liquid, Gas','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10173','1125','Gas, Solid, Waste','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10174','1125','Solid, Liquid, Waste','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10175','1125','Liquid, Solid, Air','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10176','1126','Sorption','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10177','1126','Diffusion','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10178','1126','Solubility','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10179','1126','Penetration','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10180','1127','Are uniformly highly toxic with poor warning properties','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10181','1127','Are uniformly less toxic than other pesticide formulations','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10182','1127','Vary from highly toxic to non-toxic depending on the product used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10183','1127','Vary in toxicity, odor, and color depending on the product used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10184','1128','Threshold limit value','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10185','1128','Verified respiration limit','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10186','1128','Short-term excursion limit','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10187','1128','Respiration-expiration value','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10188','1129','the tendency of a fumigant to evaporate','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10189','1129','the temperature at which a fumigant changes from a liquid to a solid','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10190','1129','the ability of the fumigant to dissolve in water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10191','1129','the toxicity of a fumigant once released','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10192','1130','42,000 cubic feet','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10193','1130','39,600 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10194','1130','40,800 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10195','1130','43,200 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10196','1131','420 ounces','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10197','1131','396 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10198','1131','408 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10199','1131','432 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10200','1132','5ppm','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10201','1132','10ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10202','1132','50ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10203','1132','100ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10204','1133','2 fluid oz','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10205','1133','1 fluid oz','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10206','1133','3 fluid oz','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10207','1133','4 fluid oz','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10208','1134','eye protection','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10209','1134','rubber gloves','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10210','1134','rubber boots','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10211','1134','long pants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10212','1135','open refrigerator doors','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10213','1135','remove all mattresses','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10214','1135','extinguish pilot lights','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10215','1135','turn off electric heaters','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10216','1136','Drywood termites','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10217','1136','Powder post beetles','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10218','1136','Roof Rats','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10219','1136','Bedbugs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10220','1137','36','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10221','1137','32','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10222','1137','24','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10223','1137','18','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10224','1138','400 lb/sq.in.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10225','1138','200 lb/sq.in.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10226','1138','300 lb/sq.in.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10227','1138','500 lb/sq.in.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10228','1139','Miran analyzer','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10229','1139','Draeger detector','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10230','1139','Davis detector','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10231','1139','Kitagawa tube','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10232','1140','Certified/Licensed applicators','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10233','1140','Employees of a licensed business','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10234','1140','Stewardship-program trainees','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10235','1140','Educational researchers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10236','1141','rapid speech','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10237','1141','respiratory irritation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10238','1141','reduced awareness','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10239','1141','slowed movement','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10240','1142','fluoride','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10241','1142','bromine','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10242','1142','calcium','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10243','1142','carbon','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10244','1143','42,000 cubic feet','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10245','1143','39,600 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10246','1143','40,800 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10247','1143','42,300 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10248','1144','420 ounces','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10249','1144','396 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10250','1144','408 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10251','1144','432ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10252','1145','Has a high LD50','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10253','1145','Is flammable','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10254','1145','Requires Applicators to wear rubber gloves','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10255','1145','Permits re-entry at 5ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10256','1146','Has a longer exposure time at colder temperatures','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10257','1146','Has a shorter exposure time at colder temperatures','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10258','1146','Exposure time is un affected by temperature','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10259','1146','Exposure time may be shortened if fumigation occurs in a vault','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10260','1147','Interscan detector','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10261','1147','Miran detector','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10262','1147','Draeger tube','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10263','1147','Vacscan meter','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10264','1148','20 to 145/1000 cu.ft.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10265','1148','5 to 15 /1000 cu.ft..','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10266','1148','150 to 300/1000 cu.ft.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10267','1148','100 to 500/1000 cu.ft','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10268','1149','May be performed a minimum of 15 feet from an occupied residence','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10269','1149','May be performed a minimum of 10 feet from an occupied residence','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10270','1149','May be performed a minimum of 10 feet from an unoccupied residence','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10271','1149','May not be performed at or near an occupied residence','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10272','1150','82,800 cubic feet','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10273','1150','2,513 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10274','1150','12,566 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10275','1150','50,265 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10276','1151','207.0 ounces','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10277','1151','6.3 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10278','1151','31.4 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10279','1151','125.7 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10280','1152','Permits re-entry at 5ppm','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10281','1152','Is flammable','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10282','1152','Has a high LD50','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10283','1152','Requires Applicators to wear rubber gloves','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10284','1153','Has a longer exposure time at colder temperatures','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10285','1153','Has a shorter exposure time at colder temperatures','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10286','1153','Exposure time is un affected by temperature','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10287','1153','Exposure time may be shortened if fumigation occurs in a vault','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10288','1154','Draeger tube','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10289','1154','Interscan detector','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10290','1154','Miran detector','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10291','1154','Vacscan meter','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10292','1155','Goggles','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10293','1155','Gloves','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10294','1155','Rubber boots','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10295','1155','Shoes and socks','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10296','1156','Check for stopped breathing','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10297','1156','Water should be administered','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10298','1156','Body temperature should be lowered','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10299','1156','Leave victim and seek medical help','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10300','1157','Business and applicator license numbers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10301','1157','Name, address, and telephone number of operator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10302','1157','Danger/Peligro','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10303','1157','Skull and crossbones','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10304','1158','Length X Width X Wall Height','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10305','1158','Length X Height (Area + Wall Height)','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10306','1158','Width X Width (Height + Length + Wall Height)','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10307','1158','Length X Area (Length + Wall Height)','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10308','1159','Self contained breathing apparatus','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10309','1159','Solo contained breathing actor','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10310','1159','Self complete breathing actuator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10311','1159','Solo complete breath analyzer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10312','1160','Solid, Liquid, Gas','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10313','1160','Gas, Solid, Waste','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10314','1160','Solid, Liquid, Waste','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10315','1160','Liquid, Solid, Air','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10316','1161','Sorption','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10317','1161','Diffusion','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10318','1161','Solubility','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10319','1161','Penetration','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10320','1162','Are uniformly highly toxic with poor warning properties','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10321','1162','Are uniformly less toxic than other pesticide formulations','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10322','1162','Vary from highly toxic to non-toxic depending on the product used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10323','1162','Vary in toxicity, odor, and color depending on the product used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10324','1163','oxygen deprivation','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10325','1163','toxic chemical','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10326','1163','enclosed space','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10327','1163','quick dispersion','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10328','1164','Threshold limit value','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10329','1164','Verified respiration limit','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10330','1164','Short-term excursion limit','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10331','1164','Respiration-expiration value','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10332','1165','the tendency of a fumigant to evaporate','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10333','1165','the temperature at which a fumigant changes from a liquid to a solid','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10334','1165','the ability of the fumigant to dissolve in water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10335','1165','the toxicity of a fumigant once released','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10336','1166','Dampwood Termites','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10337','1166','Drywood Termites','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10338','1166','Carpenter Ants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10339','1166','Flathead Borers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10340','1167','Drywood Termite fecal pellets and frass','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10341','1167','Dampwood Termite fecal pellets and frass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10342','1167','Carpenter Ants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10343','1167','Flathead Borers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10344','1168','Carpenter Ant frass','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10345','1168','Drywood Termites','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10346','1168','Dampwood Termite fecal pellets and frass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10347','1168','Flathead Borers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10348','1169','Drywood Termite fecal pellets and frass','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10349','1169','Dampwood Termite fecal pellets and frass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10350','1169','Carpenter Ant frass and pellets','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10351','1169','Formosan Termite frass and pellets','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10352','1170','Cigarette Beetles','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10353','1170','Rice Weevils','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10354','1170','Flour Weevils','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10355','1170','Corn Beetles','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10356','1171','Mediterranean Flour Moth','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10357','1171','Indian Meal Moth','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10358','1171','Web-Enclosed Moths','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10359','1171','Carpet-Web Moths','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10360','1172','Carpet Beetle and larva','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10361','1172','Cigarette Beetle and larva','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10362','1172','Flour Beetle and larva','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10363','1172','Warehouse Beetle and larva','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10364','1173','Powderpost Beetle damage','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10365','1173','Carpenter Bee damage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10366','1173','Ips Beetle damage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10367','1173','Carpenter Ant damage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10368','1174','Gopher and mound','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10369','1174','Ground Squirrel and mound','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10370','1174','Chipmunk and mound','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10371','1174','Prairie Dog and mound','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10372','1175','Ground Squirrel','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10373','1175','Prairie Dog','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10374','1175','Gopher','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10375','1175','Chipmunk','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10376','1176','Fumigation is conducted under vacuum conditions rather that at normal atmospheric pressure','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10377','1176','Fumigation is conducted at normal atmospheric pressures after the vacuuming is completed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10378','1176','Vacuum fumigations require additional monitoring','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10379','1176','Vault fumigations require less monitoring','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10380','1177','Mitigating environmental concerns','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10381','1177','Calculation of the Half Loss Time (HLT)','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10382','1177','Ensuring a successful fumigation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10383','1177','Reducing fumigant use','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10384','1178','5ppm','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10385','1178','10ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10386','1178','50ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10387','1178','100ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10388','1179','2 fluid oz','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10389','1179','1 fluid oz','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10390','1179','3 fluid oz','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10391','1179','4 fluid oz','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10392','1180','eye protection','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10393','1180','rubber gloves','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10394','1180','rubber boots','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10395','1180','long pants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10396','1181','open refrigerator doors','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10397','1181','remove all mattresses','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10398','1181','extinguish pilot lights','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10399','1181','turn off electric heaters','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10400','1182','Drywood termites','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10401','1182','Powder post beetles','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10402','1182','Roof Rats','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10403','1182','Bedbugs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10404','1183','36','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10405','1183','32','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10406','1183','24','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10407','1183','18','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10408','1184','400 lb/sq.in.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10409','1184','200 lb/sq.in.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10410','1184','300 lb/sq.in.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10411','1184','500 lb/sq.in.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10412','1185','Miran analyzer','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10413','1185','Draeger detector','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10414','1185','Davis detector','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10415','1185','Kitagawa tube','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10416','1186','Certified/Licensed applicators','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10417','1186','Employees of a licensed business','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10418','1186','Stewardship-program trainees','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10419','1186','Educational researchers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10420','1187','rapid speech','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10421','1187','respiratory irritation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10422','1187','reduced awareness','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10423','1187','slowed movement','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10424','1188','fluoride','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10425','1188','bromine','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10426','1188','calcium','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10427','1188','carbon','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10428','1189','1ppm','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10429','1189','5ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10430','1189','10ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10431','1189','50ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10432','1190','82,800 cubic feet','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10433','1190','72,000 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10434','1190','77,400 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10435','1190','165,600 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10436','1191','55 ounces','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10437','1191','48 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10438','1191','51 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10439','1191','109 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10440','1192','Two','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10441','1192','One','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10442','1192','Theree','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10443','1192','Four','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10444','1193','21 lbs. – 26 lbs.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10445','1193','10 lbs. – 13 lbs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10446','1193','15 lbs. – 19 lbs.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10447','1193','31 lbs. – 39 lbs.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10448','1194','12 – 18 hrs.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10449','1194','8 – 11 hrs.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10450','1194','6 – 10 hrs.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10451','1194','3 – 5 hrs.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10452','1195','Permits re-entry at 5ppm','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10453','1195','Is flammable','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10454','1195','Has a high LD50','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10455','1195','Requires Applicators to wear rubber gloves','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10456','1196','Has a longer exposure time at colder temperatures','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10457','1196','Has a shorter exposure time at colder temperatures','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10458','1196','Exposure time is un affected by temperature','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10459','1196','Exposure time may be shortened if fumigation occurs in a vault','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10460','1197','Draeger tube','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10461','1197','Miran detector','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10462','1197','Interscan detector','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10463','1197','Vacscan meter','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10464','1198','20 to 145/1000 cu.ft.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10465','1198','5 to 15 /1000 cu.ft..','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10466','1198','150 to 300/1000 cu.ft.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10467','1198','100 to 500/1000 cu.ft','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10468','1199','Allows the fumigant to be applied directly to the commodity','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10469','1199','Must be completed before moving the car','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10470','1199','Allows for evacuation during transit','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10471','1199','Requires only door postings as notification','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10472','1200','May be performed a minimum of 15 feet from an occupied residence','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10473','1200','May be performed a minimum of 10 feet from an occupied residence','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10474','1200','May be performed a minimum of 10 feet from an unoccupied residence','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10475','1200','May not be performed at or near an occupied residence','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10476','1201','The dosage is increased if the seal is suspect','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10477','1201','The dosage is decreased if high moisture is present','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10478','1201','Re-entry is permissible at 5ppm or less','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10479','1201','All pellets will be reacted within 5 days','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10480','1202','Buried in the ground','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10481','1202','Placed in a secured disposal','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10482','1202','Returned to the vendor','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10483','1202','Spread on the ground','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10484','1203','The appropriate moisture level is present','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10485','1203','Endangered species are at least 1 mile from the site','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10486','1203','Food crops are not present','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10487','1203','Gophers are present at the site','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10488','1204','2 to 4 tablets/mound','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10489','1204','1 to 2 tablets/10 sq.ft. of surface area','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10490','1204','2 to 4 tablets/ 10sq.ft. of surface area','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10491','1204','10 to 20 tablets/mound','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10492','1205','12,566 cu.ft.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10493','1205','2,513 cu.ft.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10494','1205','50,265 cu.ft.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10495','1205','82,800 cu.ft.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10496','1206','31.4 ounces','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10497','1206','6.3 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10498','1206','125.7 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10499','1206','207.0 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10500','1207','One','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10501','1207','Two','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10502','1207','Three','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10503','1207','Four','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10504','1208','25.0lbs','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10505','1208','6.0lbs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10506','1208','12.5lbs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10507','1208','37.5lbs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10508','1209','6 hrs','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10509','1209','3 hrs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10510','1209','12 hrs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10511','1209','24 hrs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10512','1210','25ppm','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10513','1210','5ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10514','1210','10ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10515','1210','50ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10516','1211','Heat exchanger','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10517','1211','Wind gauge','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10518','1211','Soil thermometer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10519','1211','Slab thermometer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10520','1212','a. Draeger Detector.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10521','1212','Davis Detector','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10522','1212','Ishigawa Detector','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10523','1212','Halide Detector','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10524','1213','Length X Width X Wall Height + ½ Roof Height X Roof Width X Roof Length','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10525','1213','Length X Height X Wall Height + ½ Attic Height','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10526','1213','Width X Width X Height + Length + Wall Height','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10527','1213','Length X Area X Length + Wall Height','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10528','1214','Billowing','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10529','1214','Ballooning','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10530','1214','Blooming','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10531','1214','Breathing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10532','1215','Irritating to the eyes','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10533','1215','Odorless','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10534','1215','Non-irritating to the skin','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10535','1215','Hazardous at concentrations below 10ppm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10536','1216','Goggles','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10537','1216','Gloves','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10538','1216','Rubber boots','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10539','1216','Shoes and socks','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10540','1217','Check for stopped breathing','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10541','1217','Water should be administered','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10542','1217','Body temperature should be lowered','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10543','1217','Leave victim and seek medical help','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10544','1218','Business and applicator license numbers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10545','1218','Name, address, and telephone number of operator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10546','1218','Danger/Peligro','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10547','1218','Skull and crossbones','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10548','1219','Eating utensils','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10549','1219','Furs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10550','1219','Leather goods','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10551','1219','Live plants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10552','1220','4mil or greater','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10553','1220','2mil or greater','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10554','1220','1mil or greater','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10555','1220','polyethylene sheeting may not be used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10556','1221','6.0 lbs/1000 cu.ft. for 6hrs.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10557','1221','3.5 lbs./1000 cu.ft. for 6hrs.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10558','1221','4.5 lbs./1000 cu.ft. for 12 hrs.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10559','1221','2.0 lbs/1000 cu.ft. for 24 hrs.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10560','1222','1.0 – 2.0 lbs/1000 cu.ft. for 6 hrs.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10561','1222','1.0 – 2.0 lbs./1000 cu.ft. for 12 – 24 hrs.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10562','1222','4.0 lbs/1000 cu.ft. for 2hrs.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10563','1222','4.0 lbs/1000 cu.ft. for 3 hrs.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10564','1223','1.5 – 2.0 lbs/1000 cu.ft. for 24 hrs.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10565','1223','6 oz./1000 cu.ft. for 24 hrs.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10566','1223','1.0 – 1.5 lbs./1000 cu.ft. for 12 – 18 hrs.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10567','1223','1.0 – 1.5 lbs/1000 cu.ft. for 24hrs.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10568','1224','Relative humidity within the structure','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10569','1224','Respiration rate of target organism','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10570','1224','Species of the target organism','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10571','1224','Ambient temperature within the structure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10572','1225','Little disturbance to infested materials','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10573','1225','The concentration of gas in areas where applied','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10574','1225','The presence of a residual barrier against re-infestation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10575','1225','Both dermal and inhaled toxicity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10576','1226','Diffusion','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10577','1226','Entropy','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10578','1226','Osmosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10579','1226','Sorption','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10580','1227','42,000 cubic feet','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10581','1227','39,600 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10582','1227','40,800 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10583','1227','43,200 cubic feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10584','1228','420 ounces','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10585','1228','396 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10586','1228','408 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10587','1228','432 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10588','1229','One','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10589','1229','Two','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10590','1229','Three','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10591','1229','Four','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10592','1230','126lbs','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10593','1230','84lbs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10594','1230','168lbs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10595','1230','189lbs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10596','1231','2 hrs','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10597','1231','4 hrs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10598','1231','8 hrs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10599','1231','16hrs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10600','1232','72 hrs','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10601','1232','24 hrs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10602','1232','48 hrs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10603','1232','96 hrs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10604','1233','4 bags','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10605','1233','3 bags','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10606','1233','2 bags','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10607','1233','1 bag','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10608','1234','Bags should be used','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10609','1234','Windows and doors should be opened','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10610','1234','Cracks, vents, and leaks should be sealed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10611','1235','The point at which a fumigant changes from a liquid to a gas','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10612','1235','The point at which a fumigant will dissolve into a liquid','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10613','1235','The point at which a fumigant reaches ambient temperature','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10614','1235','The at which a fumigant  reaches equilibrium','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10615','1236','Expansion','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10616','1236','Abduction','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10617','1236','Sorption','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10618','1236','Desorption','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10619','1237','Carbon dioxide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10620','1237','Oxygen','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10621','1237','Chloropicrin','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10622','1237','Halide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10623','1238','Chewing mouthparts','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10624','1238','Piercing-sucking mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10625','1238','Sponging mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10626','1238','Siphoning mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10627','1239','Piercing-sucking mouthparts','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10628','1239','Chewing mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10629','1239','Sponging mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10630','1239','Siphoning mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10631','1240','Sponging mouthparts','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10632','1240','Piercing-sucking mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10633','1240','Chewing mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10634','1240','Siphoning mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10635','1241','Siphoning mouthparts','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10636','1241','Sponging mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10637','1241','Piercing-sucking mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10638','1241','Chewing mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10639','1242','Egg, nymph and adult','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10640','1242','Egg, larva and adult','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10641','1242','First instar, second instar and adult','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10642','1242','Larva, pupa and adult','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10643','1243','Egg, larva, pupa and adult','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10644','1243','Egg, naiads, pupa and adult','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10645','1243','Egg, naiads, nymph and adult','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10646','1243','First instar, second instar, third instar and adult','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10647','1244','Workers, queens and males','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10648','1244','Reproductive, males and queens','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10649','1244','Reproductive, workers and soldiers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10650','1244','Reproductive, workers and queens','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10651','1245','German','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10652','1245','American','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10653','1245','Oriental','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10654','1245','Brown-banded','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10655','1246','Brown-banded','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10656','1246','German','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10657','1246','American','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10658','1246','Oriental','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10659','1247','Oriental','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10660','1247','Brown-banded','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10661','1247','German','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10662','1247','American','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10663','1248','Live outside but occasionally invade buildings','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10664','1248','Have adapted so well to man that they no longer live outside','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10665','1248','Are frequently found infesting wooden frames around doors','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10666','1248','Live inside but may be found outside buildings','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10667','1249','Crack and crevice','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10668','1249','Power dusting','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10669','1249','Power spraying','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10670','1249','None are permitted in food areas','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10671','1250','Increasing available moisture','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10672','1250','Weather-stripping doors and windows','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10673','1250','Removal of decaying matter','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10674','1250','Reducing available harborage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10675','1251','Ticks','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10676','1251','Lice','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10677','1251','Fleas','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10678','1251','Bedbugs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10679','1252','Total volume of unobstructed area','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10680','1252','Total interior surface area','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10681','1252','Release area height and width','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10682','1252','Restricted re-entry interval','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10683','1253','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10684','1253','Rodents','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10685','1253','Birds','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10686','1253','Insects','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10687','1254','Thoroughly surveying the problem','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10688','1254','Baiting to kill all rodents present','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10689','1254','Improving infested area sanitation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10690','1254','Applying multiple eradication strategies','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10691','1255','Broadcast spraying','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10692','1255','Fumigating','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10693','1255','Fogging','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10694','1255','Baiting','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10695','1256','Two square feet','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10696','1256','One square feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10697','1256','Five square feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10698','1256','Ten square feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10699','1257','German cockroach','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10700','1257','American cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10701','1257','Oriental cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10702','1257','Brown-banded cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10703','1258','Brown-banded cockroach','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10704','1258','German cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10705','1258','American cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10706','1258','Oriental cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10707','1259','American cockroach','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10708','1259','German cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10709','1259','Oriental cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10710','1259','Brown-banded cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10711','1260','Oriental cockroach','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10712','1260','American cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10713','1260','German cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10714','1260','Brown-banded cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10715','1261','The elimination favorable habitat','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10716','1261','The appropriate use of pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10717','1261','Improved infested area sanitation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10718','1261','Monitoring and hygiene of household pets','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10719','1262','In standing water','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10720','1262','Between loose stones','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10721','1262','Under tree bark','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10722','1262','In lumber piles','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10723','1263','Brown-banded cockroach','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10724','1263','German cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10725','1263','American cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10726','1263','Oriental cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10727','1264','American cockroach','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10728','1264','German cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10729','1264','Oriental cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10730','1264','Brown-banded cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10731','1265','German cockroach','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10732','1265','American cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10733','1265','Oriental cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10734','1265','Brown-banded cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10735','1266','Wasp','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10736','1266','Honet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10737','1266','Honey Bee','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10738','1266','Yellow Jacket','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10739','1267','Honey Bee','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10740','1267','Wasp','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10741','1267','Honet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10742','1267','Yellow Jacket','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10743','1268','House Fly','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10744','1268','Deer Fly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10745','1268','Fruit Fly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10746','1268','Phorid Fly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10747','1269','Earwig','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10748','1269','Silverfish','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10749','1269','Cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10750','1269','Sowbug','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10751','1270','Sowbug','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10752','1270','Earwig','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10753','1270','Silverfish','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10754','1270','Cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10755','1271','Silverfish','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10756','1271','Sowbug','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10757','1271','Earwig','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10758','1271','Cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10759','1272','Black widow spider','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10760','1272','Arizona brown spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10761','1272','Sun spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10762','1272','House spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10763','1273','Arizona brown spider','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10764','1273','Black widow spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10765','1273','Sun spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10766','1273','House spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10767','1274','Cedntipede','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10768','1274','Millipede','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10769','1274','Silverfish','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10770','1274','Solpugid','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10771','1275','Mouse','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10772','1275','Gopher','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10773','1275','Chipmunk','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10774','1275','Rat','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10775','1276','Crickets','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10776','1276','Cockroaches','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10777','1276','Grasshoppers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10778','1276','Silverfish','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10779','1277','Red harvester ant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10780','1277','Carpenter ant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10781','1277','Southern fire ant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10782','1277','Imported red fire ant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10783','1278','Compressed air sprayer','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10784','1278','Power sprayer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10785','1278','Granular applicator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10786','1278','Duster','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10787','1279','Advanced knowledge of pesticide chemistry','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10788','1279','Advanced knowledge of pests and pest problems','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10789','1279','Choosing the right pesticide and equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10790','1279','Choosing the proper method of application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10791','1280','Unintended dispersion and drift','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10792','1280','Possible malfunction of the sprayer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10793','1280','Incompatibility with previous liquid applications','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10794','1280','Added mixing, handling and loading requirements','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10795','1281','High volume, low pressure','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10796','1281','High volume, High pressure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10797','1281','Low volume, High pressure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10798','1281','Low volume, low pressure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10799','1282','Pump','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10800','1282','Tank','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10801','1282','Hose','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10802','1282','Agitator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10803','1283','Ultra Low Volume','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10804','1283','Under Label Volume','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10805','1283','Use Liberal Volume','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10806','1283','Use Label Volume','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10807','1284','Never use more pesticide than the label allows.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10808','1284','Use higher than label rates of pesticides very carefully','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10809','1284','Never apply herbicides close to a body of water.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10810','1284','Use low pressure, low volume when applying pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10811','1285','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10812','1285','Mixing and loading','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10813','1285','Equipment cleaning','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10814','1285','Disposal of containers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10815','1286','Pest population increases','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10816','1286','Ineffective control','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10817','1286','Environmental damage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10818','1286','Left-over mix','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10819','1287','One gallon','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10820','1287','Two gallons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10821','1287','Three gallions','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10822','1287','Five Gallons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10823','1288','1.20 ounces per gallon','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10824','1288','0.12 ounces per gallon','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10825','1288','12.0 ounces per gallon','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10826','1288','Non of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10827','1289','3.60 ounces','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10828','1289','0.36 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10829','1289','36.0 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10830','1289','36.3 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10831','1290','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10832','1290','How much finished product needed to complete the job','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10833','1290','Rate of application for equipment used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10834','1290','The size of the area of intended treatment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10835','1291','Records must be given to the consumer after application','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10836','1291','Records can establish proof of proper use','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10837','1291','Records can help you reduce pesticide mistakes or misuse','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10838','1291','OSHA requires records of all work-related activities','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10839','1292','Target pest or purpose of service','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10840','1292','Percent of active ingredient in the concentrate','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10841','1292','Name and license number of Qualifying party','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10842','1292','Service vehicle registration or license number','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10843','1293','A copy of the certification card for applicators using the vehicle','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10844','1293','Personal protective equipment as required for all pesticides on the vehicle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10845','1293','Measuring devices for the pesticides transported or used on the vehicle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10846','1293','An MSDS for each pesticide on the service vehicle.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10847','1294','Keep the water fill-pipe above the level of the pesticide mixture','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10848','1294','Fill only from a garden hose at the application site','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10849','1294','Fill only at designated pesticide mixing-loading stations','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10850','1294','Continue water flow through hose until after removing it from tank','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10851','1295','Sheds its skin','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10852','1295','Grows wings','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10853','1295','Grows antennae','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10854','1295','Lays eggs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10855','1296','Locate and treat the nest directly','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10856','1296','Spray the entire yard to kill the colony through foraging','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10857','1296','treat the baseboards in structures near food source','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10858','1296','Spray along foraging trails to cut off colony from food','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10859','1297','Residual contact insecticides','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10860','1297','Well-distributed bait stations','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10861','1297','Nocturnal liquid applications','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10862','1297','Nocturnal liquid applications','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10863','1298','Accurate pest identification','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10864','1298','Elimination of harborage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10865','1298','Elimination of moisture','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10866','1298','Accurate pesticide selection','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10867','1299','Improper pest identification','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10868','1299','Elongated pesticide persistence','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10869','1299','Use of a broad-spectrum pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10870','1299','Extraordinary site sanitation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10871','1300','Increased tolerance threshold','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10872','1300','Identifying potential resistance','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10873','1300','Cultural control adjustments','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10874','1300','Improved sanitation measures','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10875','1301','Safe product use','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10876','1301','Pesticide chemical families','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10877','1301','Authorized product distributors','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10878','1301','Basic pest entomology','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10879','1302','Signs and symptoms of exposure','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10880','1302','Mixing of two or more pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10881','1302','Advanced medical procedures','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10882','1302','Removal of product stains','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10883','1303','Before disposing of the pesticide container','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10884','1303','Immediately after purchase','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10885','1303','After mixing but before applying','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10886','1303','In the event of serious exposure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10887','1304','Lawful if permitted by the label','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10888','1304','Prohibited by both state & federal regulations','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10889','1304','Ineffective for pesticides from different chemical families','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10890','1304','A means of reducing exposure risk','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10891','1305','Face shielding','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10892','1305','High-top canvas shoes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10893','1305','Leather gloves','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10894','1305','Adequate sun protection','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10895','1306','Pesticide concentration cost','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10896','1306','Pesticide formulation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10897','1306','Applicator exposure risk','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10898','1306','Environmental fate','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10899','1307','Nematodes','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10900','1307','Piscicides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10901','1307','Herbicides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10902','1307','Molluscacides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10903','1308','Pyrethroid','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10904','1308','Carbamate','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10905','1308','Organophosphate','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10906','1308','Botanical','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10907','1309','Impermeable gloves made of neoprene','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10908','1309','Safety glasses, goggles, or face shield','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10909','1309','Coveralls or long-sleeved shirt','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10910','1309','A  dust/mist respirator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10911','1310','Non-food areas only','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10912','1310','Harborage areas','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10913','1310','Trails around doors and windows','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10914','1310','Cracks and crevices','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10915','1311','Wrapped in newspaper and discarded','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10916','1311','Placed in a sealed container for disposal in a sanitary landfill','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10917','1311','Triple rinsed and returned for recycling','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10918','1311','Punctured and disposed of in a sanitary landfill','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10919','1312','Residue on plants is non-toxic','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10920','1312','Extremely toxic to aquatic invertebrates','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10921','1312','Avoid breathing  spray mist','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10922','1312','Avoid breathing dust mist','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10923','1313','0.10%','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10924','1313','0.05%','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10925','1313','0.50%','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10926','1313','1.00%','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10927','1314','Broad-spectrum pesticide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10928','1314','Non-toxic pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10929','1314','Ready-to-use pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10930','1314','General surface pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10931','1315','Borax','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10932','1315','Fluoride','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10933','1315','Orthide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10934','1315','Acid','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10935','1316','Warning signs','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10936','1316','Original container','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10937','1316','Locked area','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10938','1316','Away from feed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10939','1317','Apply dust to cracks and crevices','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10940','1317','Apply dust to large area for general effect','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10941','1317','Apply dust to the perimeter','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10942','1317','Apply dust as a baseboard treatment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10943','1318','Red harvester ant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10944','1318','Red Fire Ant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10945','1318','Red Flour Ant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10946','1318','Imported red fire ant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10947','1319','German cockroach','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10948','1319','American cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10949','1319','Oriental cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10950','1319','Brown-banded cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10951','1320','Northern Mole Cricket','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10952','1320','Jerusalem Cricket','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10953','1320','American Cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10954','1321','Indian Meal Moth','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10955','1321','Webbing Clothes Moth','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10956','1321','Confused Flour Moth','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10957','1321','Taspestry Clothes Moth','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10958','1322','Black Widow Spider','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10959','1322','Sun Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10960','1322','Wolf Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10961','1322','Brown Recluse Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10962','1323','Crab Spider','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10963','1323','Recluse Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10964','1323','Jumping Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10965','1323','Sun Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10966','1324','House Fly','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10967','1324','Horse Fly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10968','1324','Fruit Fly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10969','1324','Black Fly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10970','1325','Varied Carpet Beetle','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10971','1325','Confused Flour Beetle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10972','1325','Palo Verde Beetle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10973','1325','Leaf Cutter Beetle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10974','1326','Jerusalem Cricket','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10975','1326','Mole Cricket','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10976','1326','Wolf Scorpion','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10977','1326','Wood Scorpion','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10978','1327','Brownbanded Cockroach','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10979','1327','German Cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10980','1327','American Cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10981','1327','Oriental Cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10982','1328','Jumping Spider','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10983','1328','Wolf Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10984','1328','Brown Recluse Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10985','1328','Sun Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10986','1329','Webbing Clothes Moth','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10987','1329','Tapestry Clothes Moth','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10988','1329','Indian Meal Moth','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10989','1329','Confused Flour Moth','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10990','1330','House Cricket','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10991','1330','Mole Cricket','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10992','1330','Jerusalem Cricket','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10993','1330','Field Cricket','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10994','1331','American cockroach','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10995','1331','German cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10996','1331','Oriental cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10997','1331','Turkistan cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10998','1332','Sun Spider','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('10999','1332','Wolf Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11000','1332','Brown Recluse Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11001','1332','Common House Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11002','1333','Fire Ant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11003','1333','Carpenter Ant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11004','1333','Thief Ant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11005','1333','Pavement Ant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11006','1334','Pigeon','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11007','1334','Dove','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11008','1334','Bobwhite','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11009','1334','Sparrow','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11010','1335','Honeybee','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11011','1335','Bumblebee','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11012','1335','Leafcutter Bee','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11013','1335','Carpenter Bee','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11014','1336','Field Cricket','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11015','1336','Mole Cricket','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11016','1336','House Cricket','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11017','1336','Jerusalem Cricket','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11018','1337','House Mouse','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11019','1337','Field Mouse','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11020','1337','Church Mouse','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11021','1337','Warehouse Mouse','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11022','1338','Clover Mite','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11023','1338','Dust Mite','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11024','1338','Lesser Mite','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11025','1338','Body Mite','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11026','1339','Brown Recluse Spider','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11027','1339','Brown Wolf Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11028','1339','Common House Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11029','1339','Black Widow Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11030','1340','Oriental cockroach','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11031','1340','American cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11032','1340','German cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11033','1340','Brown-banded cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11034','1341','Sow Bug','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11035','1341','Potato Bug','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11036','1341','Sod Bug','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11037','1341','Billbug','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11038','1342','Arizona Brown Spider','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11039','1342','Brown Recluse Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11040','1342','Black Widow Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11041','1342','Wolf Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11042','1343','House Centipede','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11043','1343','Desert Centipede','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11044','1343','Common Millipede','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11045','1343','Caterpillar','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11046','1344','Pocket Gopher','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11047','1344','Tree Rat','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11048','1344','Norway Rat','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11049','1344','Kangaroo Rat','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11050','1345','Red Flour Beetle','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11051','1345','Palo Verde Beetle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11052','1345','Box Elder Beetle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11053','1345','Red Headed Beetle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11054','1346','Turkistan Cockroach','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11055','1346','American Cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11056','1346','Oriental Cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11057','1346','Brownbanded Cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11058','1347','Earwigs','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11059','1347','Sow Bugs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11060','1347','Varied Carpet Beetles','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11061','1347','Billbugs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11062','1348','Bumblebee','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11063','1348','Honey Bee','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11064','1348','Leafcutter Bee','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11065','1348','Carpenter Bee','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11066','1349','American Dog Tick','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11067','1349','Rocky Mountain Spotted Tick','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11068','1349','Western Deer Tick','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11069','1349','Reticulated Field Tick','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11070','1350','Danger always appears on a product label with Poison printed in red','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11071','1350','All three-signal words may appear on the same pesticide label','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11072','1350','The signal word Warning indicates the product is highly toxic','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11073','1350','The signal word “Caution” indicates the product has no toxicity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11074','1351','Applying a pesticide to a target pest if the site is listed','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11075','1351','Using dosages higher than those listed for severe pest problems','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11076','1351','Using alternative equipment or an alternative method of application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11077','1351','Making applications more frequently for persistent problems','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11078','1352','The chemical or chemicals having the pesticidal effect','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11079','1352','A chemical causing uniform spreading of a liquid to contact surfaces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11080','1352','A suspension of one liquid as microscopic drops in another liquid','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11081','1352','The manner in which pesticides are prepared for sale to the user','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11082','1353','Minimize exposure','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11083','1353','Use only EPA-approved products','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11084','1353','Pesticides are dangerous','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11085','1353','Store pesticides in original containers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11086','1354','Foggers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11087','1354','Backpack sprayers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11088','1354','Power sprayers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11089','1354','Hand-held compressed air sprayer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11090','1355','Small quantities of dust into cracks and confined spaces','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11091','1355','Large quantities of dust into large, unconfined spaces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11092','1355','Small quantities of dust into small, unconfined spaces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11093','1355','Large quantities of dust into crevices and unconfined spaces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11094','1356','German cockroach','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11095','1356','American cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11096','1356','Oriental cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11097','1356','Brown-banded cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11098','1357','Reddish brown with yellow border on pronotum at least 1½ inch long','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11099','1357','Two dark longitudinal stripes on the pronotum about ½ inch long','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11100','1357','Two light transverse bands across the base of the wings and abdomen','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11101','1357','Sides of the thorax and wings margined with yellow, about 2/3 inch long','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11102','1358','Dark brown or nearly black wing pads about 1¼ inches long','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11103','1358','Two dark longitudinal stripes on the pronotum about ½ inch long','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11104','1358','Reddish brown with yellow border on pronotum at least 1½ inches long','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11105','1358','Two light transverse bands across the base of the wings and abdomen','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11106','1359','Two light transverse bands across the base of the wings and abdomen','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11107','1359','Two dark longitudinal stripes on the pronotum, about ½ inch long','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11108','1359','Reddish brown with yellow border on pronotum at least1½ inches long','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11109','1359','Sides of the thorax and wings margined with yellow, about 2/3 inch long','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11110','1360','Two dark longitudinal stripes on the pronotum, about ½ inch long','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11111','1360','Reddish brown with yellow border on pronotum at least1½ inches long','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11112','1360','Two light transverse bands across the base of the wings and abdomen','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11113','1360','Dark brown or nearly black wing pads, about 1¼ inches long','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11114','1361','Proper identification aids in the search for the nest','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11115','1361','Ants are resistant to most pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11116','1361','Ants can only be treated effectively at specific life-cycle stages','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11117','1361','Pesticides are ant-species specific','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11118','1362','Applied as directed by product label','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11119','1362','Placed in tamper-proof bait stations along all suspected trails','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11120','1362','Repellent pesticides are applied simultaneously in the same area','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11121','1362','Resistance has not developed to all applied baits','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11122','1363','Are of tropical or subtropical origin','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11123','1363','Reproduce best under cool and dry conditions','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11124','1363','Hibernate during life-cycle transformations','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11125','1363','Consume large quantities of the infested foodstuffs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11126','1364','House Mouse','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11127','1364','Roof Rat','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11128','1364','Norway Rat','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11129','1364','Gopher','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11130','1365','Warfarin','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11131','1365','Chloropicrin','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11132','1365','Strychnine','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11133','1365','Bromethalin','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11134','1366','Tracking powders','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11135','1366','Liquid baits','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11136','1366','Pellets','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11137','1366','Food baits','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11138','1367','Law specifies which control methods may be used to manage infestations and Nearly all birds are protected by law','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11139','1367','Birds can harbor disease organisms and must be exterminated','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11140','1367','Law specifies which control methods may be used to manage infestations','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11141','1367','Nearly all birds are protected by law','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11142','1368','1.00','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11143','1368','0.50','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11144','1368','1.33','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11145','1368','2.00','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11146','1369','Contact pesticide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11147','1369','Stomach poison','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11148','1369','Desiccant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11149','1369','Fumigant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11150','1370','30.6oz.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11151','1370','20.6oz.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11152','1370','25.6oz.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11153','1370','35.6oz.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11154','1371','Desiccant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11155','1371','Stomach poison','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11156','1371','Contact pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11157','1371','Fumigant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11158','1372','Fumigant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11159','1372','Desiccant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11160','1372','Stomach poison','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11161','1372','Contact pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11162','1373','Stomach poison','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11163','1373','Contact pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11164','1373','Desiccant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11165','1373','Bait','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11166','1374','Organophosphate','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11167','1374','Botanical','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11168','1374','Pyrethroid','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11169','1374','Pyrethrum','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11170','1375','Mosquitoes','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11171','1375','Ticks','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11172','1375','House Flies','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11173','1375','Rats','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11174','1376','Lie motionless in calm water','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11175','1376','Live in water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11176','1376','Well-defined head, thorax and abdomen','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11177','1376','Need not surface for air','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11178','1377','Mosquito breeding sites are located','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11179','1377','Mosquito breeding sites and habitat are altered','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11180','1377','A public education program is undertaken','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11181','1377','Adult mosquito migration is inhibited','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11182','1378','Excess food','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11183','1378','Gnawing damage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11184','1378','Grease marks','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11185','1378','Urine stains','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11186','1379','Use of Pre-baiting','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11187','1379','Providing perches','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11188','1379','Use of tactile repellents','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11189','1379','Improved sanitation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11190','1380','Develop without metamorphosis','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11191','1380','Have a gradual metamorphosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11192','1380','Have an incomplete metamorphosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11193','1380','Have a parasitic metamorphosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11194','1381','Complete metamorphosis','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11195','1381','Gradual metamorphosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11196','1381','Parasitic metamorphosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11197','1381','Incomplete metamorphosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11198','1382','Gradual metamorphosis','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11199','1382','Incomplete metamorphosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11200','1382','Completed metamorphosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11201','1382','Parasitic metamorphosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11202','1383','An incomplete metamorphosis','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11203','1383','Developed without metamorphosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11204','1383','A gradual metamorphosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11205','1383','A complete metamorphosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11206','1384','Deer Tick','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11207','1384','Mountain Tick','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11208','1384','Dog Tick','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11209','1384','Brown Tick','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11210','1385','Remove debris under which they may hide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11211','1385','Vacuum up their eggs and webs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11212','1385','Apply odorous repellant pesticides to harborages','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11213','1385','Set traps in areas of nocturnal activity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11214','1386','Total volume of unobstructed area','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11215','1386','Total interior surface area','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11216','1386','The sum of surface and unobstructed areas','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11217','1386','The product of surface and unobstructed areas','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11218','1387','One gallon','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11219','1387','Two gallons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11220','1387','Three gallons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11221','1387','Four gallons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11222','1388','3.60','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11223','1388','0.076','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11224','1388','0.53','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11225','1388','6.30','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11226','1389','The percentage of active ingredient in the concentrate','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11227','1389','The amount of finished product needed to complete the job','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11228','1389','The rate of application for the equipment used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11229','1389','The square footage of the intended treatment site','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11230','1390','Become licensed within ninety days of beginning employment','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11231','1390','Become licensed within thirty days of beginning employment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11232','1390','Receive 5 hours of training but need not be licensed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11233','1390','Work under the direct supervision of the Qualifying Party','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11234','1391','Chewing mouthparts','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11235','1391','Piercing-sucking mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11236','1391','Sponging mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11237','1391','Siphoning mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11238','1392','Workers, queens and males','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11239','1392','Reproductives, males and queens','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11240','1392','Queens, workers and soldiers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11241','1392','Workers, queens and soldiers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11242','1393','High volume, low pressure','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11243','1393','High volume, high pressure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11244','1393','Low volume, low pressure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11245','1393','Low volume, high pressure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11246','1394','Accurate identification of the pest','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11247','1394','Choosing a cost effective method','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11248','1394','Providing written educational materials','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11249','1394','Decreasing toxic pesticide use','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11250','1395','Sponging mouthparts','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11251','1395','Piercing-sucking mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11252','1395','Chewing mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11253','1395','Siphoning mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11254','1396','8 lb./3000 sq.ft.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11255','1396','1 lb./1000 sq.ft.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11256','1396','3 lb./3000 sq.ft.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11257','1396','4 lb./1000 sq.ft.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11258','1397','Apply dust to cracks and crevices','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11259','1397','Apply dust to large area for general effect','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11260','1397','Apply dust to the perimeter','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11261','1397','Apply dust as a baseboard treatment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11262','1398','Staining','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11263','1398','Odorless','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11264','1398','Long -lasting','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11265','1398','Nonflammable','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11266','1399','Borax','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11267','1399','Floride','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11268','1399','Orthide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11269','1399','Acid','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11270','1400','Warning placards','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11271','1400','Original container','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11272','1400','Locked area','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11273','1400','Away from feed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11274','1401','Residue on plants is non-toxic','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11275','1401','Extremely toxic to aquatic invertebrates','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11276','1401','Avoid breathing dust or spray mist','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11277','1401','Do not contact treated surfaces until dry','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11278','1402','0.10%','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11279','1402','0.05%','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11280','1402','0.50%','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11281','1402','1.00%','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11282','1403','Wrapped in newspaper and discarded','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11283','1403','Placed in a sealed container for disposal in a sanitary landfill','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11284','1403','Triple rinsed and returned for recycling','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11285','1403','Punctured and disposed of in a sanitary landfill','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11286','1404','Entire floor area','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11287','1404','Closets and storage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11288','1404','Cracks & crevices','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11289','1404','Under furnishings','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11290','1405','Away from pollinating bees','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11291','1405','Near buildings','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11292','1405','Along foraging trails','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11293','1405','On the mound surface','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11294','1406','Broad-spectrum pesticide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11295','1406','Non-toxic pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11296','1406','Ready-to-use pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11297','1406','General surface pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11298','1407','Turkistan cockroaches','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11299','1407','Mosquitoes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11300','1407','Yellow Jackets','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11301','1407','Fleas','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11302','1408','Impermeable gloves made of neoprene','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11303','1408','Safety glasses, goggles, or face shield','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11304','1408','Coveralls or long-sleeved shirt','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11305','1408','A  dust/mist respirator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11306','1409','0.20%','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11307','1409','0.05%','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11308','1409','0.10%','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11309','1409','0.15%','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11310','1410','Non-food areas only','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11311','1410','Harborage areas','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11312','1410','Trails around doors and windows','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11313','1410','Cracks and crevices','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11314','1411','Pyrethroid','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11315','1411','Carbamate','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11316','1411','Organophosphate','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11317','1411','Botanical','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11318','1412','An Insect Growth Regulators','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11319','1412','A mineral oil solvent','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11320','1412','Water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11321','1412','A surfactant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11322','1413','Plantscape treatment','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11323','1413','Seed treatment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11324','1413','Animal treatment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11325','1413','Research purposes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11326','1414','Attic rafters','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11327','1414','Pest droppings','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11328','1414','Grass clippings','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11329','1414','Garbage cans','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11330','1415','Flea','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11331','1415','Cockroach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11332','1415','Lice','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11333','1415','Lice','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11334','1416','Chagas Disease','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11335','1416','Malaria','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11336','1416','Tulameria','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11337','1416','Cat Scratch Fever','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11338','1417','Chelicera and Wing venation.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11339','1417','Peritiemes.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11340','1417','Chelicera.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11341','1417','Wing venation.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11342','1418','The body louse vectors typhus transmission','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11343','1418','The head louse vectors numerous diseases','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11344','1418','The head louse is found primarily on children','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11345','1418','The body louse is much larger','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11346','1419','Possible','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11347','1419','Critical','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11348','1419','Very great','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11349','1419','Impossible','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11350','1420','Organophosphates','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11351','1420','Metallics','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11352','1420','Botanicals','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11353','1420','Chlorinated Hydrocarbons','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11354','1421','Attic rafters','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11355','1421','Pest droppings','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11356','1421','Grass clippings','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11357','1421','Garbage cans','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11358','1422','Flea','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11359','1422','Spider','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11360','1422','Tick','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11361','1422','Black fly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11362','1423','Chagas Disease','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11363','1423','Malaria','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11364','1423','Tularemia','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11365','1423','Cat Scratch Fever','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11366','1424','American cockroach','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11367','1424','Dog tick','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11368','1424','Roof rat','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11369','1424','Culex Mosquito','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11370','1425','Chelicerae and Wing venation','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11371','1425','Peritiemes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11372','1425','Chelicerae','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11373','1425','Wing venation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11374','1426','Brown Dog Tick','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11375','1426','American Dog Tick','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11376','1426','Black Dog Tick','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11377','1426','Deer Tick','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11378','1427','Larval source reduction','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11379','1427','Draining marshes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11380','1427','Aerial spraying','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11381','1427','Aquatic applications','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11382','1428','Running water','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11383','1428','Animal manure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11384','1428','Stagnant pools','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11385','1428','Decaying vegetation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11386','1429','Treated by a physician','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11387','1429','Treated for pain only','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11388','1429','Treated at home','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11389','1429','Treated like other bites','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11390','1430','Size of droplet dispensed','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11391','1430','Concentration of pesticide used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11392','1430','Volume of pesticide delivered','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11393','1430','Ease of applicator use','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11394','1431','Sucking mouthparts','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11395','1431','Venom','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11396','1431','Stingers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11397','1431','Cannibalistic','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11398','1432','Bacterial disease','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11399','1432','Viral disease','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11400','1432','Fungal disease','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11401','1432','Protozoan disease','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11402','1433','Larval stage','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11403','1433','Adult stage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11404','1433','Pupae stage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11405','1433','Egg stage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11406','1434','Difficult to see','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11407','1434','Easy to see in flour','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11408','1434','Easy to see in fur','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11409','1434','Impossible to see','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11410','1435','Housefly','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11411','1435','Mosquito','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11412','1435','Screwworm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11413','1435','Black fly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11414','1436','Pediculocide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11415','1436','Conditioning shampoo','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11416','1436','Insecticide dust','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11417','1436','Acaricide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11418','1437','Red and Confused Flour Beetle','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11419','1437','Rice and Granary Weevil','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11420','1437','Grain and Flour Moth.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11421','1437','Alfalfa and Flour Weevil','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11422','1438','Attach eggs to body hair','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11423','1438','Transmit relapsing fever','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11424','1438','Highly mobile and infesting','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11425','1438','Look exactly alike','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11426','1439','To assure proper calibration of ULV spray machines, the operator must Pesticide concentration','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11427','1439','Droplet size','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11428','1439','Spray pressure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11429','1439','Flow rate','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11430','1440','Flea control','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11431','1440','Rodent control','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11432','1440','Predator control','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11433','1440','Environment manipulation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11434','1441','Different tactics','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11435','1441','Similar techniques','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11436','1441','Different pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11437','1441','Similar habitats','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11438','1442','Rarely establish  themselves in Arizona','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11439','1442','Occur only in rural higher elevation areas','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11440','1442','Are a serious plague problem in Arizona','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11441','1442','Are not rats or large rodents','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11442','1443','Swollen lymph nodes','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11443','1443','Dizziness','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11444','1443','Blurred vision','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11445','1443','Labored breathing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11446','1444','Obligate parasite','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11447','1444','Eggs attach to host','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11448','1444','Larvae suck blood','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11449','1444','Pupate for 1-2 days','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11450','1445','Egg, larvae, pupae and adult','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11451','1445','Egg, larvae, pupae and adult','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11452','1445','Egg, pupae, nymph and adult','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11453','1445','Egg, naiad, pupae and adult','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11454','1446','Special Local Needs label','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11455','1446','Emergency pest eradication program','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11456','1446','Public Health Emergency certification','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11457','1446','Arizona Health & Environmental Code','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11458','1447','Not important','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11459','1447','Extremely important','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11460','1447','Very important','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11461','1447','Somewhat important','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11462','1448','Soft and Hard','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11463','1448','Four-legged and Eight-legged','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11464','1448','Animal and Human','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11465','1448','Mites and Chiggers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11466','1449','Vectors of disease and Nuisance Pests','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11467','1449','Vectors of disease','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11468','1449','Crop pests','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11469','1449','Nuisance Pests','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11470','1450','Head Lice','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11471','1450','Book Lice','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11472','1450','Crab Lice','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11473','1450','Body Lice','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11474','1451','Number of legs','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11475','1451','Lack of wings','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11476','1451','Feeding behavior','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11477','1451','None of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11478','1452','Larvicide machine','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11479','1452','High volume fogger','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11480','1452','Mosquito fish','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11481','1452','Aerial sprayer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11482','1453','Predaceous','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11483','1453','Host specific','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11484','1453','General feeders','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11485','1453','Insectivorous','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11486','1454','Bubonic Plague','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11487','1454','Delusory parasitosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11488','1454','Arbraviral encephalitis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11489','1454','Mountain fever','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11490','1455','Used only for special Public Health purposes','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11491','1455','No longer used for any purpose in Arizona','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11492','1455','Used exclusively in agriculture by special permission','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11493','1455','Used to treat Head Lice and tick infestation only','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11494','1456','Insects','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11495','1456','Exclusively human feeders','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11496','1456','Found at high elevations only','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11497','1456','Aquatic in reproduction','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11498','1457','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11499','1457','Food supply','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11500','1457','Temperature','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11501','1457','Species of insect','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11502','1458','Curiosity','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11503','1458','Color','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11504','1458','Size','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11505','1458','Age','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11506','1459','Cool with a slight breeze','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11507','1459','Hot with predictable wind direction','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11508','1459','Cold with considerable windiness','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11509','1459','Very hot with no wind','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11510','1460','Feed on a variety of sources','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11511','1460','Take blood meals only','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11512','1460','Live exclusively in water as larva','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11513','1460','Fly only short distances','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11514','1461','Food storage cabinets','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11515','1461','The premises of the complaint','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11516','1461','Farm operations nearby','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11517','1461','Garbage collection procedures.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11518','1462','Read the labeling instructions','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11519','1462','Ensure proper equipment Calibration','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11520','1462','Contact your pesticide dealer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11521','1462','Select the application equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11522','1463','License holders','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11523','1463','Pesticide manufacturers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11524','1463','Pesticide dealers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11525','1463','The public','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11526','1464','Occurs over a long period of time','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11527','1464','Occurs almost immediately','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11528','1464','Refers to highly toxic pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11529','1464','Refers to non-toxic pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11530','1465','Chemical that controls the target pest and has toxicity','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11531','1465','Primary ingredient promoting effective pesticide dispersal','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11532','1465','The non-soluable portion of a finished mixture','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11533','1465','The proprietary, undisclosed ingredient on the label','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11534','1466','A basic knowledge of pest biology and behavior','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11535','1466','Using only the best, most up-to-date equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11536','1466','Knowledge of each pesticide available for use','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11537','1466','Possessing a license to do pest control business','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11538','1467','Never use more pesticide than the label allows','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11539','1467','Use higher than label rates of pesticides only when necessary','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11540','1467','Never apply herbicides close to a body of water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11541','1467','Use low pressure, low volume when applying pesticides on saturated soils','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11542','1468','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11543','1468','Mixing and loading of pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11544','1468','Equipment cleaning','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11545','1468','Disposal of pesticides and containers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11546','1469','1.20 ounces per gallon','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11547','1469','0.12 ounces per gallon','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11548','1469','0.83 ounces per gallon','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11549','1469','12.0 ounces per gallon.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11550','1470','3.60 ounces','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11551','1470','0.36 ounces.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11552','1470','2.49 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11553','1470','4.00 ounces','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11554','1471','The active ingredient','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11555','1471','The target pest','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11556','1471','The rate of application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11557','1471','The size of the site','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11558','1472','A pouring devices for the pesticides transported','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11559','1472','Impermeable coveralls','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11560','1472','A MSDS for each pesticide used by the business licensee','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11561','1472','Two-way communication equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11562','1473','Elevated threshold','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11563','1473','Biological control.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11564','1473','Mechanical control.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11565','1473','Improved Sanitation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11566','1474','Advanced first aid','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11567','1474','Correct product use','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11568','1474','Application areas','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11569','1474','Proper mixing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11570','1475','All of th the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11571','1475','Signs and symptoms of exposure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11572','1475','Emergency first aid procedures','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11573','1475','Health hazards','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11574','1476','Before mixing and applying the pesticide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11575','1476','Before purchasing application equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11576','1476','Transporting an unopened package of pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11577','1476','All of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11578','1477','Toxicity of the pesticide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11579','1477','Available application equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11580','1477','Possible applicator and public exposure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11581','1477','Possible environmental damage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11582','1478','One','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11583','1478','Two','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11584','1478','Three','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11585','1478','Four','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11586','1479','Food-source reduction','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11587','1479','Life-cycle disruption','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11588','1479','Drift','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11589','1479','Runoff','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11590','1480','72','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11591','1480','18','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11592','1480','36','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11593','1480','48','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11594','1481','Hit only the target pest','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11595','1481','Apply only to a labeled site','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11596','1481','Operate equipment safely','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11597','1481','Ensure active pest presence','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11598','1482','Delivering the proper amount of pesticide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11599','1482','The rate of pesticide application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11600','1482','The concentration of active ingredient','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11601','1482','Carefully measuring mixture ingredients','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11602','1483','Triple rinsed, punctured and sent for disposal in a sanitary landfill','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11603','1483','Placed in a sealed container and returned for recycling','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11604','1483','Wrapped in newspaper and discarded in a sanitary landfill','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11605','1483','Triple rinsed and re-used to hold only pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11606','1484','4.84','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11607','1484','0.0012','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11608','1484','1.279','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11609','1484','12.02','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11610','1485','2.00','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11611','1485','0.25','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11612','1485','1.00','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11613','1485','1.50','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11614','1486','Biological pesticide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11615','1486','Broad-spectrum pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11616','1486','Ready-to-use pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11617','1486','General aquatic pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11618','1487','Bacillus Thuringiensis','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11619','1487','Colloidal Fluoride','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11620','1487','Orthobiotic Bacillus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11621','1487','Aqueous Suspension','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11622','1488','Warning signs','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11623','1488','Original container','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11624','1488','Away from food & water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11625','1488','Away from feed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11626','1489','72','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11627','1489','12','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11628','1489','24','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11629','1489','96','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11630','1490','Are mechanical vectors','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11631','1490','Are not vectors','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11632','1490','Do not carry bacteria','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11633','1490','Carry viruses only','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11634','1491','Sucking','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11635','1491','Chewing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11636','1491','Lapping','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11637','1491','Sponging','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11638','1492','For about one month','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11639','1492','For about one day','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11640','1492','For about a week','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11641','1492','Until they take blood','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11642','1493','Midges','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11643','1493','Wasps','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11644','1493','Spiders','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11645','1493','Aphids','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11646','1494','10 miles','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11647','1494','<1 mile','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11648','1494','1 mile','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11649','1494','20 miles','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11650','1495','German','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11651','1495','Brown Banded','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11652','1495','American','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11653','1495','Oriental','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11654','1496','Aedes mosquitoes','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11655','1496','Midges','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11656','1496','Houseflies','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11657','1496','Anopheles mosquitoes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11658','1497','They never get a chance to eat it','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11659','1497','They never get a chance to eat it','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11660','1497','They do not live around dumps','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11661','1497','They do not live around dumps','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11662','1498','Alternative treatments','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11663','1498','Trade name','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11664','1498','Signal word','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11665','1498','Active ingredient','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11666','1499','Risk','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11667','1499','Acute toxicity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11668','1499','Chronic illness','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11669','1499','Pesticide residue','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11670','1500','Effectiveness','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11671','1500','Wildlife','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11672','1500','Non-target plants and insects','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11673','1500','Water quality','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11674','1501','After the restricted entry interval and If wearing the proper PPE','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11675','1501','After the pesticide has dried','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11676','1501','After the restricted entry interval','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11677','1501','If wearing the proper PPE','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11678','1502','Cultural controls','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11679','1502','Pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11680','1502','Air pollution','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11681','1502','Natural gas leaks','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11682','1503','Back siphoning','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11683','1503','Too much pressure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11684','1503','Too little pressure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11685','1503','Pesticide pooling','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11686','1504','Broadcast','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11687','1504','Drench','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11688','1504','Foliar','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11689','1504','Soil incorporated','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11690','1505','Drench','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11691','1505','Broadcast','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11692','1505','Foliar','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11693','1505','Soil incorporated','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11694','1506','Spot Treatment','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11695','1506','Broadcast','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11696','1506','Drench','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11697','1506','Foliar','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11698','1507','Volatilization','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11699','1507','Leaching','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11700','1507','Biodegradation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11701','1507','Drift','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11702','1508','Soil incorporated','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11703','1508','Broadcast','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11704','1508','Drench','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11705','1508','Foliar','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11706','1509','Foliar','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11707','1509','Broadcast','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11708','1509','Drench','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11709','1509','Soil incorporated','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11710','1510','Dry','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11711','1510','Small','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11712','1510','Stressed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11713','1510','Unfertilized','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11714','1511','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11715','1511','Nozzles','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11716','1511','Overlap','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11717','1511','Pressure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11718','1512','Wear and tear of equipment','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11719','1512','PPE','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11720','1512','Weight of pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11721','1512','Active ingredient','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11722','1513','The limitations on the amount applied per growing season','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11723','1513','Tell how much area the contents will treat','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11724','1513','The only target pests the pesticide can be used on','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11725','1513','All of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11726','1514','When penetration is essential and When drift is not a major concern','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11727','1514','When penetration is essential','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11728','1514','When price is the only reason for spraying','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11729','1514','When drift is not a major concern','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11730','1515','Ornamentals and turf could be damaged with the wrong nozzle','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11731','1515','You could spend too much money on chemicals','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11732','1515','Could get too little drift and damage non-target species','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11733','1515','All of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11734','1516','Fogger','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11735','1516','Hand sprayer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11736','1516','High pressure sprayer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11737','1516','Low pressure boom sprayer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11738','1517','Hand sprayer','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11739','1517','High pressure sprayer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11740','1517','Low pressure boom sprayer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11741','1517','Drop spreader','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11742','1518','Twin flat spray and hollow-cone','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11743','1518','Broadcast and off center','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11744','1518','Hollow-cone and flooding flat-fan','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11745','1518','Flat-fan and broadcast','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11746','1519','Drop, Rotary','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11747','1519','Gang, Rotary','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11748','1519','Rotary, Drop','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11749','1519','Drop, Gang','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11750','1520','6358 sq.ft.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11751','1520','4300 sq.ft.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11752','1520','6121 sq.ft.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11753','1520','7569 sq.ft.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11754','1521','6 oz.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11755','1521','7 oz.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11756','1521','12 oz.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11757','1521','18 oz.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11758','1522','Ground pearl','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11759','1522','Cutworm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11760','1522','Frit fly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11761','1522','Mite','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11762','1523','Mite','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11763','1523','Ground pearl','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11764','1523','Cutworm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11765','1523','Frit fly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11766','1524','Cutworm','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11767','1524','Ground pearl','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11768','1524','White grub','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11769','1524','Frit fly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11770','1525','Frit fly','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11771','1525','Ground pearl','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11772','1525','Cutworm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11773','1525','Mite','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11774','1526','Spider mites','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11775','1526','Aphids','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11776','1526','Phytophthora','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11777','1526','None of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11778','1527','Rove beetle','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11779','1527','Cutworm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11780','1527','Billbug','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11781','1527','White grubs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11782','1528','June beetle','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11783','1528','Sod webworm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11784','1528','Flea beetle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11785','1528','Rove beetle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11786','1529','Chinch bugs','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11787','1529','Pearl scale','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11788','1529','Ants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11789','1529','Mole crickets','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11790','1530','White grub','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11791','1530','White fly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11792','1530','Mites','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11793','1530','Aphids','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11794','1531','Plant juices in the root zone','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11795','1531','Green portions of the crown','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11796','1531','Inflorescence of the turf','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11797','1531','Tips of leaves','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11798','1532','Exoskeleton','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11799','1532','Endoskeleton','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11800','1532','Interior skeleton','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11801','1532','No skeleton','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11802','1533','White grub','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11803','1533','Ground pearl','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11804','1533','Cutworm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11805','1533','Frit fly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11806','1534','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11807','1534','Die-back or stunting','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11808','1534','Distortion of growth','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11809','1534','Browning or yellowing of leaves','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11810','1535','Mounds of soil on the turf surface.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11811','1535','Bird activity on the turf.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11812','1535','June beetles are a nuisance to golfers.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11813','1535','Turf is ripped up at night by skunks.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11814','1536','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11815','1536','Ants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11816','1536','Chinch bug','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11817','1536','Cutworm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11818','1537','Plant sucking insects','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11819','1537','Leaf chewing insects','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11820','1537','Root feeding insects','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11821','1537','None of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11822','1538','None of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11823','1538','Pear-shaped','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11824','1538','Winged or wingless','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11825','1538','Have needle-like mouthparts','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11826','1539','Thrips','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11827','1539','Mealybugs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11828','1539','Scale','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11829','1539','Aphids','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11830','1540','White grubs','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11831','1540','Ground pearl scale','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11832','1540','Aphids','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11833','1540','Caterpillar','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11834','1541','Parasitic wasp','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11835','1541','Big-headed wasp','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11836','1541','Assassin bug','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11837','1541','Leafhopper','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11838','1542','Billbug','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11839','1542','Chinch bug','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11840','1542','Palo verde bark carver','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11841','1542','Vegetable weevil','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11842','1543','Spider mites','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11843','1543','Leaf mites','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11844','1543','Lady bug larva','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11845','1543','Whiteflies','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11846','1544','Sod webworm','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11847','1544','Cutworm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11848','1544','Caterpillar','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11849','1544','Vegetable weevil','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11850','1545','Palo verde beetle','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11851','1545','Black bark beetle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11852','1545','Cypress bark beetle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11853','1545','Big eyed beetle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11854','1546','Chinch bug','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11855','1546','Billbug','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11856','1546','Flea beetle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11857','1546','Aphid','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11858','1547','Lacewing','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11859','1547','Flea beetle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11860','1547','Leafhopper','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11861','1547','Chinch bug','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11862','1548','Ladybug','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11863','1548','Assassin bug','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11864','1548','Big eyed bug','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11865','1548','Chinch bug','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11866','1549','Thrip','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11867','1549','Cicada','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11868','1549','Leafcutter bee','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11869','1549','Winged borer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11870','1550','Cutworm','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11871','1550','White grub','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11872','1550','Caterpillar','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11873','1550','Sod webworm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11874','1551','Leafhopper','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11875','1551','Sod webworm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11876','1551','Vegetable weevil','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11877','1551','Lacewing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11878','1552','Aphid','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11879','1552','Ladybug','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11880','1552','Spider mite','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11881','1552','Leafhopper','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11882','1553','Virus','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11883','1553','Bacteria','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11884','1553','Fungus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11885','1553','Mycoplasma','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11886','1554','Nematode','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11887','1554','Fungus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11888','1554','Mycoplasma','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11889','1554','Virus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11890','1555','Fusarium blight','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11891','1555','Melting out','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11892','1555','Pythium blight','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11893','1555','Brown patch','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11894','1556','Fungus','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11895','1556','Bacteria','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11896','1556','Mycoplasma','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11897','1556','Nematode','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11898','1557','Bacteria','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11899','1557','Fungus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11900','1557','Mycoplasma','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11901','1557','Nematode','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11902','1558','Symptoms','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11903','1558','Host','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11904','1558','Primary Causal Agent','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11905','1558','Favorable Environment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11906','1559','Agrobacterium','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11907','1559','Phytophthora','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11908','1559','Rhizoctonia','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11909','1559','Verticillium','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11910','1560','Verticillium wilt','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11911','1560','Trunk borers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11912','1560','Mosaic','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11913','1560','White fly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11914','1561','Strong, steady breeze','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11915','1561','Wet, humid weather','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11916','1561','Poor drainage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11917','1561','Frequent irrigation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11918','1562','Shade trees','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11919','1562','Cactus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11920','1562','Chickens','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11921','1562','Insects','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11922','1563','Twigs and branches','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11923','1563','Roots and crown','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11924','1563','Vascular system','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11925','1563','All of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11926','1564','Chemical treatment of growing plants','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11927','1564','Crop rotation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11928','1564','Use of resistant varieties','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11929','1564','Use of certified seed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11930','1565','Seedling','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11931','1565','Vegetative','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11932','1565','Seed production','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11933','1565','Maturity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11934','1566','Chemical treatment','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11935','1566','Crop rotation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11936','1566','Use of resistant varieties','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11937','1566','Use of certified seed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11938','1567','Accurate diagnosis of pests.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11939','1567','Habitat modification','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11940','1567','Using pesticides periodically','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11941','1567','All of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11942','1568','Using viruses and bacteria to control a pest.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11943','1568','Using screens to exclude mosquitoes.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11944','1568','USDA Quarantine Station.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11945','1568','Planting and harvesting dates.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11946','1569','Elevated threshhold','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11947','1569','Selective use of pesticides.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11948','1569','Use of natural enemies.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11949','1569','Detailed record-keeping','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11950','1570','Dusk','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11951','1570','Dawn','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11952','1570','Mid-morning','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11953','1570','Early afternoon','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11954','1571','Only the portion of the plant contacted','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11955','1571','The whole plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11956','1571','The roots of the plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11957','1571','Only adjacent plants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11958','1572','Growth regulator','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11959','1572','Anti-transpirant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11960','1572','Phytotoxic product','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11961','1572','Adjuvant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11962','1573','Liquid formulations of pesticides','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11963','1573','Dry formulations of pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11964','1573','Fumigants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11965','1573','Insect baits','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11966','1574','The chemical is absorbed and translocated','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11967','1574','The chemical is very strong.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11968','1574','The chemical does not degrade.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11969','1574','The chemical is applied several times per week.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11970','1575','Nothing','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11971','1575','Oil','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11972','1575','Water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11973','1575','Solvents','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11974','1576','Insect','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11975','1576','Bacteria','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11976','1576','Fungus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11977','1576','Virus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11978','1577','Melting Out','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11979','1577','Brown Patch','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11980','1577','Fire Ring','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11981','1577','Fusarium Blight','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11982','1578','Printed information attached to the pesticide container','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11983','1578','Material safety data sheets and safety information','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11984','1578','Product-specific brochures provided by manufacturers or dealers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11985','1578','Printed information attached to the pesticide container  and Material safety data sheets and safety information','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11986','1579','Deadly','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11987','1579','Danger','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11988','1579','Warning','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11989','1579','Caution','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11990','1580','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11991','1580','How much to use','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11992','1580','The target pest','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11993','1580','Application limitations','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11994','1581','Generic name of the active ingredient','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11995','1581','Manufacturer’s name','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11996','1581','Type of formulation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11997','1581','Pesticide family name','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11998','1582','Target pests','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('11999','1582','Trade name','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12000','1582','Common name','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12001','1582','First aid','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12002','1583','Product effectiveness','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12003','1583','Non-target plants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12004','1583','Water quality','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12005','1583','Wildlife habitat','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12006','1584','After the restricted entry interval','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12007','1584','At any time following treatment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12008','1584','Once the pesticide is dry','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12009','1584','Only if you are wearing PPE','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12010','1585','Application equipment','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12011','1585','Pesticidal properties','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12012','1585','Soil constituents','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12013','1585','Site conditions','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12014','1586','Causes permanent damage such as infertility','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12015','1586','Occurs soon after exposure for a short duration','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12016','1586','Is high toxicity causing immediate illness','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12017','1586','Is indicated on pesticide containers by the signal word','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12018','1587','Mixing and loading','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12019','1587','Pesticide application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12020','1587','Equipment cleanup','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12021','1587','Equipment calibration','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12022','1588','Rate of application','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12023','1588','Clogged spray nozzles','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12024','1588','Amount of spray overlap','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12025','1588','Application spray pressure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12026','1589','Spot','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12027','1589','Broadcast','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12028','1589','Drench','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12029','1589','Foliar','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12030','1590','Back siphoning','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12031','1590','Too much pressure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12032','1590','Too little pressure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12033','1590','Broken nozzle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12034','1591','Drench','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12035','1591','Broadcast','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12036','1591','Foliar','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12037','1591','Soil incorporated','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12038','1592','Increased pesticide cost','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12039','1592','Potential ornamental damage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12040','1592','Decreased risk of drift','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12041','1592','Pesticide active ingredient','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12042','1593','Respirator','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12043','1593','Goggles','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12044','1593','Gloves','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12045','1593','Boots','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12046','1594','Hand sprayer','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12047','1594','High pressure sprayer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12048','1594','Low pressure boom sprayer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12049','1594','Drop spreader','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12050','1595','Ears','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12051','1595','Skin','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12052','1595','Mouth','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12053','1595','Eyes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12054','1596','Equipment wear and tear','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12055','1596','Personal protective equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12056','1596','Weight of  finished pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12057','1596','None of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12058','1597','When the concentration is doubled','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12059','1597','When application site changes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12060','1597','When using long stored equipment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12061','1597','When a nozzle is changed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12062','1598','1/2','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12063','1598','1/8','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12064','1598','1/4','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12065','1598','1/3','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12066','1599','6 oz.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12067','1599','7 oz.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12068','1599','12 oz.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12069','1599','18 oz.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12070','1600','(b x h)/2','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12071','1600','l x w','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12072','1600','{(a + b)/2} x h','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12073','1600','(b + h)/2','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12074','1601','Quadruple the pressure','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12075','1601','Double vehicle speed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12076','1601','Double the concentration','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12077','1601','Triple the pump size','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12078','1602','5,000 square feet','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12079','1602','300 square feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12080','1602','1,000 square feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12081','1602','2,500 square feet','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12082','1603','Microscopic eyes','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12083','1603','Six legs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12084','1603','Three body regions','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12085','1603','One pair of antennae','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12086','1604','Plant juices in the root zone','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12087','1604','Green portions of the crown','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12088','1604','Inflorescence of the turf','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12089','1604','Tips of leaves','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12090','1605','Exoskeleton','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12091','1605','Endoskeleton','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12092','1605','Ectoskeleton','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12093','1605','No skeleton','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12094','1606','Gradual metamorphosis','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12095','1606','Complete metamorphosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12096','1606','Incomplete metamorphosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12097','1606','Progressive metamorphosis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12098','1607','Ant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12099','1607','Cutworm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12100','1607','Aphid','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12101','1607','White grub','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12102','1608','Aphid','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12103','1608','Lady bug larva','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12104','1608','Spider mite','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12105','1608','White fly larva','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12106','1609','Parasitic wasp','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12107','1609','Big-headed wasp','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12108','1609','Assassin bug','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12109','1609','Leafhopper','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12110','1610','Caterpillar','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12111','1610','White grub','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12112','1610','Round borer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12113','1610','Thrip','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12114','1611','Thrip','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12115','1611','Cicada','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12116','1611','Leafcutter bee','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12117','1611','Winged borer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12118','1612','Cutworm','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12119','1612','White grub','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12120','1612','Caterpillar','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12121','1613','Symptoms','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12122','1613','Host','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12123','1613','Primary Causal Agent','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12124','1613','Favorable Environment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12125','1614','Strong, steady breeze','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12126','1614','Wet, humid weather','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12127','1614','Poor drainage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12128','1614','Frequent irrigation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12129','1615','Fungi','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12130','1615','Bacteria','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12131','1615','Viruses','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12132','1615','Nematodes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12133','1616','Fungi','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12134','1616','Bacteria','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12135','1616','Viruses','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12136','1616','Nematodes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12137','1617','Melting-out','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12138','1617','Gray snow mold','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12139','1617','Dollar spot','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12140','1617','Brown patch','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12141','1618','Powdery mildew','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12142','1618','Slime mold','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12143','1618','Fire blight','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12144','1618','Crown gall','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12145','1619','Rose virus','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12146','1619','Fire blight','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12147','1619','Rust','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12148','1619','Slime mold','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12149','1620','Leaf cuticle','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12150','1620','Root hairs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12151','1620','Water conducting tissue','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12152','1620','Food conducting tissue','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12153','1621','Dictates the threshold at which treatment should begin','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12154','1621','Allows for use of environmental factors in controlling the pest','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12155','1621','Allows timing of treatment to coincide with vulnerable life stage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12156','1621','Allows for determining which controls and actions are necessary','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12157','1622','Chemigation utilization','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12158','1622','Ornamental plant rotation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12159','1622','Resistant variety selection','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12160','1622','Certified seed use','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12161','1623','Accurate pest identification','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12162','1623','Early morning applications','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12163','1623','Regular pesticide use','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12164','1623','Habitat modification','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12165','1624','Adjuvant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12166','1624','Growth regulator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12167','1624','Anti-transpirant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12168','1624','Phytotoxic substrate','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12169','1625','Increase pest repellence','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12170','1625','Increase plant bloomage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12171','1625','Reduce labor costs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12172','1625','Reduce root rush','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12173','1626','Beneficial insects','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12174','1626','Insect traps','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12175','1626','Botanical pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12176','1626','Proper pruning','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12177','1627','Preventative maintenance','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12178','1627','Selective maintenance','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12179','1627','Selective maintenance','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12180','1627','Integrated maintenance','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12181','1628','Growth regulator','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12182','1628','Anti-transpirant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12183','1628','Phytotoxic substrate','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12184','1628','Adjuvant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12185','1629','The pesticide is translocated within the plant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12186','1629','The pesticide residual is very strong','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12187','1629','The pesticide does not easily degrade','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12188','1630','Nematicide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12189','1630','Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12190','1630','Insecticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12191','1630','Fungicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12192','1631','Systemic poison','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12193','1631','Contact poison','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12194','1631','Stomach poison','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12195','1631','Foliar poison','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12196','1632','Emulsifiable concentrate','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12197','1632','Flowable','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12198','1632','Wettable powder','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12199','1632','Granule','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12200','1633','The finished concentration','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12201','1633','The vegetation being treated','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12202','1633','The pest being controlled','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12203','1633','The formulation being used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12204','1634','Apply pesticide to the target','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12205','1634','Decrease applicator exposure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12206','1634','Reduce or eliminate drift','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12207','1634','Reduce the toxicity of pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12208','1635','Is the chemical that has toxicity','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12209','1635','The soluble  portion of a mixture','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12210','1635','Allows for effective dispersement','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12211','1635','Degrades quickly without additives','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12212','1636','Custom mixing of pesticides for effectiveness','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12213','1636','A basic knowledge of pests and pest problems','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12214','1636','The ability to choose the right pesticide and equipment.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12215','1636','Knowledge of proper methods of application.','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12216','1637','Pump','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12217','1637','Tank','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12218','1637','Hose','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12219','1637','Connectors','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12220','1638','Never use more pesticide than the label permits','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12221','1638','Maintain an air gap between the fill hose and tank','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12222','1638','Never apply herbicides too close to a body of water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12223','1638','Use low pressure, low volume when applying to saturated soil','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12224','1639','Installing backflow prevention','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12225','1639','Mixing and loading','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12226','1639','Equipment cleaning','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12227','1639','Disposal of containers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12228','1640','Serious injury','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12229','1640','Under dosing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12230','1640','Leftover mix','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12231','1640','Over dosing','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12232','1641','Spill containment material to contain a minimum 25 gallon spill','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12233','1641','Personal protective equipment as required for all pesticides on the service vehicle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12234','1641','Pouring devices for the pesticides stored and transported on the service vehicle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12235','1641','MSDS for each pesticide transported or stored on the service vehicle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12236','1642','Where to apply the pesticide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12237','1642','Alternative treatment strategies','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12238','1642','Target pest resistance','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12239','1642','Only Target pest resistance  and Where to apply the pesticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12240','1643','Signs and symptoms of exposure','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12241','1643','Long-term first aid procedures','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12242','1643','Container disposal instructions','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12243','1643','All of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12244','1644','Promotes applicator safety','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12245','1644','Neutralizes pesticide toxicity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12246','1644','Prevents pesticide inhalation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12247','1644','Permits prolonged exposure','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12248','1645','Particle size','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12249','1645','Pump speed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12250','1645','Mixture concentration','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12251','1645','All of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12252','1646','72 hours in advance of any pesticide application','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12253','1646','18 hours in advance of any pesticide application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12254','1646','36 hours in advance of any pesticide application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12255','1646','48 hours in advance of any pesticide application','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12256','1647','The date and time the application is to occur','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12257','1647','Name of the applicator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12258','1647','Signs for the schools to post','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12259','1647','Records of previous pesticide treatments','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12260','1648','Fire Ring','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12261','1648','Melting Out','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12262','1648','Brown Patch','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12263','1648','Fusarium Blight','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12264','1649','White grub','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12265','1649','Ground pearl','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12266','1649','Frit fly','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12267','1649','Cutworm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12268','1650','Insects','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12269','1650','Bacteria','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12270','1650','Mycoplasma & virus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12271','1650','Fungus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12272','1651','Brown Patch','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12273','1651','Melting Out','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12274','1651','Fire Ring','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12275','1651','Fusarium Blight','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12276','1652','Acaricide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12277','1652','Insecticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12278','1652','Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12279','1652','Fungicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12280','1653','Nematicide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12281','1653','Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12282','1653','Fungicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12283','1653','Insecticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12284','1654','Fusarium Blight','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12285','1654','Melting Out','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12286','1654','Brown Patch','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12287','1654','Greasy Spot','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12288','1655','Systemic poison','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12289','1655','Contact poison','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12290','1655','Stomach poison','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12291','1655','Fumigant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12292','1656','Increased dosage rates','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12293','1656','Decreased dosage rates','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12294','1656','Only soluble materials to be used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12295','1656','Only insoluble materials to be used','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12296','1657','Broadcast','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12297','1657','Foliar','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12298','1657','Drench','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12299','1657','Soil incorporate','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12300','1658','Fungicide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12301','1658','Acaricide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12302','1658','Insecticide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12303','1658','Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12304','1659','Dollar Spot','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12305','1659','Brown Patch','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12306','1659','Greasy Spot','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12307','1659','Fusarium Blight','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12308','1660','Adjuvant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12309','1660','Plant growth regulator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12310','1660','Phytotoxic product','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12311','1660','Anti-transpirant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12312','1661','Pesticidal treatments','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12313','1661','Crop rotation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12314','1661','Use of resistant varieties','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12315','1661','Use of certified seed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12316','1662','Bacteria','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12317','1662','Mycoplasma','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12318','1662','Fungus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12319','1662','Nematode','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12320','1663','Nematode','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12321','1663','Fungus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12322','1663','Mycoplasma','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12323','1663','Virus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12324','1664','Phytotoxic product','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12325','1664','Plant growth regulator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12326','1664','Anti-transpirant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12327','1664','Adjuvant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12328','1665','Frit fly','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12329','1665','Ground pearl','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12330','1665','Cutworm','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12331','1665','Mite','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12332','1666','Anti-transpirant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12333','1666','Plant growth regulator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12334','1666','Desiccant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12335','1666','Defoliant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12336','1667','Perennials and biennials','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12337','1667','Perennials','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12338','1667','Biennials','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12339','1667','Annuals','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12340','1668','Bacteria','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12341','1668','Mycoplasma','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12342','1668','Fungus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12343','1668','Nematode','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12344','1936','Monocot','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12345','1936','Summer Annual','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12346','1936','Winter Annual','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12347','1936','Dicot','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12348','1937','Have reduced activity','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12349','1937','Increase in activity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12350','1937','Have no activity whatsoever','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12351','1937','Not be affected','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12352','1938','Perennial Plant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12353','1938','Annual Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12354','1938','Biennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12355','1938','Evergreen Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12356','1939','Leaf cuticle','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12357','1939','Root hairs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12358','1939','Water conducting tissue','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12359','1939','Food conducting tissue','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12360','1940','Saturate','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12361','1940','Surface water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12362','1940','Recharge','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12363','1940','Aquifer','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12364','1941','Noxious Weed','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12365','1941','Summer Annual','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12366','1941','Winter Annual','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12367','1941','Dicot','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12368','1942','Contact','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12369','1942','Non-Selective','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12370','1942','Translocated','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12371','1942','Selective','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12372','1943','Any plant growing where it is not wanted','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12373','1943','Bermuda grass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12374','1943','A plant on which you spray pesticides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12375','1943','None of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12376','1944','Non-Selective Herbicide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12377','1944','Translocated Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12378','1944','Contact Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12379','1944','Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12380','1945','Evergreen Plant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12381','1945','Annual Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12382','1945','Biennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12383','1945','Perennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12384','1946','Dicot','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12385','1946','Summer Annual','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12386','1946','Winter Annual','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12387','1946','Monocot','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12388','1947','Soil Sterilant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12389','1947','Pre-Emergence Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12390','1947','Preplant Treatment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12391','1947','Post-Emergence Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12392','1948','Translocated Herbicide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12393','1948','Non-Selective Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12394','1948','Contact Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12395','1948','Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12396','1949','Water and temperature','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12397','1949','Primary causal agents','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12398','1949','Nutrients','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12399','1949','Light levels','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12400','1950','Winter Annual','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12401','1950','Monocot','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12402','1950','Summer Annual','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12403','1950','Dicot','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12404','1951','Compatability','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12405','1951','Phytotoxicity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12406','1951','Potentation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12407','1951','Suseptible Species','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12408','1952','Physical','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12409','1952','Symbiotic','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12410','1952','Periodic','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12411','1952','Continuous','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12412','1953','Degrades','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12413','1953','Is unchanged','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12414','1953','Increases toxicity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12415','1953','Is persistent','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12416','1954','Eradication','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12417','1954','Avoidance','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12418','1954','Exclusion','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12419','1954','Protection','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12420','1955','Evergreen Plant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12421','1955','Annual Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12422','1955','Biennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12423','1955','Perennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12424','1956','Summer Annual','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12425','1956','Winter Annual','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12426','1956','Monocot','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12427','1956','Dicot','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12428','1957','Phytotoxicity','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12429','1957','Compatibility','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12430','1957','Potentiation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12431','1957','Photosynthesis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12432','1958','Post-Emergence Herbicide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12433','1958','Pre-Emergence Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12434','1958','Preplant Treatment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12435','1958','Broad-spectrum Treatment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12436','1959','Systemic','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12437','1959','Contact','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12438','1959','Stomach','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12439','1959','Insect growth regulator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12440','1960','Annual Plant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12441','1960','Biennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12442','1960','Perennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12443','1960','Evergreen Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12444','1961','Annual Plant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12445','1961','Biennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12446','1961','Perennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12447','1961','Evergreen Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12448','1962','Winter Annual','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12449','1962','Perennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12450','1962','Biennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12451','1962','Summer Annual','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12452','1963','Susceptible Species','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12453','1963','Compatibility','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12454','1963','Phytotoxicity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12455','1963','Potentiation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12456','1964','Selective Herbicide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12457','1964','Translocated Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12458','1964','Contact Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12459','1964','Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12460','1965','Deciduous Plant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12461','1965','Annual Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12462','1965','Biennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12463','1965','Perennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12464','1966','Herbicide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12465','1966','Non-Selective Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12466','1966','Translocated Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12467','1966','Contact Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12468','1967','Annual Plant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12469','1967','Biennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12470','1967','Perennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12471','1967','Deciduous Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12472','1968','Annual Plant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12473','1968','Biennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12474','1968','Perennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12475','1968','Deciduous Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12476','1969','Deciduous Plant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12477','1969','Annual Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12478','1969','Biennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12479','1969','Perennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12480','1970','Phytotoxic','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12481','1970','Residual','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12482','1970','Translocatible','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12483','1970','All of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12484','1971','How much to use','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12485','1971','The only target pests it can be used on','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12486','1971','Minimum amount that may be legally applied','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12487','1971','All of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12488','1972','Pre-Emergence Herbicide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12489','1972','Preplant Treatment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12490','1972','Post-Emergence Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12491','1972','Soil Sterilant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12492','1973','Perennial Plant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12493','1973','Annual Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12494','1973','Biennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12495','1973','Deciduous Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12496','1974','Perennial Plant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12497','1974','Annual Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12498','1974','Biennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12499','1974','Deciduous Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12500','1975','Preplant Treatment','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12501','1975','Pre-Emergence Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12502','1975','Post-Emergence Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12503','1975','Residual Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12504','1976','Activate soil applied materials','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12505','1976','Activate foliar applied materials','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12506','1976','Cause all herbicides to become active','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12507','1976','Have the herbicide absorbed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12508','1977','Annual Plant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12509','1977','Biennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12510','1977','Perennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12511','1977','Evergreen Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12512','1978','Potentation','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12513','1978','Compatibility','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12514','1978','Phytotoxicity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12515','1978','Residue','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12516','1979','Pre-Emergence Herbicide','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12517','1979','Preplant Treatment','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12518','1979','Post-Emergence Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12519','1979','Residual Herbicide','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12520','1980','Using viruses and bacteria to control a pest','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12521','1980','Using screens to exclude mosquitoes','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12522','1980','USDA Quarantine Stations','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12523','1980','Planting and harvesting dates','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12524','1981','Necrosis','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12525','1981','Abnormal physiology','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12526','1981','Flowers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12527','1981','Injury','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12528','1982','Residual','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12529','1982','Potentation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12530','1982','Compatibility','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12531','1982','Phytotoxicity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12532','1983','Annual Plant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12533','1983','Biennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12534','1983','Perennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12535','1983','Deciduous Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12536','1984','Biennial Plant','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12537','1984','Annual Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12538','1984','Perennial Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12539','1984','Deciduous Plant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12540','1985','4 lbs','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12541','1985','1 1/2 lb','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12542','1985','2 1/4 lbs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12543','1985','3 lbs','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12544','1986','a. Never use more pesticide than the label allows','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12545','1986','b. Use high-pressure, high-volume when applying pesticides on saturated soils','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12546','1986','c. Never apply herbicides close to a body of water','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12547','1986','d. Use low-pressure, low-volume when applying pesticides on saturated soils','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12548','1987','Pump','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12549','1987','Hose','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12550','1987','Agitator','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12551','1987','Nozzle','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12552','1988','Nothing.','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12553','1988','Oil','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12554','1988','Water conducting tissue','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12555','1988','Fertilizers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12556','1989','Plant growth regulator','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12557','1989','Anti-transpirant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12558','1989','Phytotoxic product','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12559','1989','Adjuvant','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12560','1990','DrenchBroadcast','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12561','1990','Foliar','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12562','1990','Soil-incorporated','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12563','1991','Crabgrass','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12564','1991','Annual bluegrass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12565','1991','Bermudagrass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12566','1991','Tall fescue','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12567','1992','Prostrate spurge','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12568','1992','Puncturevine','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12569','1992','Oxalis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12570','1992','Common chickweed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12571','1993','Nutsedge','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12572','1993','Crabgrass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12573','1993','Bermudagrass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12574','1993','Tall fescue','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12575','1994','Bermudagrass','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12576','1994','Crabgrass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12577','1994','Tall fescue','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12578','1994','Annual bluegrass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12579','1995','Dandelion','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12580','1995','Malva','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12581','1995','London rocket','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12582','1995','Nightshade','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12583','1996','White clover','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12584','1996','Khakiweed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12585','1996','Oxalis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12586','1996','Prostrate spurge','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12587','1997','Tall fescue','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12588','1997','Crabgrass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12589','1997','Bermudagrass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12590','1997','Annual bluegrass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12591','1998','Annual bluegrass','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12592','1998','Tall fescue','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12593','1998','Crabgrass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12594','1998','Bermudagrass','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12595','1999','Malva','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12596','1999','Dandelion','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12597','1999','London rocket','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12598','1999','Nightshade','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12599','2000','Puncturevine','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12600','2000','Oxalis','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12601','2000','Prostrate spurge','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12602','2000','Common chickweed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12603','2001','Oxalis','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12604','2001','Puncturevine','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12605','2001','Prostrate spurge','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12606','2001','Common chickweed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12607','2002','London rocket','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12608','2002','Dandelion','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12609','2002','Malva','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12610','2002','Nightshade','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12611','2003','Seedling','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12612','2003','Vegetative','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12613','2003','Seed production','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12614','2003','Maturity','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12615','2004','Reduce plant ability to absorb herbicides','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12616','2004','Increase plant ability to absorb herbicides','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12617','2004','Have no influence upon herbicide absorption','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12618','2004','Are present only on broadleaved species','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12619','2005','All of the answers','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12620','2005','It allows for timing treatment to coincide with the pest’s vulnerable life stage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12621','2005','It assists in determine if controls are necessary and what action should be taken','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12622','2005','It provides clues as to the environment of infestation at a particular life stage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12623','2006','Chemical treatment of growing plants','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12624','2006','Crop rotation','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12625','2006','Use of resistant varieties','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12626','2006','Use of certified seed','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12627','2007','Accurate diagnosis of pests','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12628','2007','Use of restricted products','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12629','2007','Periodic pesticide applications','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12630','2007','All of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12631','2008','Glyphosate','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12632','2008','Phosphorus','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12633','2008','Ammonium','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12634','2008','Methyl salt','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12635','2009','9.6','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12636','2009','4.8','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12637','2009','14.4','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12638','2009','28.8','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12639','2010','1.30','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12640','2010','0.32','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12641','2010','0.64','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12642','2010','6.40','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12643','2011','Use product when wind speeds are less than 5mph only','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12644','2011','Refrain from use during temperature inversions','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12645','2011','Apply from a height of less than 10 feet above plants','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12646','2011','Use as few high flow rate nozzles as needed for coverage','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12647','2012','15','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12648','2012','5','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12649','2012','10','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12650','2012','20','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12651','2013','Annual grasses','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12652','2013','Broadleaf weeds','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12653','2013','Flowering perennials','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12654','2013','All of the answers','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12655','2014','1.8','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12656','2014','1.3','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12657','2014','2.6','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12658','2014','3.6','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12659','2015','0.4','','1');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12660','2015','1.2','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12661','2015','2.1','','0');
INSERT INTO `answer` (`uid`,`questionnaires_uid`,`answer`,`images`,`type`) VALUES ('12662','2015','3.3','','0');
/*!40000 ALTER TABLE `answer` ENABLE KEYS */;


--
-- Create Table `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles` (
  `articles_id` int(11) NOT NULL AUTO_INCREMENT,
  `articles_name` varchar(255) NOT NULL,
  `articles_content` longtext NOT NULL,
  `articles_status` int(11) DEFAULT NULL,
  PRIMARY KEY (`articles_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Data for Table `articles`
--

/*!40000 ALTER TABLE `articles` DISABLE KEYS */;
INSERT INTO `articles` (`articles_id`,`articles_name`,`articles_content`,`articles_status`) VALUES ('2','How Pestest Works','<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\">\n	<tbody>\n		<tr>\n			<td>\n			<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\n				<tbody>\n					<tr>\n						<td>\n						<div style=\"text-align: justify;\"><span style=\"font-size:16px\"><strong><strong>How Pestest.com works:</strong></strong><br />\n						<br />\n						<br />\n						<strong>1. Take the practice exam.</strong><br />\n						The questions are randomly generated and very similar to the state test.<br />\n						<br />\n						<strong>2. Review the questions you have missed.</strong><br />\n						After reviewing the answers, you can choose to retake only the questions you have missed.<br />\n						<br />\n						<strong>3. Know which categories you are struggling with.</strong><br />\n						PesTesT can generate questions on any particular category you are having trouble with.<br />\n						<br />\n						<strong>4. Take the full exam again.</strong><br />\n						Observe your score improve significantly with every retake of the practice exam.</span></div>\n						<br />\n						<br />\n						 </td>\n						<td>\n						<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" style=\"width:100%\">\n							<tbody>\n								<tr>\n									<td><img alt=\"\" src=\"/uploads/site/image 2.jpg\" style=\"height:405px; width:500px\" /></td>\n								</tr>\n							</tbody>\n						</table>\n						</td>\n					</tr>\n				</tbody>\n			</table>\n			</td>\n		</tr>\n		<tr>\n			<td style=\"text-align:center\"><span style=\"font-size:16px\"><strong>PesTesT will produce a categorical analysis with each test,<br />\n			so you can focus on the areas you need to improve the most.<br />\n			<br />\n			In a few hours, you will have become an expert on the subject!</strong></span></td>\n		</tr>\n		<tr>\n			<td> </td>\n		</tr>\n	</tbody>\n</table>','1');
INSERT INTO `articles` (`articles_id`,`articles_name`,`articles_content`,`articles_status`) VALUES ('6','Terms','<br />\n<span style=\"font-size:14px\">Terms of Service<br />\nPestest.com, A&amp;K Computers, Inc.</span><br />\n<br />\n<span style=\"font-size:14px\"><em>This agreement was last modified on 18 Mar, 2014.</em></span>\n<div style=\"text-align: justify;\"><br />\n<span style=\"font-size:14px\">These terms of service document the legally binding terms and conditions attached to the use of the site, Pestest.com.<br />\nBy using or accessing the site in any way, viewing or browsing the site, or adding your own content to the site, you are agreeing to be bound by these Terms of Service.<br />\n<br />\n<strong>Intellectual Property</strong><br />\nThe site and all of its original content are the sole property of Pestest.com and are, as such, fully protected by the appropriate international copyright and other intellectual property rights laws.<br />\n<br />\n<strong>Termination</strong><br />\nPestest.com reserves the right to terminate your access to the site, without any advance notice.<br />\n<br />\n<strong>Links to Other Websites</strong><br />\nOur site may contain a number of links to other websites and online resources that are not owned or controlled by Pestest.com.<br />\nPestest.com has no control over, and therefore cannot assume responsibility for, the content or general practices of any of these third party sites and/or services. Therefore, we strongly advise you to read the entire terms and conditions and privacy policy of any site that you visit as a result of following a link that is posted on our site.<br />\n<br />\n<strong>Governing Law</strong><br />\nThis agreement is governed in accordance with the laws of California, United States.<br />\n<br />\n<strong>Changes to This Agreement</strong><br />\nPestest.com reserves the right to modify these Terms of Service at any time. We do so by posting and drawing attention to the updated terms on the site. Your decision to continue to visit and make use of the site after such changes have been made constitutes your formal acceptance of the new Terms of Service.<br />\nTherefore, we ask that you check and review this agreement for such changes on an occasional basis. Should you not agree to any provision of this agreement or any changes we make to this agreement, we ask and advise that you do not use or continue to access Pestest.com immediately.<br />\n<br />\n<strong>Contact Us</strong><br />\nIf you have any questions about this agreement, please feel free to contact us at info@pestest.com.</span></div>\n<br />\n ','1');
INSERT INTO `articles` (`articles_id`,`articles_name`,`articles_content`,`articles_status`) VALUES ('3','Pricing','Pricing','0');
/*!40000 ALTER TABLE `articles` ENABLE KEYS */;


--
-- Create Table `author`
--

DROP TABLE IF EXISTS `author`;
CREATE TABLE `author` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(45) DEFAULT NULL,
  `lname` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `status` int(45) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Data for Table `author`
--

/*!40000 ALTER TABLE `author` DISABLE KEYS */;
INSERT INTO `author` (`uid`,`fname`,`lname`,`email`,`status`) VALUES ('4','Ken','test','sonata.techknowledge@gmail.com','0');
INSERT INTO `author` (`uid`,`fname`,`lname`,`email`,`status`) VALUES ('5','huy','le','xulanh00@gmail.com','0');
INSERT INTO `author` (`uid`,`fname`,`lname`,`email`,`status`) VALUES ('6','Tikay','Lee','tikaylee@tikay.com','1');
/*!40000 ALTER TABLE `author` ENABLE KEYS */;


--
-- Create Table `authorizenet_config`
--

DROP TABLE IF EXISTS `authorizenet_config`;
CREATE TABLE `authorizenet_config` (
  `api_login` varchar(255) COLLATE utf8_bin NOT NULL,
  `transaction_key` varchar(255) COLLATE utf8_bin NOT NULL,
  `post_url` varchar(255) COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Data for Table `authorizenet_config`
--

/*!40000 ALTER TABLE `authorizenet_config` DISABLE KEYS */;
INSERT INTO `authorizenet_config` (`api_login`,`transaction_key`,`post_url`) VALUES ('pg6A8bG51B','S1wLV5qEy65','https://swp.paymentsgateway.net/co/default.aspx');
/*!40000 ALTER TABLE `authorizenet_config` ENABLE KEYS */;


--
-- Create Table `banner`
--

DROP TABLE IF EXISTS `banner`;
CREATE TABLE `banner` (
  `banner_id` int(11) NOT NULL AUTO_INCREMENT,
  `banner_name` varchar(255) NOT NULL,
  `banner_width` int(11) DEFAULT NULL,
  `banner_height` int(11) DEFAULT NULL,
  `banner_status` int(11) NOT NULL,
  PRIMARY KEY (`banner_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Data for Table `banner`
--

/*!40000 ALTER TABLE `banner` DISABLE KEYS */;
/*!40000 ALTER TABLE `banner` ENABLE KEYS */;


--
-- Create Table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE `category` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `level` int(11) NOT NULL,
  `path` varchar(255) NOT NULL,
  `left` int(11) NOT NULL,
  `right` int(11) NOT NULL,
  `test_uid` int(11) NOT NULL,
  `state` varchar(45) DEFAULT NULL,
  `industry` varchar(45) DEFAULT NULL,
  `branch` varchar(45) DEFAULT NULL,
  `sub_branch` varchar(45) DEFAULT NULL,
  `category` varchar(45) DEFAULT NULL,
  `sub_category` varchar(45) DEFAULT NULL,
  `category_percentage` decimal(5,2) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8;

--
-- Data for Table `category`
--

/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('1','0','0','','1','168','2','','','','','','','0.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('63','1','1','','38','39','34',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('66','1','1','','32','33','36',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('67','1','1','','30','31','37',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('68','1','1','','28','29','38',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('69','1','1','','26','27','39',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('70','1','1','','24','25','40',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('71','1','1','','22','23','41',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('72','1','1','','20','21','42',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('73','1','1','','18','19','43',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('74','1','1','','16','17','44',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('75','1','1','','14','15','45',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('76','1','1','','12','13','46',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('77','1','1','','10','11','47',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('78','1','1','','8','9','48',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('79','1','1','','6','7','49',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('80','1','1','','4','5','50',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
INSERT INTO `category` (`uid`,`parent_id`,`level`,`path`,`left`,`right`,`test_uid`,`state`,`industry`,`branch`,`sub_branch`,`category`,`sub_category`,`category_percentage`,`status`) VALUES ('81','1','1','','2','3','51',NULL,NULL,NULL,NULL,'Pre-Test',NULL,'100.00','1');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;


--
-- Create Table `data_template`
--

DROP TABLE IF EXISTS `data_template`;
CREATE TABLE `data_template` (
  `configuration_id` int(11) NOT NULL AUTO_INCREMENT,
  `languages_id` int(11) DEFAULT NULL,
  `configuration_title` text COLLATE utf8_bin,
  `configuration_key` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `configuration_value` text COLLATE utf8_bin NOT NULL,
  `configuration_description` text COLLATE utf8_bin,
  `configuration_group_id` int(11) DEFAULT '0',
  `configuration_sort_order` int(5) DEFAULT NULL,
  `configuration_last_modified` datetime DEFAULT NULL,
  `configuration_date_added` datetime DEFAULT '0001-01-01 00:00:00',
  `configuration_use_function` text COLLATE utf8_bin,
  `configuration_set_function` text COLLATE utf8_bin,
  PRIMARY KEY (`configuration_id`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Data for Table `data_template`
--

/*!40000 ALTER TABLE `data_template` DISABLE KEYS */;
INSERT INTO `data_template` (`configuration_id`,`languages_id`,`configuration_title`,`configuration_key`,`configuration_value`,`configuration_description`,`configuration_group_id`,`configuration_sort_order`,`configuration_last_modified`,`configuration_date_added`,`configuration_use_function`,`configuration_set_function`) VALUES ('2','1','Email Contact','EMAIL_CONTACT','<table width=\"100%\" border=\"0\" cellpadding=\"2\" cellspacing=\"2\">\r\n  \r\n  <tr>\r\n    <td width=\"10%\"> - Name: </td>\r\n    <td>#contact_name#.</td>\r\n  </tr>\r\n  <tr>\r\n    <td><p> - Phone:</p>    </td>\r\n    <td> #contact_phone#.</td>\r\n  </tr>\r\n  <tr>\r\n    <td> - Subject: </td>\r\n    <td>#contact_subject#. </td>\r\n  </tr>\r\n  <tr>\r\n    <td valign=\"top\"> - Content: </td>\r\n    <td>#contact_content#.</td>\r\n  </tr>\r\n \r\n</table>',NULL,'0',NULL,NULL,'0001-01-01 00:00:00',NULL,NULL);
INSERT INTO `data_template` (`configuration_id`,`languages_id`,`configuration_title`,`configuration_key`,`configuration_value`,`configuration_description`,`configuration_group_id`,`configuration_sort_order`,`configuration_last_modified`,`configuration_date_added`,`configuration_use_function`,`configuration_set_function`) VALUES ('10','1','Testing','EMAIL_TESTING','<p>Dear #name#,</p>\n\n<p>You have successfully completed #test# (#code#) on #date#.<br />\n<br />\nYou have scored #score# points, and finished the test in #duration#.</p>\n\n<p> </p>\n\n<p>#site#</p>','','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','');
INSERT INTO `data_template` (`configuration_id`,`languages_id`,`configuration_title`,`configuration_key`,`configuration_value`,`configuration_description`,`configuration_group_id`,`configuration_sort_order`,`configuration_last_modified`,`configuration_date_added`,`configuration_use_function`,`configuration_set_function`) VALUES ('4','1','Email Register','EMAIL_REGISTER','<p>Dear #name#,</p>\n\n<p>Congratulations! Your account has been successfully created.<br />\n<br />\nYou can now take advantage of our member privileges. If you have any questions about the operation of the site, please use the contact form on our site to contact the administrators.<br />\n<br />\nYour login information is as follows:<br />\n<br />\nEmail: #username#<br />\nPassword: #password#<br />\n<br />\n#sitename#</p>',NULL,'0',NULL,NULL,'0001-01-01 00:00:00',NULL,NULL);
INSERT INTO `data_template` (`configuration_id`,`languages_id`,`configuration_title`,`configuration_key`,`configuration_value`,`configuration_description`,`configuration_group_id`,`configuration_sort_order`,`configuration_last_modified`,`configuration_date_added`,`configuration_use_function`,`configuration_set_function`) VALUES ('7','1','Email Forgotpass','EMAIL_FORGOTPASS','<p>Dear #name#,</p>\n\n<p>You are receiving this e-mail because you have requested a password reset for your Pestest.com account. Please see below for your new temporary password. If you did not request a password reset, please notify us using the contact form on our website.</p>\n\n<p>Email: #username#<br />\nPassword: #password#<br />\n<br />\nPlease be sure to change your password after logging in using your temporary password.<br />\n<br />\nThank you,<br />\n#sitename#</p>',NULL,'0',NULL,NULL,'0001-01-01 00:00:00',NULL,NULL);
INSERT INTO `data_template` (`configuration_id`,`languages_id`,`configuration_title`,`configuration_key`,`configuration_value`,`configuration_description`,`configuration_group_id`,`configuration_sort_order`,`configuration_last_modified`,`configuration_date_added`,`configuration_use_function`,`configuration_set_function`) VALUES ('11','1','Testing Company','EMAIL_TESTING_COMPANY','<p>Dear #company#,</p>\n\n<p>Your student, #name#, has successfully completed #test# (#code#) on #date#.<br />\n<br />\nYour student has scored #score# points, and finished the test in #duration#.</p>\n\n<p>#site#</p>','','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','');
INSERT INTO `data_template` (`configuration_id`,`languages_id`,`configuration_title`,`configuration_key`,`configuration_value`,`configuration_description`,`configuration_group_id`,`configuration_sort_order`,`configuration_last_modified`,`configuration_date_added`,`configuration_use_function`,`configuration_set_function`) VALUES ('12','1','Checkcode User','EMAIL_CHECKCODE_USER','<p>Date: #date#</p>\r\n<p>User Name: #username#</p>\r\n<p>Test: #test#</p>\r\n#description#','','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','');
INSERT INTO `data_template` (`configuration_id`,`languages_id`,`configuration_title`,`configuration_key`,`configuration_value`,`configuration_description`,`configuration_group_id`,`configuration_sort_order`,`configuration_last_modified`,`configuration_date_added`,`configuration_use_function`,`configuration_set_function`) VALUES ('13','1','Email Payment','EMAIL_PAYMENT','<p>Date: #date#</p>\r\n<p>Full Name: #username#</p>\r\n<p>Test: #test#</p>\r\n<p>Transaction Code: #ordercode#</p>','','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','');
INSERT INTO `data_template` (`configuration_id`,`languages_id`,`configuration_title`,`configuration_key`,`configuration_value`,`configuration_description`,`configuration_group_id`,`configuration_sort_order`,`configuration_last_modified`,`configuration_date_added`,`configuration_use_function`,`configuration_set_function`) VALUES ('14','1','Email Skip Payment','EMAIL_SKIPPAYMENT','<p>Date: #date#</p>\r\n<p>Full Name: #username#</p>\r\n<p>Test: #test#</p>','','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','','');
/*!40000 ALTER TABLE `data_template` ENABLE KEYS */;


--
-- Create Table `emails`
--

DROP TABLE IF EXISTS `emails`;
CREATE TABLE `emails` (
  `emails_id` int(11) NOT NULL AUTO_INCREMENT,
  `emails_date_created` int(11) DEFAULT NULL,
  `emails_date_modified` int(11) DEFAULT NULL,
  `emails_date_sent` int(11) DEFAULT NULL,
  `emails_from` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `emails_subject` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `emails_content` longtext CHARACTER SET utf8 COLLATE utf8_bin,
  `emails_attachment1` varchar(512) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `emails_attachment2` varchar(300) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `emails_attachment3` varchar(300) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `emails_active` binary(1) DEFAULT NULL,
  `email_num_send` int(11) DEFAULT NULL,
  `email_time_send` int(11) DEFAULT NULL,
  `email_mailing_to` longtext CHARACTER SET utf8 COLLATE utf8_bin,
  `emailing_temp_group` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `email_start_position` int(11) DEFAULT NULL,
  PRIMARY KEY (`emails_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `emails`
--

/*!40000 ALTER TABLE `emails` DISABLE KEYS */;
/*!40000 ALTER TABLE `emails` ENABLE KEYS */;


--
-- Create Table `emails_detail`
--

DROP TABLE IF EXISTS `emails_detail`;
CREATE TABLE `emails_detail` (
  `emdt_id` int(11) NOT NULL AUTO_INCREMENT,
  `emdt_mailing_id` int(11) DEFAULT NULL,
  `emdt_mailing_email` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `emdt_emails_id` int(11) DEFAULT NULL,
  `emdt_time` int(11) DEFAULT NULL,
  `emdt_return` int(11) DEFAULT NULL COMMENT '1:success,2:fail,3:spam',
  `emdt_malgrp_id` varchar(300) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`emdt_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `emails_detail`
--

/*!40000 ALTER TABLE `emails_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `emails_detail` ENABLE KEYS */;


--
-- Create Table `languages`
--

DROP TABLE IF EXISTS `languages`;
CREATE TABLE `languages` (
  `languages_id` int(11) NOT NULL AUTO_INCREMENT,
  `languages_name` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `languages_code` char(10) COLLATE utf8_bin DEFAULT NULL,
  `languages_image` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `languages_status` tinyint(4) DEFAULT NULL,
  `languages_sort_order` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`languages_id`),
  KEY `idx_languages_name_zen` (`languages_name`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Data for Table `languages`
--

/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` (`languages_id`,`languages_name`,`languages_code`,`languages_image`,`languages_status`,`languages_sort_order`) VALUES ('5','English','en_US','us.png','1','0');
INSERT INTO `languages` (`languages_id`,`languages_name`,`languages_code`,`languages_image`,`languages_status`,`languages_sort_order`) VALUES ('6','Korean','ko_KR','kr.png','0','0');
INSERT INTO `languages` (`languages_id`,`languages_name`,`languages_code`,`languages_image`,`languages_status`,`languages_sort_order`) VALUES ('7','Viet Nam','vi_VN','vn.png','0','0');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;


--
-- Create Table `mailing`
--

DROP TABLE IF EXISTS `mailing`;
CREATE TABLE `mailing` (
  `mailing_id` int(11) NOT NULL AUTO_INCREMENT,
  `mailing_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `mailing_first_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `mailing_last_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `mailing_email` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `mailing_date` int(11) DEFAULT NULL,
  `mailing_ip` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `mailing_order` int(11) DEFAULT NULL,
  `mailing_active` binary(1) DEFAULT NULL,
  `mailing_malgrp_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`mailing_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `mailing`
--

/*!40000 ALTER TABLE `mailing` DISABLE KEYS */;
/*!40000 ALTER TABLE `mailing` ENABLE KEYS */;


--
-- Create Table `mailing_group`
--

DROP TABLE IF EXISTS `mailing_group`;
CREATE TABLE `mailing_group` (
  `malgrp_id` int(11) NOT NULL AUTO_INCREMENT,
  `malgrp_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `malgrp_order` int(11) DEFAULT NULL,
  `malgrp_active` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`malgrp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `mailing_group`
--

/*!40000 ALTER TABLE `mailing_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `mailing_group` ENABLE KEYS */;


--
-- Create Table `member`
--

DROP TABLE IF EXISTS `member`;
CREATE TABLE `member` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `member_email` varchar(45) DEFAULT NULL,
  `member_pw` varchar(45) DEFAULT NULL,
  `register_date` int(11) DEFAULT NULL,
  `member_fname` varchar(45) DEFAULT NULL,
  `member_lname` varchar(45) DEFAULT NULL,
  `company_name` varchar(45) DEFAULT NULL,
  `company_contact_name` varchar(45) DEFAULT NULL,
  `company_contact_email` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `send_mail` int(11) DEFAULT '0',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=171 DEFAULT CHARSET=utf8;

--
-- Data for Table `member`
--

/*!40000 ALTER TABLE `member` DISABLE KEYS */;
/*!40000 ALTER TABLE `member` ENABLE KEYS */;


--
-- Create Table `menu_categories`
--

DROP TABLE IF EXISTS `menu_categories`;
CREATE TABLE `menu_categories` (
  `menu_categories_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_categories_image` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `menu_categories_link` varchar(64) COLLATE utf8_bin DEFAULT NULL,
  `menu_categories_parent_id` int(11) DEFAULT '0',
  `menu_categories_sort_order` int(3) DEFAULT NULL,
  `menu_categories_date_added` datetime DEFAULT NULL,
  `menu_categories_last_modified` datetime DEFAULT NULL,
  `menu_categories_status` tinyint(1) DEFAULT '1',
  `menu_categories_pid` int(11) DEFAULT NULL,
  `menu_categories_gid` int(11) DEFAULT NULL,
  `menu_categories_level` tinyint(4) DEFAULT NULL,
  `menu_categories_path` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `menu_categories_left` int(11) DEFAULT NULL,
  `menu_categories_right` int(11) DEFAULT NULL,
  PRIMARY KEY (`menu_categories_id`)
) ENGINE=MyISAM AUTO_INCREMENT=91 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Data for Table `menu_categories`
--

/*!40000 ALTER TABLE `menu_categories` DISABLE KEYS */;
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('1','','','0','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','0','0','0','','1','122');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('35','','admin_account','42','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','42','0','2','42|35|','9','10');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('42','','#','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','1','0','1','42|','4','33');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('43','','admin_language','42','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','42','0','2','42|43|','31','32');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('44','','admin_config','42','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','42','0','2','42|44|','11','12');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('45','','admin_templates','42','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','42','0','2','42|45|','29','30');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('46','','admin_themes','42','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','42','0','2','42|46|','27','28');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('47','','#','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','1','0','1','47|','54','61');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('48','','admin_backup_file','47','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','47','0','2','47|48|','59','60');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('49','','admin_backup_db','47','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','47','0','2','47|49|','57','58');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('70','','admin_category','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','1','0','1','70|','38','39');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('71','','admin_author','42','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','42','0','2','42|71|','23','24');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('72','','admin_payment_method','42','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','42','0','2','42|72|','25','26');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('73','','admin_questionnaires','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','1','0','1','73|','40','41');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('74','','admin_promotion','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','1','0','1','74|','44','45');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('75','','admin_test','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','1','0','1','75|','36','37');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('76','','admin_testing','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','1','0','1','76|','42','43');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('77','','admin_member','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','1','0','1','77|','34','35');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('78','','admin_banner','42','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','42','0','2','42|78|','7','8');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('79','','admin_articles','42','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','42','0','2','42|79|','5','6');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('80','','admin_home','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','1','0','1','80|','2','3');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('81','','admin_sale','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','1','0','1','81|','46','47');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('82','','#','1','0','0000-00-00 00:00:00','0000-00-00 00:00:00','0','1','0','1','82|','48','53');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('83','','admin_backup_file','82','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','82','0','2','82|83|','51','52');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('84','','admin_backup_db','82','0','0000-00-00 00:00:00','0000-00-00 00:00:00','1','82','0','2','82|84|','49','50');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('85','','admin_checkupdate','47',NULL,NULL,NULL,'1','47','0','2','47|85|','55','56');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('86','','#','42',NULL,NULL,NULL,'1','42','0','2','42|86|','13','22');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('87','','admin_emailtemplate/edit/4','86',NULL,NULL,NULL,'1','86','0','3','42|86|87|','20','21');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('88','','admin_emailtemplate/edit/7','86',NULL,NULL,NULL,'1','86','0','3','42|86|88|','18','19');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('89','','admin_emailtemplate/edit/11','86',NULL,NULL,NULL,'1','86','0','3','42|86|89|','16','17');
INSERT INTO `menu_categories` (`menu_categories_id`,`menu_categories_image`,`menu_categories_link`,`menu_categories_parent_id`,`menu_categories_sort_order`,`menu_categories_date_added`,`menu_categories_last_modified`,`menu_categories_status`,`menu_categories_pid`,`menu_categories_gid`,`menu_categories_level`,`menu_categories_path`,`menu_categories_left`,`menu_categories_right`) VALUES ('90','','admin_emailtemplate/edit/10','86',NULL,NULL,NULL,'1','86','0','3','42|86|90|','14','15');
/*!40000 ALTER TABLE `menu_categories` ENABLE KEYS */;


--
-- Create Table `menu_categories_description`
--

DROP TABLE IF EXISTS `menu_categories_description`;
CREATE TABLE `menu_categories_description` (
  `menu_categories_description_id` int(11) NOT NULL AUTO_INCREMENT,
  `menu_categories_id` int(11) DEFAULT '0',
  `languages_id` int(11) DEFAULT '1',
  `menu_categories_name` varchar(32) COLLATE utf8_bin DEFAULT NULL,
  `menu_categories_description` text COLLATE utf8_bin,
  PRIMARY KEY (`menu_categories_description_id`)
) ENGINE=MyISAM AUTO_INCREMENT=129 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Data for Table `menu_categories_description`
--

/*!40000 ALTER TABLE `menu_categories_description` DISABLE KEYS */;
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('33','35','1','Administrator','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('40','42','1','Configuration','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('41','43','1','Languages','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('42','44','1','Website','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('43','45','1','Templates','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('44','46','1','Themes','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('45','47','1','Backup - Update','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('46','48','1','Backup File','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('47','49','1','Backup Database','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('50','35','2','Quản trị','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('51','35','3','관리자','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('64','42','2','Cấu hình','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('65','42','3','설정','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('66','46','2','Chủ đề','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('67','46','3','테마','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('68','43','2','Ngôn ngữ','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('69','43','3','언어','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('70','47','2','Sao lưu - Cập nhật','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('71','47','3','백업 - 업데이트','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('72','45','2','Bản mẫu','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('73','45','3','Templates','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('74','49','2','Sao lưu Dữ liệu','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('75','49','3','데이터베이스 백업','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('76','48','2','Sao lưu tập tin','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('77','48','3','파일 백업','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('78','44','2','Website','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('79','44','3','웹사이트','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('82','35','5','Administrator','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('90','42','5','Configuration','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('91','47','5','Backup','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('92','49','5','Backup Database','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('93','48','5','Backup File','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('94','44','5','Site','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('95','43','5','Languages','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('108','70','5','Category','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('109','71','5','Author','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('110','72','5','Payment','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('111','73','5','Questionnaires','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('112','74','5','Promotion','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('113','75','5','Test','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('114','76','5','Testing','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('115','77','5','Member','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('116','78','5','Banner','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('117','79','5','Articles','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('118','80','5','Home','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('119','81','5','SALES REPORT','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('120','82','5','Backup','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('121','83','5','Backup File','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('122','84','5','Backup Database','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('123','85','5','Check Update','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('124','86','5','Email Template','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('125','87','5','Registered','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('126','88','5','Forgotten Passwords','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('127','89','5','Sponsor','');
INSERT INTO `menu_categories_description` (`menu_categories_description_id`,`menu_categories_id`,`languages_id`,`menu_categories_name`,`menu_categories_description`) VALUES ('128','90','5','Test-Takers','');
/*!40000 ALTER TABLE `menu_categories_description` ENABLE KEYS */;


--
-- Create Table `payment`
--

DROP TABLE IF EXISTS `payment`;
CREATE TABLE `payment` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `member_uid` int(11) NOT NULL,
  `test_uid` int(11) NOT NULL,
  `payment_type` varchar(45) DEFAULT NULL,
  `payment_date` int(11) DEFAULT NULL,
  `payment_price` decimal(10,2) NOT NULL,
  `transaction_code` text,
  `promotion_code` varchar(45) DEFAULT NULL,
  `valid_until` int(11) DEFAULT NULL,
  `daytest` int(11) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=313 DEFAULT CHARSET=utf8;

--
-- Data for Table `payment`
--

/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;


--
-- Create Table `payments_method`
--

DROP TABLE IF EXISTS `payments_method`;
CREATE TABLE `payments_method` (
  `payments_method_id` int(11) NOT NULL AUTO_INCREMENT,
  `payments_method_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `payments_method_code` varchar(10) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `payments_method_desc` text CHARACTER SET utf8 COLLATE utf8_bin,
  `payments_method_sort_order` tinyint(2) DEFAULT NULL,
  `payments_method_status` tinyint(1) DEFAULT NULL COMMENT '0:inactive,1:active',
  PRIMARY KEY (`payments_method_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Data for Table `payments_method`
--

/*!40000 ALTER TABLE `payments_method` DISABLE KEYS */;
INSERT INTO `payments_method` (`payments_method_id`,`payments_method_name`,`payments_method_code`,`payments_method_desc`,`payments_method_sort_order`,`payments_method_status`) VALUES ('1','Credit Card','AUT','','0','1');
/*!40000 ALTER TABLE `payments_method` ENABLE KEYS */;


--
-- Create Table `promotion`
--

DROP TABLE IF EXISTS `promotion`;
CREATE TABLE `promotion` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `promotion_code` varchar(45) NOT NULL,
  `promotion_price` decimal(10,2) NOT NULL,
  `date` int(11) NOT NULL,
  `description` text,
  `company` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `qty` int(11) NOT NULL DEFAULT '0',
  `usage_qty` int(11) NOT NULL,
  `test_uid` int(11) NOT NULL,
  `start_date` int(11) DEFAULT NULL,
  `end_date` int(11) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

--
-- Data for Table `promotion`
--

/*!40000 ALTER TABLE `promotion` DISABLE KEYS */;
/*!40000 ALTER TABLE `promotion` ENABLE KEYS */;


--
-- Create Table `questionnaires`
--

DROP TABLE IF EXISTS `questionnaires`;
CREATE TABLE `questionnaires` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `test_uid` int(11) NOT NULL,
  `category_uid` int(11) NOT NULL,
  `question` text,
  `created_by` int(11) NOT NULL,
  `input_date` int(11) DEFAULT NULL,
  `answer_description` text,
  `note` text,
  `note_ext` text,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `fk_questionnaires_category_idx` (`category_uid`),
  KEY `created_by_idx` (`created_by`)
) ENGINE=InnoDB AUTO_INCREMENT=2016 DEFAULT CHARSET=utf8;

--
-- Data for Table `questionnaires`
--

/*!40000 ALTER TABLE `questionnaires` DISABLE KEYS */;
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('379','34','63','You are applying a foliage herbicide from a boat at 5 mph, and you are making a 30-foot spray swath.  You apply 2 gallons of herbicide per minute.  How much herbicide solution are you applying per surface acre?','1','1399567183','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('380','34','63','10.8 pounds of chemical per acre-foot is how many ppm?','1','1399567183','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('381','34','63','An herbicide formulation is 50WP.  To get a final concentration of 3-ppm active ingredient, how much herbicide must be applied per acre-foot of water?','1','1399567183','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('382','34','63','What is the final concentration of active ingredient (in ppm) in a lake that has been treated with 27 pounds per acre-foot of a pesticide that is a 25 percent wettable powder?','1','1399567183','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('383','34','63','An applicator is using 3 gallons of “fishy oil” per 100 gallons of water.  A 200-gallon tank that is ¾ full of spray material.  How many gallons of “fishy oil” will be required to fill the tank and still maintain the same concentration?','1','1399567183','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('384','34','63','The treatment area is a triangle having a height of 90 feet and a base of 60 feet.  The label requires an application of 4 ounces of active ingredient per 1000 square feet.  How many ounces of a pesticide formulated as a 50 percent wettable powder would be required to treat the desired area?','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('385','34','63','The most important step in an aquatic plant management plan is','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('386','34','63','Most aquatic weeds fall into which two major categories','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('387','34','63','A submersed plant is an aquatic plant that grows with','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('388','34','63','A free-floating plant','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('389','34','63','An emergent plant','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('390','34','63','The term “phytotoxic” refers to','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('391','34','63','The term “watershed” refers to','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('392','34','63','This photo is best identified as<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/14.jpg\" style=\"height:208px; width:276px\" />','1','1399567231','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('393','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/15.jpg\" style=\"height:245px; width:273px\" />','1','1399567261','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('394','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/16.jpg\" style=\"height:257px; width:257px\" />','1','1399567303','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('395','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/17.jpg\" style=\"height:242px; width:202px\" />','1','1399567355','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('396','34','63','Major factors regulating aquatic plant growth include all of the following, except','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('397','34','63','Which is not a traditional method of aquatic weed control?','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('398','34','63','Aquatic weeds are typically spread by all of the following, except','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('399','34','63','Which of the following nutrients does not often regulate plant growth?','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('400','34','63','In choosing an aquatic herbicide, one of the most critical steps is','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('401','34','63','Persistence of a herbicide depends upon','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('402','34','63','Fish kills are more likely to occur when','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('403','34','63','For algae or submersed plants the amount of herbicide is calculated by','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('404','34','63','The term “acre-feet” refers to','1','1399567184','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('405','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/27.jpg\" style=\"height:222px; width:276px\" />','1','1399567457','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('406','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/28.jpg\" style=\"height:223px; width:296px\" />','1','1399567490','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('407','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/29.jpg\" style=\"height:278px; width:186px\" />','1','1399567533','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('408','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/30.jpg\" style=\"height:170px; width:237px\" />','1','1399567601','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('409','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/31.jpg\" style=\"height:236px; width:208px\" />','1','1399567729','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('410','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/32.jpg\" style=\"height:193px; width:256px\" />','1','1399567940','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('411','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/33.jpg\" style=\"height:189px; width:283px\" />','1','1399568003','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('412','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/34.jpg\" style=\"height:256px; width:256px\" />','1','1399568197','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('413','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/35.jpg\" style=\"height:227px; width:227px\" />','1','1399568374','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('414','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/36.jpg\" style=\"height:271px; width:254px\" />','1','1399568406','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('415','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/37.jpg\" style=\"height:254px; width:248px\" />','1','1399568432','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('416','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/38.jpg\" style=\"height:232px; width:309px\" />','1','1399568459','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('417','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/39.jpg\" style=\"height:206px; width:206px\" />','1','1399568490','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('418','34','63','This photo is best identified as<br />\n<br />\n<img alt=\"\" src=\"/uploads/Arizona_aquatic/40.jpg\" style=\"height:228px; width:302px\" />','1','1399568514','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('419','34','63','If the toxicity level of an herbicide for an aquatic weed is 2ppm of active ingredient, the herbicide should be applied at a ratio of 2 parts of active ingredient to how many parts of water?','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('420','34','63','A cubic foot of water contains approximately how many gallons of water?','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('421','34','63','An acre-foot of water weighs 2.7 million pounds.  A treatment is needed in a pond  containing 10 acre-feet.  How many pounds of herbicide must you apply to the body of water to obtain a concentration of .2ppm?','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('422','34','63','When temperature varies with depth, this is called','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('423','34','63','Weeds that grow standing out of the water or in water-saturated soils are called','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('424','34','63','The potential hazards of herbicide use are greater in','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('425','34','63','The use of chemicals to control unwanted fish species','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('426','34','63','Which of the following is an emergent weed?','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('427','34','63','What does the term \'miscible\' mean when discussing pesticides?','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('428','34','63','Macrophytes is the term used to describe all of the following types of growth, except','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('429','34','63','Which statement about leeches is incorrect?','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('430','34','63','Which nutrient is most responsible for heavy infestation of algae?','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('431','34','63','The fish least susceptible to pesticides is','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('432','34','63','Another method used to control weeds is using tilapia, zillie or white amur. What is this method called?','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('433','34','63','What is the surface of a pond, in acres, that is 200 feet long on each side and 100 feet wide at each end?','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('434','34','63','Which of the following statements about the zebra mussel is incorrect?','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('435','34','63','When treating an entire pond for Macrophytes fish kills which are mainly due to','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('436','34','63','How many acre feet of water are contained in a lake which has a surface area of 2 acres and an average depth of 5.1 feet?','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('437','34','63','Which of the following methods of control is not typically used for control of  water-living mammals?','1','1399567185','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('438','34','63','Filamentous algae can be controlled with the application of copper sulfate at finished concentration of 1.0 ppm per acreft.. How much copper sulfate should be applied to a body of water that is 1 1/2 surface acres and an average depth of 5 feet. (2.7 lb. of product per 1 A ft=1ppm).','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('439','34','63','Which of the following is not an invertebrate?','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('440','34','63','Which algae is somewhat tolerant to copper treatments?','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('441','34','63','The ways in which herbicides are typically removed from water include all of the following, except','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('442','34','63','A neutral pH is represented by the number','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('443','34','63','Bioaccumulation  of herbicides in fish is ____________ problem','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('444','34','63','How many gallons of water is contained in one acre foot of water?','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('445','34','63','Which of the following is not true of Pesticides used at concentrations needed to be effective?','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('446','34','63','Which of the following is the host for the pest that causes swimmers itch?','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('447','34','63','Empty containers should be','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('448','34','63','The International Toxic Units for this product is equal to _____ billion units per gallon.','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('449','34','63','For treatment of mosquito larvae in sewage ponds a maximum label-specified amount of this product is ________ pints per acre.','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('450','34','63','This product is best described as a','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('451','34','63','According to the label this pesticide’s primary active ingredient is','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('452','34','63','When applying pesticides the label requires an applicator to do all of the following, except','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('453','34','63','The best way to keep from contaminating groundwater is to','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('454','34','63','Which pesticide-handling activity poses a threat to groundwater?','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('455','34','63','Integrated Pest Management tactics include all of the following, except','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('456','34','63','Calibration means','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('457','34','63','All of the following are true of granular treatments, except','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('458','34','63','An adjuvant is required to make effective an application to emergent plants because it','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('459','34','63','Empty containers should be','1','1399567186','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('460','34','63','The dipotassium endothall content for this product is equal to approximately _____ ounces (weight) per gallon.','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('461','34','63','For treatment of zannichellia palustris in an entire pond, a maximum label-specified amount of this product is ________ pints per acre feet.','1','1399567187','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('462','34','63','This product is best described as a','1','1399567187','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('463','34','63','According to the label this pesticide’s primary active ingredient is','1','1399567187','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('464','34','63','The minimum label-specified effective dose of this product for the treatment of P. diversifolius on the perimeter of a lake is ___________ ppm.','1','1399567187','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('465','34','63','The rate of application prescribed by the label for this product to a 2-foot deep by 10 feet wide canal that is 3 miles long is ________ gallons to achieve the label-specified minimum effective dose for the treatment of sago.','1','1399567187','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('466','34','63','The minimum contact time for effective weed control for this product is _______ hours.','1','1399567187','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('467','34','63','The EPA registration number for this product is','1','1399567187','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('468','34','63','In order to legally use this product for control of aquatic weeds, an applicator must ensure all of the following, except','1','1399567187','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('469','34','63','For discouraging herons integrated pest management would include','1','1399567187','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('470','34','63','Which of the following is not true of Pesticides?','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('471','34','63','Pesticides are least effective in the control of which of the following species?','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('472','34','63','The family of insects most damaging to humans is','1','1399567187','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('473','34','63','Substrate area per unit volume discharge is generally greater','1','1399567187','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('474','34','63','Which of the following bio-control agents is used in mosquito control programs?','1','1399567187','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('560','34','63','The problem with black fly in Arizona is typically ','1','1399575675','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('561','34','63','Nutria are ','1','1399575743','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('562','34','63','In general pesticides are classified as ','1','1399575781','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('563','34','63','In order to reduce resistance in a species of pest, an applicator should ','1','1399575822','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('908','36','66','A newly hired applicator must be certified within ______ days of employment.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('909','36','66','Before purchasing or selecting a pesticide from inventory _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('910','36','66','Who is responsible for acts, omission and compliance with law and other lawful Orders of the Structural Pest Control Commission?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('911','36','66','Chronic toxicity _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('912','36','66','The active ingredient of a pesticide is the __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('913','36','66','The word “pesticide” means __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('914','36','66','A pest is all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('915','36','66','Competence in pest control includes _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('916','36','66','What is considered to be the most important part of a spraying system?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('917','36','66','The best way to keep from contaminating groundwater is to __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('918','36','66','Which pesticide-handling activity poses a threat to groundwater?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('919','36','66','Inaccurate measurement of pesticides can lead to _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('920','36','66','How many fluid ounces of insecticide concentrate are needed per gallon of water if the label recommends 12 ounces of insecticide concentrate per 10 gallons of water?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('921','36','66','How many fluid ounces of insecticide concentrate must be added to fill a three-gallon tank of water if the label recommends 12 ounces of insecticide per 10 gallons of water?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('922','36','66','What information is needed before calculating how much pesticide and diluent to combine to achieve the correct amount of finished spray mixture?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('923','36','66','Each service vehicle must be provided with ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('924','36','66','What precautions should you take to avoid getting pesticides into your water source at mix-load sites?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('925','36','66','The first step in an effective pest management program is __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('926','36','66','Integrated Pest Management (IPM) pest control tactics include all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('927','36','66','The pesticide label gives you instructions on ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('928','36','66','The Material Safety Data Sheet (MSDS) includes information on __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('929','36','66','An applicator should read the pesticide label ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('930','36','66','What types of personal protection should be worn when loading pesticides?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('931','36','66','In choosing a pesticide application procedure, an applicator should consider all of the following, except  ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('932','36','66','The term “pesticide” means __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('933','36','66','A sprayer delivers 32 ounces of water over 250 square feet.  The label recommends that 12 fluid ounces of insecticide concentrate be mixed in 10 gallons of water and applied as a spray at the rate of 1 gallon per 1000 square feet.  The sprayer capacity is three gallons.  What is the volume of finished spray per 1000 square feet of area sprayed?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('934','36','66','The most commonly used sprayer in the pest control industry is a __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('935','36','66','The signal word on a pesticide container indicates ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('936','36','66','Labels contain instructions on pesticide use and detail ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('937','36','66','Before purchasing a pesticide an applicator should read the product label to determine ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('938','36','66','Before applying a pesticide an applicator should read the product label to determine all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('939','36','66','Before storing a pesticide an applicator should read the product label to determine all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('940','36','66','Factors that influence whether a pesticide can move offsite in the air during an application include ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('941','36','66','The best first aid in the event of a pesticide emergency is to ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('942','36','66','Minimal personal protective equipment ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('943','36','66','Chemically resistant clothing includes _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('944','36','66','The most important part of pesticide selection is ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('945','36','66','Application procedures influence all of the following, except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('946','36','66','Consequences of improper pesticide use include all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('947','36','66','Which of the following is not true about dust formulations?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('948','36','66','Which of the following is not true about bait formulations?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('949','36','66','Which of the following is not true about aerosol formulations?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('950','36','66','Which of the following is not true about emulsifiable concentrate formulations?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('951','36','66','Which of the following is not true about granular formulations?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('952','36','66','Which of the following is not true about wettable powder formulations?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('953','36','66','Which of the following is not true about fumigants?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('954','36','66','All of the following are ways that pesticides may harm nontarget organisms that are present during a pesticide application, except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('955','36','66','Public schools must be notified at least ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('956','36','66','The advance notice to public schools shall include:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('957','36','66','In addition to the advance notification requirement, public schools must also be notified immediately prior to an application.  The notification immediately prior to an application shall provide the school with:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('958','36','66','Each certified applicator shall annually renew their certification by submitting a renewal form and by furnishing proof of completion of at least ______ hours of continuing education.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('959','36','66','All pesticide labels contain general instructions for the appropriate storage and disposal of a pesticide and its container, typically including _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('960','36','66','The “use” instructions on a pesticide label explain __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('961','36','66','“Residue” is a part of a pesticide that ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('962','36','66','Lightweight particles of pesticides are those particles that are easily carried by moving air.  These lightweight particles include:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('963','36','66','When rinsing a pesticide container, an applicator should __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('964','36','66','Applying pesticides in an enclosed space __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('965','36','66','When applying pesticides __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('966','36','66','Calibration means ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('967','36','66','Calibration is not required when __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('968','36','66','The term “target pest” means __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('969','36','66','To be able to identify and control pests, you need to know ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('970','36','66','The term “threshold level” means _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('971','36','66','Integrated pest management control strategies begin with ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('972','36','66','The pesticide label ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('973','36','66','The precautionary statement on a pesticide label alerts users to ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('974','36','66','Oral exposures to pesticides are often caused by all of the following, except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('975','36','66','Dermal exposures to pesticides are often caused by all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('976','36','66','Inhalation exposures to pesticides are often caused by all of the following, except __________.:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('977','36','66','Eye exposures to pesticides are often caused by all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('978','36','66','On the basis of possible hazard to the environment pesticides are classified as ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('979','36','66','A molluscicide kills ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('980','36','66','Mixing of a dry formulated concentrate in water is required.  The water weighs 8.34 pounds per gallon.  The dry formula is in 100 pound bags.  The active ingredient is 50%.  The inert ingredients are 50%.  The only label rate is 1%.  If you want to prepare a 1% solution in a 50 gallon tank, what will the total amount of the liquid in the tank weigh?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('981','36','66','A pest could be defined as _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('982','36','66','Most pesticides which are moderately toxic to humans are identified with which signal word?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('983','36','66','By law, which information need not appear on a pesticide container label?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('984','36','66','Acaricide is used against ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('985','36','66','When two or more low toxicity pesticides are combined creating a more toxic pesticide, this is called ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('986','36','66','A pesticide storage facility shall be all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('987','36','66','When is wearing protective clothing required?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('988','36','66','When must a self-contained breathing apparatus be worn?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('989','37','67','72 hours in advance of applying a pesticide at a school a notice shall be given to the school which includes all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('990','37','67','Immediately prior to an application of a pesticide at a school, a notice shall be provided with all of the following, except _______.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('991','37','67','A business licensee shall register each primary and branch office __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('992','37','67','The business licensee shall furnish proof of financial responsibility in the amount of ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('993','37','67','Each employee of a business licensee who applies pesticides, makes proposals, advertises or solicits shall:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('994','37','67','All of the following are grounds for disciplinary action, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('995','37','67','All of the following may make recommendations regarding a pesticide application, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('996','37','67','A company shall make and preserve true and accurate records of treatments performed, including those performed under warranty, for ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('997','37','67','Company records of treatments performed shall include all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('998','37','67','Company records directly related to the business of structural pest control shall include all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('999','37','67','Company records directly related to the business of structural pest control shall include all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1000','37','67','The Commission shall consider only those complaints filed with the Commission within _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1001','37','67','The business licensee shall report actions to resolve a complaint of property damage to SPCC within ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1002','37','67','None of the following shall be stored in the same room with a pesticide, except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1003','37','67','Which of the following requires notification to SPCC within one business day following incidents allegedly caused by the use of pesticides?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1004','37','67','Cleanup of pesticide spillage shall be made  _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1005','37','67','Each service vehicle used for pest control applications shall be equipped with all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1006','37','67','All empty pesticide containers not yet prepared for disposal in accordance with label directions shall ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1007','37','67','A pesticide storage facility shall be all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1008','37','67','All service vehicles storing pesticides shall ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1009','37','67','The three routes that a pesticide may enter the body are __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1010','37','67','When is wearing protective clothing required?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1011','37','67','Pesticide toxicity is affected by all of the following, except _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1012','37','67','The advantages of emulsifiable concentrates include all of the following, except _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1013','37','67','The advantages of wettable powders include all of the following, except _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1014','37','67','Which of the following is not true about dust formulations?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1015','37','67','The advantages of bait formulations include all of the following, except _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1016','37','67','Which of the following is not true about granular formulations?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1017','37','67','When must a self-contained breathing apparatus be worn?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1018','37','67','Which of the following pesticide formulations poses the greatest dermal hazard?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1019','37','67','Which of the following is not true about fumigants?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1020','37','67','All of the following are true of pesticide ingestion, except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1021','37','67','Dermal exposures to pesticides may be caused by all of the following, except____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1022','37','67','Inhalation exposures to pesticides may be caused by all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1023','37','67','All of the following are true of Ocular exposures to pesticides, except _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1024','37','67','Every Qualifying Party should be well informed about all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1025','37','67','A pesticide label’s precautionary statement alerts users to ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1026','37','67','Before using a pesticide a user should first ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1027','37','67','Pesticide storage facilities should be ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1028','37','67','To avoid pesticidal ocular contact a user should do all of the following, except _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1029','37','67','All of the following are signal words, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1030','37','67','All of the following are stated on a pesticide label, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1031','37','67','The three “C’s” in spill management include all of the following, except _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1032','37','67','Personal protective equipment is resistant to pesticides when made of _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1033','37','67','A pesticide label’s statement of practical treatment relates to _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1034','37','67','If a job requires the application of 12 gallons of finished product and an applicator has only a 10 gallon tank, the applicator should __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1035','37','67','Routine personal cleanup, including clothing and equipment, should be done __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1036','37','67','Dangerous exposure to pesticides may be reduced by all of the following, except _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1037','37','67','When handling pesticides, which of the following should not be done ?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1038','37','67','Re-use of pesticide containers is permissible _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1039','37','67','Pesticide drift is ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1040','37','67','Pesticide container rinsate should be ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1041','37','67','Pesticide containment systems perform all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1042','37','67','Risks reduced through the use of as little pesticide as necessary includes all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1043','37','67','The increasing amount of systemic pesticide residue within an ecosystems predation chain is called ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1044','37','67','Factors affecting the rate of pesticide absorption through the skin include all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1045','37','67','Factors in determining hazard include all of the following, except _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1046','37','67','The two basic types of pesticide toxicity are acute and  __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1047','37','67','All of the following are true of pesticide run-off, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1048','37','67','Pesticide Compatibility refers to ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1049','37','67','In case of a pesticide spill the applicator should do all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1050','37','67','All of the following are effective strategies for reducing or eliminating pesticide container disposal, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1051','37','67','All of the following are typical signs of pesticide poisoning, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1052','37','67','Combining pesticides into a single mixture may result in all of the following, except _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1053','37','67','Information required on a pesticide label includes ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1054','37','67','Use of baits __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1055','37','67','“Keep out of reach of children” appears __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1056','37','67','Rinsate may be used as a diluent for a future pesticide application if all of the following apply, except _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1057','37','67','Which of the following is not an important component of a pesticide storage area?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1058','37','67','An allergic reaction an applicator to pesticide exposure indicates __________.','1','0','The pesticide has been misused',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1059','37','67','A pesticide formulation which is finely ground and non-dissolving is a __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1060','37','67','The carrier is ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1061','37','67','Within a flowable formulation the active ingredient is mixed with a liquid  to form a ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1062','37','67','The pH for most pesticides is __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1063','37','67','Granular formulations are like dust formulations, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1064','37','67','Pesticides which effect the development of pests are called __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1065','37','67','Dust formulations ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1066','37','67','Microencapsulated formulations ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1067','37','67','The purpose of an adjuvant is ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1068','37','67','Desiccants are effective because _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1069','37','67','Ultra-low volume concentrates are used ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1070','37','67','Minimum standards of applicator competence for the use of restricted use pesticides are established by _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1071','37','67','All of the following refer to treatment records, except _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1072','37','67','Application of general-use pesticides in areas inhabited by endangered species must be made by __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1073','37','67','Licensed applicators and qualifying parties must obtain a minimum of ______ hours of SPCC-approved continuing education for each category of licensure annually.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1074','37','67','A response to a complaint must be filed within ______ days.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1075','37','67','The maximum financial penalty that SPCC may levy for each violation of the law is $________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1076','37','67','An applicator license must be renewed annually before _________ or the Commission shall suspend it.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1077','37','67','Pesticides allowable for use in Arizona must be registered with the United State Environmental Protection Agency and the __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1078','37','67','Integrated pest management combines all of the following elements, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1079','37','67','With regard to Integrated Pest Management occasional invaders __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1080','37','67','Soil is best categorized as __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1081','37','67','Natural controls __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1082','37','67','High temperatures and low humidity increase the likelihood of pesticide __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1083','37','67','A treatment area is 40 ft. by 50 ft.. The rate of application is 2 gallons of finished pesticide mixture for every 100 square ft.  The label requires 1 oz. of pesticide concentrate for each gallon of finished pesticide mixture.  How much pesticide concentrate is needed to treat this area?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1084','37','67','The pesticide label requires that the pesticide active ingredient applied be 1% by weight in water per 100 sq. ft..  What percentage of pesticide active ingredient will the finished pesticide mixture have if treating 2500 sq. ft.?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1085','37','67','Dilution refers to ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1086','37','67','An asymmetrical area is composed of a 12 ft. square, 16 ft diameter half circle, and an equilateral triangle with 10 ft. sides.  What is the approximate area to be treated?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1087','37','67','Application failure may result from all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1088','37','67','Secondary pests are distinguished by feeding habits that include __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1089','38','68','A structural application requires treatment of 65,000 cu.ft..  The application rate is one pound per 10,000 cu.ft.. How many pounds are needed under ideal conditions?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1090','38','68','The goals in monitoring fumigant concentration include all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1091','38','68','An area to be fumigated should be closely inspected to determine all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1092','38','68','In structural fumigation, a fumiguide is a __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1093','38','68','All of the following factors affect the usable lifetime of a breathing apparatus, except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1094','38','68','Inhalation exposures may be caused by all of the following except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1095','38','68','Before using a fumigant __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1096','38','68','As the slab temperature increases the ounce-hour requirements __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1097','38','68','Assume good tarps and an equal number of properly placed sand snakes around a structure.  Which of the following areas will have the least amount of gas loss?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1098','38','68','For measuring small amounts of Hydrogen Phosphide use a __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1099','38','68','What is the purpose of using fans during a fumigation?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1100','38','68','Half Loss Time is affected by all of the following, except ________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1101','38','68','Generally, where should you place monitoring lines?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1102','38','68','What is the cubic footage of a structure that is 50 feet wide, 37 feet long, and has an average height of 10 feet?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1103','38','68','Equilibrium is best described as the _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1104','38','68','How do vacuum chamber fumigations differ from other forms of vault fumigations?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1105','38','68','Fumigation spot treatments are intended to:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1106','38','68','Spot fumigations are effective in controlling all of the following, except ________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1107','38','68','The first step in an effective pest management program is:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1108','38','68','What is the cubic footage of a building that is 40 feet long, 20 feet wide and has an average height of 10 feet?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1109','38','68','This is a photo of a _________.<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/21.jpg\" style=\"height:609px; width:1066px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1110','38','68','This is a photo of a(n) _________.<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/22.jpg\" style=\"height:298px; width:535px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1111','38','68','This is a photo of a(n) _________.<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/23.jpg\" style=\"height:299px; width:530px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1112','38','68','This is a photo of a _________.<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/24.jpg\" style=\"height:221px; width:298px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1113','38','68','This is a photo of a(n) _________.<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/25.jpg\" style=\"height:299px; width:539px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1114','38','68','This is a photo of a _________.<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/26.jpg\" style=\"height:299px; width:522px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1115','38','68','This is a photo of a _________.<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/27.jpg\" style=\"height:218px; width:251px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1116','38','68','This is a photo of a _________.<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/28.jpg\" style=\"height:299px; width:535px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1117','38','68','This is a photo of a(n) _________.<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/29.jpg\" style=\"height:202px; width:158px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1118','38','68','This is a photo of a _________.<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/30.jpg\" style=\"height:288px; width:528px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1119','38','68','This is a photo of a _________.<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/31.jpg\" style=\"height:267px; width:324px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1120','38','68','This is a photo of a(n) _________.<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/32.jpg\" style=\"height:351px; width:262px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1121','38','68','This is a photo of a _________.<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/33.jpg\" style=\"height:154px; width:327px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1122','38','68','For fumigants all of the following are true, except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1123','38','68','Tarps are used in fumigation to ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1124','38','68','All of the following are true of the tape and seal method, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1125','38','68','The three states of matter are____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1126','38','68','During fumigation, the gas is taken up by both the liquid and the solid articles remaining in the structure.  This is called ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1127','38','68','Fumigants ___________________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1128','38','68','Airborne concentrations of a chemical as a factor of average exposure level is called ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1129','38','68','Vapor pressure is a measurement of ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1130','38','68','How many cubic feet are contained in this structure?<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/44.jpg\" style=\"height:243px; width:314px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1131','38','68','At the rate of 10 oz. per 1,000 cubic feet, how much fumigate would you use in this structure?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1132','38','68','[VIKANE]According to the label a SCBA must be worn until the measurable amount of the fumigant remaining in the structure does not exceed __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1133','38','68','[VIKANE]According to the label the amount of warning agent for a 20,000 cubic foot structure is _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1134','38','68','[VIKANE]According to the label the personal protective equipment require for introduction of this fumigant includes ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1135','38','68','[VIKANE]According to the label the required steps for preparing a structure for the introduction of this fumigant includes all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1136','38','68','[VIKANE]According to the label, the multiplication factor for the dosage of fumigant to treat for other pests is based on which species?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1137','38','68','[VIKANE]According to the label sufficient gas should be introduced to the structure to accumulate at least _______ounce-hours following equilibrium.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1138','38','68','[VIKANE]According to the label the fumigant should be released into the structure through a leak-proof tube with a burst pressure of at least _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1139','38','68','[VIKANE]According to the label only a detection device of sufficient sensitivity, such as a ___________, can be used to confirm the safe-entry concentration of this fumigant.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1140','38','68','[VIKANE]According to the label the persons to whom this fumigant may be sold include ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1141','38','68','[VIKANE]According to the label all of the following are early symptoms of human exposure to this fumigant, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1142','38','68','[VIKANE]According to the label the active ingredient includes ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1143','38','68','How many cubic feet are contained in this structure?<br />\n<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/57.jpg\" style=\"height:227px; width:479px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1144','38','68','At the rate of 2/3 oz. per 1,000 cubic feet, how much fumigate would you use in this structure?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1145','38','68','[Fumitoxin]According to the label this product _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1146','38','68','[Fumitoxin]According to the label this product _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1147','38','68','[Fumitoxin]According to the label concentration levels can be detected by ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1148','38','68','[Fumitoxin]According to the label general commodity fumigation rates with tablets would consist of ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1149','38','68','[Fumitoxin]According to the label burrow fumigation ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1150','38','68','[Fumitoxin]How many cubic feet are contained in this structure?<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/64.jpg\" style=\"height:327px; width:314px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1151','38','68','[Fumitoxin]At the rate of  1/2 oz. per 200 cubic feet, how much fumigate would you use in this structure?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1152','38','68','[METH-O-GAS 100]According to the label this product _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1153','38','68','[METH-O-GAS 100]According to the label this product _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1154','38','68','[METH-O-GAS 100]According to the label concentration levels can be detected by ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1155','38','68','[Fumitoxin]According to the label during release an applicator should wear ________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1156','38','68','[Fumitoxin]According to the label if inhalation results in unconsciousness __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1157','38','68','[Fumitoxin]According to the label which item is not require on the placard posted at the fumigation site?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1158','39','69','What formula is used to calculate the volume of a structure which has a flat roof?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1159','39','69','The initials SCBA stand for  __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1160','39','69','The three states of matter are __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1161','39','69','During fumigation, the gas is taken up by both the liquid and the solid articles remaining in the structure.  This is called ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1162','39','69','Fumigants ___________________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1163','39','69','All of the following elements pertain to a definition of fumigation, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1164','39','69','Airborne concentrations of a chemical as a factor of average exposure level is called ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1165','39','69','Vapor pressure is a measurement of ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1166','39','69','This is a photo of a _________.<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/33.jpg\" style=\"height:154px; width:327px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1167','39','69','This is a photo of a _________.<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/QP10.jpg\" style=\"height:195px; width:195px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1168','39','69','This is a photo of a _________.<br />\n<br />\n<br />\n\\<img alt=\"\" src=\"/uploads/Fumigation Certification/31.jpg\" style=\"height:267px; width:324px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1169','39','69','<img alt=\"\" src=\"/uploads/Fumigation Certification/30.jpg\" style=\"height:288px; width:528px\" />This is a photo of a _________.','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1170','39','69','This is a photo of a _________.<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/QP12.jpg\" style=\"height:146px; width:222px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1171','39','69','This is a photo of a(n) _________.<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/29.jpg\" style=\"height:202px; width:158px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1172','39','69','This is a photo of a(n) _________.<br />\n<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/32.jpg\" style=\"height:351px; width:262px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1173','39','69','This is a photo of a(n) _________.<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/25.jpg\" style=\"height:299px; width:539px\" /><br />\n<br />\n ','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1174','39','69','This is a photo of a _________.<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/21.jpg\" style=\"height:609px; width:1066px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1175','39','69','This is a photo of a _________.<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/26.jpg\" style=\"height:299px; width:522px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1176','39','69','How do vacuum chamber fumigations differ from other forms of vault fumigations?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1177','39','69','Which of the following is not a goal in monitoring fumigant concentration?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1178','39','69','[VIKANE]According to the label a SCBA must be worn until the measurable amount of the fumigant remaining in the structure does not exceed __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1179','39','69','[VIKANE]According to the label the amount of warning agent for a 20,000 cubic foot structure is _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1180','39','69','[VIKANE]According to the label the personal protective equipment require for introduction of this fumigant includes ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1181','39','69','[VIKANE]According to the label the required steps for preparing a structure for the introduction of this fumigant includes all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1182','39','69','[VIKANE]According to the label, the multiplication factor for the dosage of fumigant to treat for other pests is based on which species?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1183','39','69','[VIKANE]According to the label sufficient gas should be introduced to the structure to accumulate at least _______ounce-hours following equilibrium.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1184','39','69','[VIKANE]According to the label the fumigant should be released into the structure through a leak-proof tube with a burst pressure of at least _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1185','39','69','[VIKANE]According to the label only a detection device of sufficient sensitivity, such as a ___________, can be used to confirm the safe-entry concentration of this fumigant.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1186','39','69','[VIKANE]According to the label the persons to whom this fumigant may be sold include ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1187','39','69','[VIKANE]According to the label all of the following are early symptoms of human exposure to this fumigant, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1188','39','69','[VIKANE]According to the label the active ingredient includes ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1189','39','69','The Interscan device will detect levels of concentration as low as?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1190','39','69','How many cubic feet are contained in this structure?<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/QP33.jpg\" style=\"height:327px; width:314px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1191','39','69','At the rate of 2/3 oz. per 1,000 cubic feet, how much fumigate would you use in this structure?<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/QP33.jpg\" style=\"height:327px; width:314px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1192','39','69','According to Label #1, a minimum of ______ introduction site(s) is required for the introduction of the warning agent.<br />\n<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/QP33.jpg\" style=\"height:327px; width:314px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1193','39','69','According to Label #3, ___________ of fumigant should be introduced to this structure in order to treat for rats.<br />\n<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/QP33.jpg\" style=\"height:327px; width:314px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1194','39','69','According to Label #3, ___________ exposure time is required for treatment of rats in this structure.<br />\n<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/QP33.jpg\" style=\"height:327px; width:314px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1195','39','69','[Fumitoxin]According to the label this product _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1196','39','69','[Fumitoxin]According to the label this product _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1197','39','69','[Fumitoxin]According to the label concentration levels can be detected by ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1198','39','69','[Fumitoxin]According to the label general commodity fumigation rates with tablets would consist of ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1199','39','69','[Fumitoxin]According to the label railcar fumigation for malt ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1200','39','69','[Fumitoxin]According to the label burrow fumigation ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1201','39','69','[Fumitoxin]According to the label when performing a truck fumigation ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1202','39','69','[Fumitoxin]According to the label when un-reacted pesticide remains at the conclusion of a fumigation it may be ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1203','39','69','[Fumitoxin]According to the label burrow systems may be fumigated if _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1204','39','69','[Fumitoxin]According to the label the proper dosage for gopher control is ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1205','39','69','How many cubic feet are contained in this structure?<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/QP48.jpg\" style=\"height:140px; width:144px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1206','39','69','At the rate of 1/2 oz. per 200 cubic feet, how much fumigate would you use in this structure?<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/QP48.jpg\" style=\"height:140px; width:144px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1207','39','69','According to Label #1, a minimum of ______ introduction site(s) is required for the introduction of the warning agent.<br />\n<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/QP48.jpg\" style=\"height:140px; width:144px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1208','39','69','According to Label #3, ___________ of fumigant should be introduced to this structure in order to fumigate warehouse moth in corn.<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/QP48.jpg\" style=\"height:140px; width:144px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1209','39','69','According to Label #3, ___________ exposure time is required for treatment of warehouse moth in corn.<br />\n<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/QP48.jpg\" style=\"height:140px; width:144px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1210','39','69','Halide detectors are capable of measuring Methyl Bromide concentrations as low as __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1211','39','69','Because of Methyl Bromide’s boiling point, the label requires the use of a _________ for replacing energy.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1212','39','69','For detecting Methyl Bromide, an Interscan device may be used interchangeably with a ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1213','39','69','What formula is used to calculate the volume of a structure which has a pitched roof?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1214','39','69','A condition where pressure within the structure increases, due to wind passing over the exterior surface, and causing an inflation of the tarps is called ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1215','39','69','[METH-O-GAS 100]According to the label the vapor is not ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1216','39','69','[METH-O-GAS 100]According to the label during release an applicator should wear ________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1217','39','69','[METH-O-GAS 100]According to the label if inhalation results in unconsciousness __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1218','39','69','[METH-O-GAS 100]According to the label which item is not require on the placard posted at the fumigation site?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1219','39','69','[METH-O-GAS 100]According to the label all items should be removed from the structure prior to introduction of the fumigant except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1220','39','69','[METH-O-GAS 100]According to the label polyethylene sheeting may be used if its thickness is _______.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1221','39','69','[METH-O-GAS 100]According to the label chestnuts may be fumigated for saw-tooth grain beetles, at 70F degrees ambient temperature, at a rate of ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1222','39','69','[METH-O-GAS 100]According to the label cheese may be fumigated for cheese mites, at 70F degrees ambient temperature, at a rate of ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1223','39','69','[METH-O-GAS 100]According to the label a 100,000 cu.ft. grain elevator may be fumigated for German Cockroaches, at 50F degrees ambient temperature, at a rate of ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1224','39','69','Factors affecting the kill rate include all of the following except _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1225','39','69','Fumigants are effective because their properties include ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1226','39','69','The process of a fumigant moving from greater to lesser concentration is  ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1227','39','69','How many cubic feet are contained in this structure?<br />\n<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/57.jpg\" style=\"height:227px; width:479px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1228','39','69','At the rate of 10 oz. per 1,000 cubic feet, how much fumigate would you use in this structure?<br />\n<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/57.jpg\" style=\"height:227px; width:479px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1229','39','69','According to Label #1, a minimum of ______ introduction site(s) is required for the introduction of the warning agent to this structure.<br />\n<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/57.jpg\" style=\"height:227px; width:479px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1230','39','69','According to Label #3, ___________ of fumigant should be introduced to this structure in order to fumigate for alfalfa weevil in hay.<br />\n<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/57.jpg\" style=\"height:227px; width:479px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1231','39','69','According to Label #3, ___________ exposure time is required for treatment of brown mites in pears in this structure.<br />\n<br />\n<br />\n<br />\n<br />\n<img alt=\"\" src=\"/uploads/Fumigation Certification/57.jpg\" style=\"height:227px; width:479px\" />','1','0','','','','Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1232','39','69','According to Label #2, the minimum exposure at 75F degrees for bags is ________ .','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1233','39','69','According to Label #2, the maximum dosage per 1000 cu.ft. for dried fruit is _______.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1234','39','69','According to Label #2, all of the following are required for application to a Quonset building, except _______.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1235','39','69','The boiling point of a fumigant is ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1236','39','69','The movement of a fumigant throughout a structure is called ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1237','39','69','To accelerate the rate of kill a fumigant may be mixed with _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1238','40','70','Cockroaches, ants and beetles have ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1239','40','70','Bed bugs and conenose bugs have ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1240','40','70','House flies have ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1241','40','70','Moths and butterflies have _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1242','40','70','Gradual metamorphosis consists of _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1243','40','70','Complete metamorphosis consists of ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1244','40','70','There three castes of ants usually found within a colony are ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1245','40','70','Which cockroach prefers areas of warmth and high humidity?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1246','40','70','Which cockroach prefers warm areas and low humidity?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1247','40','70','Which cockroach prefers damp cooler situations?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1248','40','70','The term “dooryard pests” refers to pests that ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1249','40','70','The best technique for treating cockroaches in food areas is __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1250','40','70','Control of sowbugs, pillbugs, and earwigs includes all of the following, except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1251','40','70','Lyme disease is usually associated with ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1252','40','70','The use directions on total release aerosol products require calculation of the ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1253','40','70','Pest identification, exclusion, and population reduction are control methods usually associated with ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1254','40','70','What is the most important step in beginning a successful rodent control program?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1255','40','70','Which of the following is a common application technique for treating ticks in yards?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1256','40','70','Spot treatment” means an area not larger than __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1257','40','70','Two dark longitudinal stripes on pronotum; approximately ½ inch in length best describes the _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1258','40','70','Two pale bands at the base and tip of wings; ½ inch in length best describes the ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1259','40','70','Brown to reddish brown color; wings cover abdomen; 1 to 1 ½ inches in length best describes the ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1260','40','70','Almost black in color; wings shorter than abdomen; 1 inch in length best describes the _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1261','40','70','The basis for effective domestic fly control is ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1262','40','70','Scorpions are nocturnal and are likely to be found in all of the following areas, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1263','40','70','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1264','40','70','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1265','40','70','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1266','40','70','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1267','40','70','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1268','40','70','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1269','40','70','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1270','40','70','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1271','40','70','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1272','40','70','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1273','40','70','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1274','40','70','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1275','40','70','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1276','40','70','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1277','40','70','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1278','40','70','The most commonly used sprayer is the ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1279','40','70','Competence in pest control includes all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1280','40','70','A significant hazard when applying a dust formulation is the ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1281','40','70','When applying pesticides outdoors with a power sprayer, generally it is best to use:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1282','40','70','What is the most important part of a spraying system?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1283','40','70','U.L.V., when applying undiluted pesticides, means:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1284','40','70','The best way to keep from contaminating groundwater is to ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1285','40','70','Which pesticide-handling activity poses a threat to groundwater?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1286','40','70','Inaccurate measurement of pesticides can lead to all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1287','40','70','A sprayer applies 32 oz. of water over 250 sq.ft..  The label requires that 12 oz. of pesticide concentrate be mixed in 10 gallons of water and applied as a spray at the rate of 1 gallon per 1000 square feet.  The sprayer capacity is three gallons.  What is the volume of finished spray per 1000 square feet of area sprayed?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1288','40','70','How many oz. of pesticide concentrate are needed per gallon of water if the label recommends 12 ounces of insecticide concentrate per 10 gallons of water?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1289','40','70','How many fluid ounces of pesticide concentrate must be added to fill a three-gallon tank of water if the label recommends 12 ounces of insecticide per 10 gallons of water?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1290','40','70','What information is needed before calculating how much pesticide and diluent to combine to achieve the correct amount of finished spray mixture?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1291','40','70','Why must an applicator keep records of pesticide applications?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1292','40','70','Treatment records shall include ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1293','40','70','Each service vehicle must be provided with all of the following, except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1294','40','70','What precautions should you take to avoid getting pesticides into the water source at mix-load sites?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1295','40','70','When an insect molts, it ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1296','40','70','The most reliable means of ant control is ___________','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1297','40','70','When treating for scorpions, chemical control is best achieved with ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1298','40','70','The most important step in any pest management program is ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1299','40','70','Failure to control a  pest problem can often be attributed to ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1300','40','70','Integrated Pest Management includes all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1301','40','70','The pesticide label gives you instructions on ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1302','40','70','The Material Safety Data Sheet includes information on ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1303','40','70','An applicator should read the pesticide label ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1304','40','70','Mixing and applying two or more pesticides at one time is ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1305','40','70','When mixing or loading pesticides proper PPE may include ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1306','40','70','Application procedures should consider all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1307','40','70','Pesticides include all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1308','40','70','Refer to Label #1, This pesticide is a __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1309','40','70','Refer to Label #1, The required personal protective equipment for use of this pesticide during application includes ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1310','40','70','Refer to Label #1,  A pest control company has a contract with a hospital for pest control services.  During a routine monthly service call ants are found in the dining room.  The proper treatment location during business hours is to __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1311','40','70','Refer to Label #2,  Empty packets should be_____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1312','40','70','Refer to Label #2,  All of the following statements are accurate about this pesticide, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1313','40','70','Refer to Label #2,  Mixing 2 packets of this pesticide with 1 gallon of water makes an active ingredient concentration of __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1314','40','70','Refer to Label #2,  This product is best described as a ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1315','40','70','Refer to Label #3,  According to the label this pesticide’s primary ingredient is ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1316','40','70','Refer to Label #3,  According to the label storage of this pesticide requires all of the following, except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1317','40','70','Refer to Label #3,  What is the recommended treatment method for application of this product in the kitchen area of a restaurant?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1318','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1319','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1320','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1321','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1322','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1323','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1324','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1325','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1326','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1327','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1328','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1329','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1330','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1331','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1332','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1333','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1334','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1335','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1336','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1337','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1338','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1339','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1340','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1341','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1342','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1343','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1344','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1345','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1346','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1347','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1348','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1349','41','71','Which option correctly identifies this photo?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1350','41','71','Regarding the signal words Warning, Danger, and Caution __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1351','41','71','A pesticide applicator may not use any pesticide in a manner inconsistent with label directions, except when ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1352','41','71','The term “active ingredient” is defined as ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1353','41','71','The basic rule of pesticide safety is ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1354','41','71','Aerosol generators are also known as __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1355','41','71','Most hand dusters are used to introduce __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1356','41','71','The most common cockroach species in structures in the southwest is ________.:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1357','41','71','The American Cockroach can be distinguished by ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1358','41','71','The Oriental Cockroach female can be distinguished by ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1359','41','71','The Brownbanded Cockroach can be distinguished by _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1360','41','71','The German Cockroach can be distinguished by _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1361','41','71','The successful management of ants often requires an exact identification of the species involved because ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1362','41','71','Baits may be used in ant control programs if ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1363','41','71','Most pests of stored products ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1364','41','71','The most numerous and wide spread mammal on earth, and the number one rodent pest is the ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1365','41','71','Of the following, which rodenticide is classified as a first generation anticoagulant?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1366','41','71','Of the following, which rodenticide is potentially more hazardous than other pesticide formulations due to its high concentration?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1367','41','71','A licensed applicator must realize which of the following concerning bird management?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1368','41','71','An applicator wishes to control German cockroaches at a small apartment using a residual pesticide spray.  After calculating the size of the treatment area it is determined that only three quarts of a 0.5% spray dilution is required.  The product label requires that 1.33 fl.oz. of concentrate be used to make one gallon of 0.5 percent water-based dilution.  How many oz. concentrate is needed to treat this apartment?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1369','41','71','A pesticide that penetrates the body wall to cause death is called a __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1370','41','71','A large estate requires ant control.  After an inspection and calculation an applicator determines that 5 gallons of 0.25 % pesticide dilution is needed.  After spraying one gallon of pesticide a severe tick infestation is discovered.    While the label indicates that the product may also be used for ticks, it states that a 0.5% rate is required for effective control.  After re-calculating, it is determined that 25 gallons of 0.5% dilution is needed to complete the job.   The pesticide label indicates 1.33 fl.oz. of concentrate are required to make one gallon of 0.5% dilution.  How much pesticide concentrate needs to be added to the existing mix in the spray tank to have a 0.5 percent dilution in the finished mix of 25 gallons?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1371','41','71','The type of pesticide that kills by disrupting the waxy outer coating on the insect’s cuticle is called a __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1372','41','71','The type of pesticide whose vapors enter the pest’s body via inhalation is called a ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1373','41','71','The type of pesticide that must be ingested to kill is called a __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1374','41','71','Of the following pesticides groups, for which is the primary toxic action inhibition of cholinesterase?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1375','41','71','The only known vector of the causal agents of yellow fever is __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1376','41','71','Mosquito larvae are characterized by all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1377','41','71','An effective mosquito management program cannot be planned until _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1378','41','71','All of the following are readily evident  signs of rodent infestation, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1379','41','71','The most important aspect of a successful bird baiting program is __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1380','41','71','Insects whose growth is by a series of successive molts ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1381','41','71','Insects whose young emerge from the egg and have an entirely different form, usually live in different situations, and feed on different foods than the adults have a(n) __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1382','41','71','Insects whose young resemble the adults in the general form of their body, in their manner of living, and in their food preferences have a(n) ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1383','41','71','Insects whose young are known as naiads, have a different body structure and a completely different mode of life than the adults have ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1384','41','71','The primary vector of Lyme Disease in the United States is the ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1385','41','71','The first step in managing scorpions around dwellings is to ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1386','41','71','The use of total release aerosol products requires calculation of ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1387','41','71','A sprayer delivers 32 ounces of water over 250 sq.ft.  The label recommends that 12 fl.oz. of pesticide concentrate be mixed in 10 gallons of water and applied at a rate of 1 gallon /1000 sq.ft.  If the sprayer capacity is three gallons what is the volume of finished spray per 1000 sq.ft. of area sprayed?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1388','41','71','How many fl.oz. of pesticide concentrate must be added to fill a 3 gallon tank if the label recommends 12 oz. of pesticide/10 gallons of water?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1389','41','71','All of the following are required in order to calculate how much pesticide and diluent to combine to achieve the correct amount of finished spray mixture in your application equipment, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1390','41','71','Employees who answer general questions and prescribe treatments must __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1391','41','71','Cockroaches, ants and beetles have ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1392','41','71','The three forms of castes of ants found within a colony are __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1393','41','71','Power sprayer applications are most effective when using __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1394','41','71','The most effective step in any pest management program is __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1395','41','71','Flesh flies, blow flies and house flies have:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1396','41','71','[Refer to Level #1]  What is the maximum amount of this material that may be applied when performing a sewer treatment?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1397','41','71','[Refer to Level #1]  What is the recommended treatment method for application of this product in the kitchen area of a restaurant?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1398','41','71','[Refer to Level #1]  According to the label this pesticide has all of the following characteristics, except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1399','41','71','[Refer to Level #1]  According to the label this pesticide’s primary ingredient is ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1400','41','71','[Refer to Level #1]  According to the label storage of this pesticide requires all of the following, except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1401','41','71','[Refer to Level #2]  All of the following statements are accurate about this pesticide, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1402','41','71','[Refer to Level #2]  Mixing 2 packets of this pesticide with 1 gallon of water makes an active ingredient concentration of __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1403','41','71','[Refer to Level #2]  Empty packets should be_____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1404','41','71','[Refer to Level #2]  For indoor pest control this pesticide should be applied to all of the following areas, except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1405','41','71','[Refer to Level #2]  Use of this pesticide for treatment of imported red fire ants is limited to areas ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1406','41','71','[Refer to Level #2]  This product is best described as a ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1407','41','71','[Refer to Level #2]  This pesticide is labeled to control all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1408','41','71','[Refer to Level #3]  The required personal protective equipment for use of this pesticide during application includes ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1409','41','71','[Refer to Level #3]  The recommended concentration of active ingredient when treating for spiders is ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1410','41','71','[Refer to Level #3]  A pest control company has a contract with a hospital for pest control services.  During a routine monthly service call ants are found in the dining room.  The proper treatment location during business hours is to __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1411','41','71','[Refer to Level #3]  This pesticide is a __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1412','41','71','[Refer to Level #3]  For brush applications this pesticide must be mixed only with ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1413','41','71','[Refer to Level #3]  This pesticide may be used for ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1414','41','71','Likely filth-fly breeding locations in homes include all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1415','41','71','The ectoparasite with the most public health impact in Arizona is the ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1416','41','71','The disease with which reduviids are generally associated is __________','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1417','41','71','Which of the following taxonomic characteristics are apt to be important in mites?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1418','42','72','Although the head louse and the body louse are closely related in appearance, they differ in which of the following important characteristics?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1419','42','72','The potential for malaria in Arizona could be best described as ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1420','42','72','Pesticides which inhibit cholinesterase are the ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1421','42','72','Likely filth-fly breeding locations in homes include all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1422','42','72','The ectoparasite with the most public health impact in Arizona is the _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1423','42','72','The disease with which reduviids are generally associated is __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1424','42','72','Many Arizona city sewers are infested with the ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1425','42','72','Which of the following taxonomic characteristics are apt to be important in mites ___________?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1426','42','72','The tick that infests dogs in many Arizona cities is __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1427','42','72','Control of mosquitoes is most effectively accomplished by __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1428','42','72','Black fly larvae breed in ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1429','42','72','Bites from the Arizona Brown Spiders should be ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1430','42','72','The standard space sprayer and the Ultra Low Volume sprayer vary principally in ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1431','42','72','Although not all scorpions are considered deadly, they all have  each of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1432','42','72','Plague is a ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1433','42','72','Less pesticide is needed to control mosquitoes in the ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1434','42','72','Because of their size and color, mites are ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1435','42','72','Which of the following are considered “filth flies”?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1436','42','72','The best pesticide for use for lice control is a(n) ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1437','42','72','Two types of beetles commonly attacking milled grain areas are the ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1438','42','72','Head Lice and Crab Lice resemble each other most in that they _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1439','42','72','To assure proper calibration of ULV spray machines, the operator must determine all of the following, except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1440','42','72','The most practical wild rodent plague control technique is ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1441','42','72','Surveying breeding sites for houseflies, blackflies, and mosquitoes includes __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1442','42','72','With few exceptions diseased domestic rodents ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1443','42','72','Signs and symptoms of pesticide poisoning may include all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1444','42','72','The life cycle of a flea could best be described by which parameters?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1445','42','72','What life stages do flies have?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1446','42','72','A special permit to use a pesticide in variance with the label may be issued under a provision called ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1447','42','72','As vectors of pathogens in Arizona, mites are ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1448','42','72','Ticks may be broadly classified into which two groups?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1449','42','72','Mosquitoes are important in Arizona as ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1450','42','72','The lice most apt to infest children in Arizona are the ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1451','42','72','Ticks differ taxonomically from insects in ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1452','42','72','Larval source reduction of mosquitoes can be undertaken by using a(n) ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1453','42','72','In relation to feeding most fleas are ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1454','42','72','Mosquitoes are important vectors of ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1455','42','72','DDT is __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1456','42','72','The bloodsucking Reduviidae are all ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1457','42','72','The length of a particular stage of development is generally dependent on ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1458','42','72','Domestic Rat behavior is influenced by ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1459','42','72','The best spraying conditions for mosquito adulticiding are ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1460','42','72','Mites usually ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1461','42','72','To pinpoint likely breeding places for filth flies, an investigator should inspect all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1462','42','72','Before purchasing or selecting a pesticide from inventory ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1463','42','72','Who is responsible for acts, omission and compliance with law and other lawful Orders of the Structural Pest Control Commission?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1464','42','72','Chronic toxicity __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1465','42','72','The active ingredient of a pesticide is the ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1466','42','72','Competence in pest control includes ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1467','42','72','The best way to keep from contaminating groundwater is to ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1468','42','72','Which pesticide-handling activity poses a threat to groundwater?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1469','42','72','How many fluid ounces of insecticide concentrate are needed per gallon of water if the label recommends 12 ounces of insecticide concentrate per 10 gallons of water?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1470','42','72','How many fluid ounces of insecticide concentrate must be added to fill a three-gallon tank of water if the label recommends 12 ounces of insecticide per 10 gallons of water?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1471','42','72','The information needed before calculating how much pesticide and diluent to combine to achieve the correct amount of finished spray includes all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1472','42','72','Each service vehicle must be provided with ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1473','42','72','Integrated Pest Management tactics include all of the following, except ___________','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1474','42','72','The pesticide label gives instructions on _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1475','42','72','The Material Safety Data Sheet (MSDS) includes information on _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1476','42','72','An applicator should read the pesticide label __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1477','42','72','The choice of pesticide application procedures should all of the following factors, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1478','42','72','A sprayer delivers 32 ounces of liquid over 250 square feet.  The label recommends that 12 fluid ounces of insecticide concentrate be mixed in 10 gallons of water and applied as a spray at the rate of 1 gallon per 1000 square feet.  The sprayer capacity is three gallons.  What is the volume in gallons of finished spray per 1000 square feet of area sprayed?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1479','42','72','Pesticide applications for periodic pest control may harm non-target organisms that are present by all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1480','42','72','Public schools must be notified at least _______ hours in advance of any pesticide application.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1481','42','72','When applying pesticides the label requires an applicator to do all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1482','42','72','Calibration means ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1483','42','72','[VECTOBAC 12AF] Empty containers should be____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1484','42','72','[VECTOBAC 12AF] The International Toxic Units for this product is equal to _____ billion units per gallon.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1485','42','72','[VECTOBAC 12AF] For treatment of mosquito larvae in sewage ponds a maximum label-specified amount of this product is ________ pints per acre.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1486','42','72','[VECTOBAC 12AF] This product is best described as a ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1487','42','72','[VECTOBAC 12AF] According to the label this pesticide’s primary active ingredient is ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1488','42','72','According to the label storage of this pesticide requires all of the following, except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1489','42','72','After mixing, this pesticide should be used within ________ hours.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1490','42','72','Filth flies such as the house fly ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1491','42','72','Flea mouthparts are adapted for ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1492','42','72','Female lice produce eggs __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1493','42','72','Mosquitoes are closely related to __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1494','42','72','Aedes mosquitoes are known to have a range of __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1495','42','72','The most common cockroach infesting commercial kitchens in Arizona  is the ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1496','42','72','An area is inflicted by a severe biting-insect problem. It has been raining for about two weeks.  The biting is more severe during the day than at night.  The insects are most likely ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1497','42','72','One reason that wild rodents are hard to control with anticoagulants is ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1498','43','73','Each label must show all of the following, except _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1499','43','73','(Toxicity) x (exposure) equals ______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1500','43','73','Pesticide runoff effects all of the following, except _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1501','43','73','It is safe to enter an area recently treated with pesticide _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1502','43','73','Plants in the landscape are susceptible to injury from all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1503','43','73','Use of chemigation through a sprinkler system may result in well contamination from _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1504','43','73','Which type of application is distributed uniformly over an area?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1505','43','73','What type of application saturates the soil?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1506','43','73','Which type of application is made to a small area?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1507','43','73','Which of the following is used to describe the loss of large amounts of pesticides from the foliage into the air?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1508','43','73','What type of application is typically made to the bare ground?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1509','43','73','What type of application is made to leaves?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1510','43','73','When applying a pesticide plants should typically be ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1511','43','73','Which of the following affects uniform spray coverage?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1512','43','73','In addition to ground speed, sprayer pressure, and nozzle type, what must be considered when calibrating spray equipment?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1513','43','73','The directions for use on a pesticide label will __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1514','43','73','Hollow cone nozzles are used _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1515','43','73','Selection of the correct spray equipment nozzle is important because ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1516','43','73','Which application device creates droplets so fine that they do not stick to surfaces?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1517','43','73','Which application device works best for weed spot treatments on residential properties?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1518','43','73','Which two spray nozzles are best for penetrating dense foliage?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1519','43','73','__________ spreaders are more sensitive to ground speed than __________ spreaders for accuracy.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1520','43','73','If a golf green is round and the diameter is 30 yards, what is the area in square feet?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1521','43','73','If a lawn is 50 ft. long by 40 ft. wide and needs 3 oz. of pesticide per 1000 sq.ft., how much pesticide is needed in total?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1522','43','73','What sap-sucking insect covers itself with a hard shell-like material and feeds on grass roots in the soil?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1523','43','73','This very small, sap-sucking organism is not an insect.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1524','43','73','What insect larva causes injury by chewing at the base of plants?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1525','43','73','The larva of this insect feeds and tunnels inside of grass stems.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1526','43','73','What is the most likely cause of yellowed, dying leaves on indoor plants with webbing near the growing points?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1527','43','73','Small piles of soil on a putting green in the summer is probably caused by','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1528','43','73','White grubs are the larva of','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1529','43','73','Which of the following is a particular problem on St. Augustine grass in Arizona?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1530','43','73','Which of the following is a root feeding insect?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1531','43','73','Ground pearl, a scale insect with a pearly white waxy coat, primarily feeds on ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1532','43','73','Insects are invertebrates that have (an) _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1533','43','73','The C-shaped larva that feed on grass roots are called ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1534','43','73','Which of the following is a likely indicator that turf damage is being caused by insects?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1535','43','73','Which of the following is not a sign of grub infestation on the golf course?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1536','43','73','Which of the following is an above ground insect?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1537','43','73','Aphids and mites are considered __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1538','43','73','Which of these is a characteristic of Aphids?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1539','43','73','Which of the following does not produce a sticky honeydew as a result of feeding on plant fluids?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1540','43','73','Identify the insect in this photo ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1541','43','73','Identify the insect in this photo ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1542','43','73','Identify the insect in this photo ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1543','43','73','Identify the insect in this photo ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1544','43','73','Identify the insect in this photo ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1545','43','73','Identify the insect in this photo ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1546','43','73','Identify the insect in this photo ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1547','43','73','Identify the insect in this photo ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1548','43','73','Identify the insect in this photo ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1549','43','73','Identify the insect in this photo ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1550','43','73','Identify the insect in this photo ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1551','43','73','Identify the insect in this photo ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1552','43','73','Identify the insect in this photo ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1553','43','73','What type of organism causes mosaic diseases?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1554','43','73','What type of organism causes root knot?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1555','43','73','What turf disease is very destructive during cool weather on shaded winter grasses?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1556','43','73','What type of organism causes bud rot of palm, fusarium blight, and sooty canker?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1557','43','73','What type of organism causes fireblight and crowngall?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1558','43','73','The disease triangle consists of all of the following, except ______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1559','43','73','Crown gall is caused by _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1560','43','73','Which of the following is a troublesome pest of olive trees in Arizona?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1561','43','73','Which of the following does not increase the severity of fungal diseases?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1562','43','73','Anthracnose is a common disease of ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1563','43','73','Cankers and fire blight infect what parts of trees?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1564','43','73','Which of the following is not considered a cultural plant disease management technique?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1565','43','73','In general, what plant growth stage are herbicides most effective on?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1566','43','73','Which of the following is not considered a cultural disease management technique?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1567','43','73','Managing pest populations successfully requires ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1568','43','73','Which of the following is a form of biological control?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1569','43','73','Which of the following is not a component of Integrated Pest Management?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1570','43','73','Fungal diseases are generally more severe when turf is watered at ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1571','43','73','Contact herbicides kill ___________________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1572','43','73','A product that alters normal plant or insect processes is called a(n) ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1573','43','73','EC, S, F, and A are abbreviations for ______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1574','43','73','Systemic chemicals control target pests for a longer period of time compared to contact chemicals because _______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1575','43','73','Granular pesticides are usually mixed with _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1576','43','73','This type of organism causes mosaic diseases ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1577','43','73','This turf disease is responsible for most of the lawn and greens problems in the lower elevations of Arizona.  Large patches die slowly.  Water stress is an important factor.  This disease is called ______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1578','44','74','The pesticide label refers to the ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1579','44','74','Which of the following is not a signal word found on a pesticide label?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1580','44','74','The directions for use on a pesticide label disclose ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1581','44','74','The common name of a pesticide is the ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1582','44','74','Each pesticide label must have all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1583','44','74','Pesticide runoff affects all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1584','44','74','It is safe to enter a recently treated area ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1585','44','74','Which of the following is not a factor when determining whether a pesticide is likely to reach groundwater when applied in a turf and ornamental setting?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1586','44','74','A chronic health effect ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1587','44','74','The greatest exposure hazard occurs during ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1588','44','74','All of the following affect uniform spray coverage, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1589','44','74','Which type of application is made to a small area?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1590','44','74','In chemigation through a sprinkler system, well contamination can occur from  _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1591','44','74','Which type of application saturates the soil with liquid pesticide?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1592','44','74','All of the following impact nozzle selection, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1593','44','74','In cleaning spray equipment all of the following PPE is always required, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1594','44','74','Which application device works best for weed spot treatments on residential properties?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1595','44','74','Which of the following is not one of the common ways that pesticides may enter the human body during maintenance and cleaning of application equipment?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1596','44','74','In addition to ground speed, sprayer pressure, and nozzle type, what must be considered when calibrating spray equipment?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1597','44','74','All of the following times require equipment recalibration, except ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1598','44','74','Doubling the effective spray width decreases the volume applied per acre by __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1599','44','74','If a lawn is 50 ft. long by 40 ft. wide and needs 3 oz. of pesticide per 1000 sq.ft., how much pesticide is needed in total?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1600','44','74','The formula for calculating the area of a triangle is __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1601','44','74','To double the flow rate of a power sprayer','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1602','44','74','The area of a rectangle 100 ft. by 50 ft. is ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1603','44','74','All of the following are distinguishing characteristics of adult insects, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1604','44','74','Ground pearl primarily feeds on ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1605','44','74','An insect has an ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1606','44','74','The nymphs resemble the adults in this type of metamorphosis.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1607','44','74','The insect in the photo is a(n) ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1608','44','74','The insect in the photo is a(n) ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1609','44','74','The insect in the photo is a(n) ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1610','44','74','The insect in the photo is a(n) ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1611','44','74','The insect in the photo is a(n) ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1612','44','74','The insect in the photo is a(n) ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1613','44','74','The disease triangle consists of all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1614','44','74','Which of the following environmental factors does not increase the severity of fungal diseases?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1615','44','74','Most ornamental plant diseases are caused by ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1616','44','74','Endophytes are __________ that live in turfgrasses and make plant tissue toxic to feeding insects.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1617','44','74','The disease in the photo is ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1618','44','74','The disease in the photo is ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1619','44','74','The disease in the photo is ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1620','44','74','A major barrier to foliar uptake is ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1621','44','74','Knowledge of a pest’s life cycle is essential for all of the following reasons, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1622','44','74','Which of the following is not considered a cultural plant disease management technique?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1623','44','74','Managing pest populations successfully requires ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1624','44','74','Adding a(n) ___________ improves the physical characteristics of a pesticide.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1625','44','74','Managing a plant to minimize stress will ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1626','44','74','Biological control of insects may employ ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1627','44','74','The best plan for disease control in turf is __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1628','44','74','A product that alters normal plant processes is called a(n) __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1629','44','74','Systemic pesticides control target pests for a longer period of time compared to contact pesticides because ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1630','44','74','What type of pesticide controls roundworms?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1631','44','74','What type of pesticide is absorbed through the leaves or roots making the plant to be toxic?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1632','44','74','The pesticide formulation most likely to injure plants is ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1633','44','74','The equipment used to apply pesticides varies with all of the following, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1634','44','74','The primary function of application equipment is to ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1635','44','74','The active ingredient of a pesticide ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1636','44','74','Professionalism in pest control includes all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1637','44','74','What is considered to be the most important part of a spraying system?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1638','44','74','The best way to keep from contaminating groundwater is to:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1639','44','74','All of the following activities pose a threat to groundwater, except __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1640','44','74','Inaccurate measurement of pesticides can lead to all of the following, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1641','44','74','Each service vehicle must be provided with:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1642','44','74','The pesticide label gives you instructions on ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1643','44','74','The Material Safety Data Sheet (MSDS) includes information on ___________.:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1644','44','74','Personal protective equipment __________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1645','44','74','Factors influencing pesticide movement offsite during application include _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1646','44','74','Public schools must be notified at least:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1647','44','74','The advance notice to public schools shall include','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1648','44','74','This turf disease is destructive during hot, humid weather.  Blackened leaf blades wither together and turn reddish brown ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1649','44','74','The C-shaped larva which feeds among grass roots is called ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1650','44','74','Which of the following organisms causes mosaic diseases?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1651','44','74','Which of the following is responsible for most of the lawn problems in the lower elevations of Arizona?  Large patches die slowly.  Water stress is an important factor.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1652','44','74','A pesticide which controls thrips is called a(n)  ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1653','44','74','A pesticide which controls roundworms is called a(n) _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1654','44','74','Which of the following is very destructive on winter grasses, especially in cool weather and in shady places?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1655','44','74','A pesticide which is absorbed by a plant and moved throughout the sap is called a ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1656','44','74','High organic matter soils require _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1657','44','74','Which type of application is uniformly distributed over an area?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1658','44','74','A pesticide which controls rust is called a(n) ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1659','44','74','On bent grasses which turf disease may appear as small, circular patches with well defined borders?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1660','44','74','A product which improves the physical characteristics of a pesticide is called a(n) _________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1661','44','74','Which of the following is not considered a cultural plant disease management technique?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1662','44','74','Which type of organism causes fireblight and crowngall?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1663','44','74','Which type of organism causes root knot?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1664','44','74','A product which causes death or injury to a plant is called a(n) _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1665','44','74','The larva of which insect feeds and tunnels inside of grass stems?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1666','44','74','A product which reduces water loss from plants is called a(n) ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1667','44','74','Contact herbicides are most effective on _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1668','44','74','This type of organism causes stubborn diseases _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1936','45','75','This term best describes a grass-like plant having one seed leaf.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1937','45','75','At low temperatures (40-50 degrees farenheit), most herbicides would be expected to _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1938','45','75','Nutsedge is best described as a(n)____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1939','45','75','A major barrier to foliar herbicide uptake is ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1940','45','75','_____________ is water that percolates downward through the root zone until it reaches the water table.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1941','45','75','Which term best describes a plant that is very undesirable or troublesome ?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1942','45','75','Which term best describes any plant-killing herbicide that affects only the parts of the plant the herbicide falls on?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1943','45','75','A weed is _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1944','45','75','Which of the following best describes a pesticide that kills most types of plants without regard to the kind of plant?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1945','45','75','An Olive tree is best describe as a(n)______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1946','45','75','Which term best describes a broadleaf plant having two seed leaves?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1947','45','75','A soil application which prevents the growth of all plants on a temporary or permanent basis best describes using a _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1948','45','75','Which term best describes a plant killing chemical that is absorbed by the plant and is moved throughout the sap of the plant?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1949','45','75','The environmental factor(s) which most often effect(s) weed development is/are ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1950','45','75','Which of the following best describes a plant that germinates in late summer, fall or winter and then produces seeds and dies the next spring or summer?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1951','45','75','Which of the following refers to the mixing of two or more chemicals which results in no undesirable effects.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1952','45','75','In order for plant disease to develop there must be a ____________  interaction between the host and the primary causal agent.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1953','45','75','What happens to an herbicide after it enters a plant and disrupts a process or structure ?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1954','45','75','Most spray programs use which of the following principles ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1955','45','75','Which of the following describes a plant that does NOT loose its leaves seasonally or all at once?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1956','45','75','Which term best describes a plant that germinates in the spring, produces seeds, and dies the next winter?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1957','45','75','Which term means the effect of a chemical that causes death or injury to plants?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1958','45','75','Applying a chemical to control weeds after seedlings break through the soil best describes using a _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1959','45','75','A pesticide which is taken in through the leaves or roots of a plant and cause the plant to be toxic to a pest is a ____________ pesticide.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1960','45','75','Bur Clover is best described as a(n) ______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1961','45','75','Crabgrass is best described as a(n)____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1962','45','75','Which seeds sprout in the fall and die with the heat of summer?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1963','45','75','Which term refers to a plant that is poisoned by moderate amounts of herbicide?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1964','45','75','Which term best describes a plant-killing chemical that kills only certain kinds of plants and not other plants?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1965','45','75','Which term is used to describe a perennial that loses its leaves seasonally, usually during the winter?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1966','45','75','Which term best describes any compound used to kill or inhibit the growth of plant life?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1967','45','75','Prostrate Spurge is best describe as a(n) ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1968','45','75','Malva is best described as a(n) ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1969','45','75','A Mulberry tree is best described as a(n) ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1970','45','75','A pesticide is harmful to plants when it is ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1971','45','75','The directions for use on a pesticide label explain ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1972','45','75','Applying a chemical at the time of planting or in established plant beds in order to kill weeds as they germinate best describes using a  ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1973','45','75','Dandelion is best described as a(n)___________. (841)','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1974','45','75','Which term is used to describe a plant that lives for more than two years?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1975','45','75','Applying a herbicide to soil after the soil has been prepared but before planting best describes using a ______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1976','45','75','Rainfall or irrigation is required to _______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1977','45','75','Which term is used to describe a plant that completes its life cycle in one season?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1978','45','75','Which term refers to an increase in toxicity when two or more chemicals are used?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1979','45','75','In a landscaped area, applying a weed killer that persists in the soil and kills plants as they germinate best describes using a ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1980','45','75','Which of the following is a form of biological control?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1981','45','75','When a plant is diseased, it has ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1982','45','75','Which term means an amount of chemical left in the soil after an application?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1983','45','75','Russian Thistle is best described as a(n)_____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1984','45','75','Which term is used to describe a plant that requires two growing seasons to complete its life cycle?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1985','45','75','If a recommendation for an herbicide application calls for 3 lb. of active ingredient per acre and you are using a 75 percent formulation (ai = 75%), the total amount of herbicide you would apply per acre would be:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1986','45','75','The best way to keep from contaminating groundwater is to ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1987','45','75','What is considered to be the most important part of a spraying system?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1988','45','75','Granular pesticides are usually mixed with ____________.:','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1989','45','75','A pesticide that alters normal plant processes is called a (n) ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1990','45','75','Which type of application is distributed uniformly over an area?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1991','45','75','This is a photo of _______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1992','45','75','This is a photo of _______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1993','45','75','This is a photo of _______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1994','45','75','This is a photo of _______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1995','45','75','This is a photo of _______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1996','45','75','This is a photo of _______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1997','45','75','This is a photo of _______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1998','45','75','This is a photo of _______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('1999','45','75','This is a photo of _______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('2000','45','75','This is a photo of _______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('2001','45','75','This is a photo of _______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('2002','45','75','This is a photo of _______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('2003','45','75','In general, what plant growth stage are herbicides most effective on?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('2004','45','75','Wax and cuticles of leaves ____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('2005','45','75','Understanding a pest’s life cycle is essential because _____________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('2006','45','75','Which of the following is not considered a cultural plant disease management technique?','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('2007','45','75','Managing pest populations successfully requires ______________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('2008','45','75','[ROUNDUP] The chemical name for the active ingredient in this product is ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('2009','45','75','[ROUNDUP] When treating Bermuda grass with runners of less than 6 inches in length, the maximum amount of active ingredient of this pesticide to be added to 40 gallons of water is __________ ounces.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('2010','45','75','[ROUNDUP] To control pigweed of over 24 inches in height, a _________ percent solution of this pesticide should be used.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('2011','45','75','[ROUNDUP] To reduce the potential for drift of this product all of the following should be done, except ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('2012','45','75','[PENDELUM] In case of skin exposure clothing should be removed and the area rinsed for a minimum of _________ minutes.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('2013','45','75','[PENDELUM]  This pesticide provides pre-emergence control of most ___________.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('2014','45','75','[PENDELUM]  The maximum amount of this pesticide’s concentrate that may be mixed for the control of 100 square feet of knotweed is _______ ounces.','1','0','',NULL,NULL,'Active');
INSERT INTO `questionnaires` (`uid`,`test_uid`,`category_uid`,`question`,`created_by`,`input_date`,`answer_description`,`note`,`note_ext`,`status`) VALUES ('2015','45','75','[PENDELUM]  Each pint of this pesticide contains approximately _______ pounds of its active ingredient?','1','0','',NULL,NULL,'Active');
/*!40000 ALTER TABLE `questionnaires` ENABLE KEYS */;


--
-- Create Table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE `sessions` (
  `session_id` varchar(127) COLLATE utf8_bin NOT NULL,
  `last_activity` int(10) unsigned NOT NULL,
  `data` text COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`session_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Data for Table `sessions`
--

/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` (`session_id`,`last_activity`,`data`) VALUES ('l0ef8d274j55m0ps5r91pg2077','1407924874','c2Vzc2lvbl9pZHxzOjI2OiJsMGVmOGQyNzRqNTVtMHBzNXI5MXBnMjA3NyI7dG90YWxfaGl0c3xpOjEyO19rZl9mbGFzaF98YTowOnt9dXNlcl9hZ2VudHxzOjEwMjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgNi4xKSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMzYuMC4xOTg1LjEyNSBTYWZhcmkvNTM3LjM2IjtpcF9hZGRyZXNzfHM6MTA6IjEuNTIuNy4yMTUiO2xhc3RfYWN0aXZpdHl8aToxNDA3OTI0ODc0O3Nlc3NfaGlzX2FkbWlufGE6Mjp7czo0OiJiYWNrIjtzOjI5OiJhZG1pbl9xdWVzdGlvbm5haXJlcy9lZGl0LzY0NSI7czo3OiJjdXJyZW50IjtzOjIwOiJhZG1pbl9xdWVzdGlvbm5haXJlcyI7fXNlc3NfYWRtaW5fbGFuZ3xzOjE6IjUiO3Nlc3NfYWRtaW58YTo0OntzOjI6ImlkIjtzOjE6IjEiO3M6NToibGV2ZWwiO3M6MToiMSI7czo4OiJ1c2VybmFtZSI7czo1OiJhZG1pbiI7czo1OiJlbWFpbCI7czoyMzoic29uYXRhQHRlY2hrbm93bGVkZ2Uudm4iO31wYWdlfGI6MDs=');
INSERT INTO `sessions` (`session_id`,`last_activity`,`data`) VALUES ('ana7hle2rribio84if4rekt7r1','1407948792','c2Vzc2lvbl9pZHxzOjI2OiJhbmE3aGxlMnJyaWJpbzg0aWY0cmVrdDdyMSI7dG90YWxfaGl0c3xpOjEwO19rZl9mbGFzaF98YTowOnt9dXNlcl9hZ2VudHxzOjEwOToiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgNi4zOyBXT1c2NCkgQXBwbGVXZWJLaXQvNTM3LjM2IChLSFRNTCwgbGlrZSBHZWNrbykgQ2hyb21lLzM1LjAuMTkxNi4xMTQgU2FmYXJpLzUzNy4zNiI7aXBfYWRkcmVzc3xzOjE0OiIxMDguMjAzLjUyLjE0MiI7bGFzdF9hY3Rpdml0eXxpOjE0MDc5NDg3OTE7c2Vzc19oaXNfYWRtaW58YToyOntzOjQ6ImJhY2siO3M6MTA6ImFkbWluX2hvbWUiO3M6NzoiY3VycmVudCI7czoyMDoiYWRtaW5fcXVlc3Rpb25uYWlyZXMiO31zZXNzX2FkbWluX2xhbmd8czoxOiI1IjtzZXNzX2FkbWlufGE6NDp7czoyOiJpZCI7aToxO3M6NToibGV2ZWwiO2k6MTtzOjg6InVzZXJuYW1lIjtzOjY6IkFLY29tcCI7czo1OiJlbWFpbCI7czoxNjoiaW5mb0BwZXN0ZXN0LmNvbSI7fXBhZ2V8YjowOw==');
INSERT INTO `sessions` (`session_id`,`last_activity`,`data`) VALUES ('5a93ghpnn2qgpjr43ls0mh00k7','1407972076','c2Vzc2lvbl9pZHxzOjI2OiI1YTkzZ2hwbm4ycWdwanI0M2xzMG1oMDBrNyI7dG90YWxfaGl0c3xpOjEzNTg7X2tmX2ZsYXNoX3xhOjE6e3M6MTE6InNlc3Nfc2VhcmNoIjtzOjM6Im5ldyI7fXVzZXJfYWdlbnR8czoxMDk6Ik1vemlsbGEvNS4wIChXaW5kb3dzIE5UIDYuMTsgV09XNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8zNS4wLjE5MTYuMTUzIFNhZmFyaS81MzcuMzYiO2lwX2FkZHJlc3N8czoxMjoiNjQuMjQ1LjMuMjE1IjtsYXN0X2FjdGl2aXR5fGk6MTQwNzk3MjA3NTtzZXNzX2hpc19hZG1pbnxhOjI6e3M6NDoiYmFjayI7czozMDoiYWRtaW5fcXVlc3Rpb25uYWlyZXMvZWRpdC8xMjMxIjtzOjc6ImN1cnJlbnQiO3M6MjA6ImFkbWluX3F1ZXN0aW9ubmFpcmVzIjt9c2Vzc19hZG1pbl9sYW5nfHM6MToiNSI7c2Vzc19hZG1pbnxhOjQ6e3M6MjoiaWQiO2k6MTtzOjU6ImxldmVsIjtpOjE7czo4OiJ1c2VybmFtZSI7czo2OiJBS2NvbXAiO3M6NToiZW1haWwiO3M6MTY6ImluZm9AcGVzdGVzdC5jb20iO31wYWdlfGI6MDtzZXNzX2hpc19jbGllbnR8YToyOntzOjQ6ImJhY2siO3M6NDoiaG9tZSI7czo3OiJjdXJyZW50IjtzOjQ6ImhvbWUiO31zZXNzX3NlYXJjaHxhOjU6e3M6Nzoia2V5d29yZCI7czowOiIiO3M6ODoiY3VyX3BhZ2UiO3M6MDoiIjtzOjQ6InRlc3QiO3M6MjoiMzkiO3M6ODoiY2F0ZWdvcnkiO3M6MDoiIjtzOjc6ImRpc3BsYXkiO3M6MzoiMTAwIjt9');
INSERT INTO `sessions` (`session_id`,`last_activity`,`data`) VALUES ('7vlb9olqkn44dfnuerbvi8gm52','1407974702','c2Vzc2lvbl9pZHxzOjI2OiI3dmxiOW9scWtuNDRkZm51ZXJidmk4Z201MiI7dG90YWxfaGl0c3xpOjE7X2tmX2ZsYXNoX3xhOjA6e311c2VyX2FnZW50fHM6MTA5OiJNb3ppbGxhLzUuMCAoV2luZG93cyBOVCA2LjM7IFdPVzY0KSBBcHBsZVdlYktpdC81MzcuMzYgKEtIVE1MLCBsaWtlIEdlY2tvKSBDaHJvbWUvMzUuMC4xOTE2LjExNCBTYWZhcmkvNTM3LjM2IjtpcF9hZGRyZXNzfHM6MTQ6IjY5LjEwNy4yMTAuMjUwIjtsYXN0X2FjdGl2aXR5fGk6MTQwNzk3NDcwMjtzZXNzX2hpc19jbGllbnR8YToyOntzOjQ6ImJhY2siO3M6NDoiaG9tZSI7czo3OiJjdXJyZW50IjtzOjQ6ImhvbWUiO30=');
INSERT INTO `sessions` (`session_id`,`last_activity`,`data`) VALUES ('uf779kn3tgssvvbnj6in9806s0','1407980700','c2Vzc2lvbl9pZHxzOjI2OiJ1Zjc3OWtuM3Rnc3N2dmJuajZpbjk4MDZzMCI7dG90YWxfaGl0c3xpOjU7X2tmX2ZsYXNoX3xhOjA6e311c2VyX2FnZW50fHM6MTAyOiJNb3ppbGxhLzUuMCAoV2luZG93cyBOVCA2LjEpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIENocm9tZS8zNi4wLjE5ODUuMTI1IFNhZmFyaS81MzcuMzYiO2lwX2FkZHJlc3N8czoxMDoiMS41Mi43LjIxNSI7bGFzdF9hY3Rpdml0eXxpOjE0MDc5ODA3MDA7c2Vzc19oaXNfYWRtaW58YToyOntzOjQ6ImJhY2siO3M6MTA6ImFkbWluX2hvbWUiO3M6NzoiY3VycmVudCI7czoyMDoiYWRtaW5fcXVlc3Rpb25uYWlyZXMiO31zZXNzX2FkbWluX2xhbmd8czoxOiI1IjtzZXNzX2FkbWlufGE6NDp7czoyOiJpZCI7czoxOiIxIjtzOjU6ImxldmVsIjtzOjE6IjEiO3M6ODoidXNlcm5hbWUiO3M6NToiYWRtaW4iO3M6NToiZW1haWwiO3M6MjM6InNvbmF0YUB0ZWNoa25vd2xlZGdlLnZuIjt9cGFnZXxiOjA7');
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;


--
-- Create Table `site`
--

DROP TABLE IF EXISTS `site`;
CREATE TABLE `site` (
  `site_id` tinyint(2) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(50) COLLATE utf8_bin NOT NULL,
  `site_address` varchar(50) COLLATE utf8_bin NOT NULL,
  `site_city` varchar(50) COLLATE utf8_bin NOT NULL,
  `site_state` varchar(50) COLLATE utf8_bin NOT NULL,
  `site_zipcode` varchar(50) COLLATE utf8_bin NOT NULL,
  `site_logo` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `site_logo_width` int(5) NOT NULL,
  `site_logo_height` int(5) NOT NULL,
  `site_phone` varchar(20) COLLATE utf8_bin NOT NULL,
  `site_fax` varchar(20) COLLATE utf8_bin DEFAULT NULL,
  `site_slogan` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `site_email` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `site_title` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `site_keyword` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `site_description` text COLLATE utf8_bin,
  `site_num_line` tinyint(4) DEFAULT NULL,
  `site_num_line2` tinyint(4) DEFAULT NULL,
  `site_lang_client` tinyint(5) NOT NULL,
  `site_lang_admin` tinyint(5) NOT NULL,
  `site_short_date` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `site_long_date` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `site_admin_theme` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `site_client_theme` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `site_df_sreg` tinyint(1) NOT NULL,
  `site_home_num_row` tinyint(5) NOT NULL DEFAULT '0',
  `site_home_num_col` tinyint(1) NOT NULL DEFAULT '2',
  `site_pertest` int(255) DEFAULT NULL,
  `site_testuid` int(11) NOT NULL,
  `site_cart` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`site_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Data for Table `site`
--

/*!40000 ALTER TABLE `site` DISABLE KEYS */;
INSERT INTO `site` (`site_id`,`site_name`,`site_address`,`site_city`,`site_state`,`site_zipcode`,`site_logo`,`site_logo_width`,`site_logo_height`,`site_phone`,`site_fax`,`site_slogan`,`site_email`,`site_title`,`site_keyword`,`site_description`,`site_num_line`,`site_num_line2`,`site_lang_client`,`site_lang_admin`,`site_short_date`,`site_long_date`,`site_admin_theme`,`site_client_theme`,`site_df_sreg`,`site_home_num_row`,`site_home_num_col`,`site_pertest`,`site_testuid`,`site_cart`) VALUES ('1','Pestest.com','','','','','13959726001394173037logo.png','340','340','1-408-434-1130','','Pass your state exam.','info@pestest.com','PesTesT','Pest Control License Test preparation, Pre test','','20','20','5','5','m/d/Y','F j, Y, g:i a','0','styleSIC','1','1','1','0','0','1');
/*!40000 ALTER TABLE `site` ENABLE KEYS */;


--
-- Create Table `temp_answer`
--

DROP TABLE IF EXISTS `temp_answer`;
CREATE TABLE `temp_answer` (
  `uid` int(11) NOT NULL,
  `answer_uid` int(11) DEFAULT NULL,
  `answer` text,
  `type` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `temp_answer`
--

/*!40000 ALTER TABLE `temp_answer` DISABLE KEYS */;
/*!40000 ALTER TABLE `temp_answer` ENABLE KEYS */;


--
-- Create Table `temp_questionnaires`
--

DROP TABLE IF EXISTS `temp_questionnaires`;
CREATE TABLE `temp_questionnaires` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `questionnaires_uid` int(11) DEFAULT NULL,
  `category_uid` int(11) NOT NULL,
  `question` text,
  `created_by` int(11) NOT NULL,
  `input_date` int(11) DEFAULT NULL,
  `answer_description` text,
  `note` text,
  `note_ext` text,
  `status` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Data for Table `temp_questionnaires`
--

/*!40000 ALTER TABLE `temp_questionnaires` DISABLE KEYS */;
/*!40000 ALTER TABLE `temp_questionnaires` ENABLE KEYS */;


--
-- Create Table `test`
--

DROP TABLE IF EXISTS `test`;
CREATE TABLE `test` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `test_title` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `test_description` text,
  `qty_question` int(11) NOT NULL,
  `date` int(11) NOT NULL,
  `type_time` int(11) NOT NULL COMMENT '1: up time,2: down time',
  `time_value` int(11) NOT NULL DEFAULT '0',
  `status` int(11) DEFAULT NULL,
  `pass_score` int(11) DEFAULT '0',
  `price` decimal(10,2) DEFAULT NULL,
  `questionpage` int(11) NOT NULL DEFAULT '10',
  `displayexplanation` enum('N','Y') NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=52 DEFAULT CHARSET=utf8;

--
-- Data for Table `test`
--

/*!40000 ALTER TABLE `test` DISABLE KEYS */;
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('42','Public Health Certification','','50','0','1','60','1','80','100.00','10','N');
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('43','Turf & Ornamental Certification','','50','0','1','60','1','80','100.00','10','N');
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('34','Aquatics Certification','','50','0','1','60','1','80','100.00','10','Y');
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('36','Core Certification','','50','0','1','60','1','80','100.00','10','N');
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('37','Core QP','','50','0','1','60','1','80','100.00','10','N');
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('38','Fumigation Certification','','50','0','1','60','1','80','100.00','10','N');
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('39','Fumigation QP','','50','0','1','60','1','80','100.00','10','N');
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('40','General Pest Certification','','50','0','1','60','1','80','100.00','10','N');
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('41','General Pest QP','','50','0','1','60','1','80','100.00','10','N');
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('44','Turf & Ornamental QP','','50','0','1','60','1','80','100.00','10','N');
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('45','Weed Certification','','50','0','1','60','1','80','100.00','10','N');
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('46','Weed QP','','50','0','1','60','1','80','100.00','10','N');
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('47','Wood Preservatives Certification','','50','0','1','60','1','80','100.00','10','N');
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('48','Wood-Destroying Insect Inspection Applicator','','50','0','1','60','1','80','100.00','10','N');
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('49','Wood-Destroying Insect Inspection QP','','50','0','1','60','1','80','100.00','10','N');
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('50','Wood-Destroying Organisms Certification','','50','0','1','60','1','80','100.00','10','N');
INSERT INTO `test` (`uid`,`test_title`,`test_description`,`qty_question`,`date`,`type_time`,`time_value`,`status`,`pass_score`,`price`,`questionpage`,`displayexplanation`) VALUES ('51','Wood-Destroying Organisms QP','','50','0','1','60','1','80','100.00','10','N');
/*!40000 ALTER TABLE `test` ENABLE KEYS */;


--
-- Create Table `testing`
--

DROP TABLE IF EXISTS `testing`;
CREATE TABLE `testing` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `parent_code` varchar(255) NOT NULL,
  `testing_code` varchar(45) DEFAULT NULL,
  `test_uid` int(11) NOT NULL,
  `member_uid` int(11) NOT NULL,
  `testing_date` int(11) DEFAULT NULL,
  `testing_type` varchar(45) DEFAULT NULL,
  `testing_score` int(11) DEFAULT NULL,
  `duration` int(11) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=1431 DEFAULT CHARSET=utf8;

--
-- Data for Table `testing`
--

/*!40000 ALTER TABLE `testing` DISABLE KEYS */;
/*!40000 ALTER TABLE `testing` ENABLE KEYS */;


--
-- Create Table `testing_category`
--

DROP TABLE IF EXISTS `testing_category`;
CREATE TABLE `testing_category` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `category` varchar(255) NOT NULL,
  `percentage` int(11) NOT NULL,
  `parent_code` varchar(255) NOT NULL,
  `testing_code` varchar(11) NOT NULL,
  `member_uid` int(11) NOT NULL,
  `test` int(11) NOT NULL,
  PRIMARY KEY (`uid`),
  KEY `member_uid` (`member_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Data for Table `testing_category`
--

/*!40000 ALTER TABLE `testing_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `testing_category` ENABLE KEYS */;


--
-- Create Table `testing_detail`
--

DROP TABLE IF EXISTS `testing_detail`;
CREATE TABLE `testing_detail` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `testing_code` varchar(45) NOT NULL,
  `questionnaires_uid` int(11) NOT NULL,
  `selected_answer` int(11) NOT NULL,
  `result` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=39455 DEFAULT CHARSET=utf8;

--
-- Data for Table `testing_detail`
--

/*!40000 ALTER TABLE `testing_detail` DISABLE KEYS */;
/*!40000 ALTER TABLE `testing_detail` ENABLE KEYS */;


--
-- Create Table `version`
--

DROP TABLE IF EXISTS `version`;
CREATE TABLE `version` (
  `version_id` tinyint(1) NOT NULL AUTO_INCREMENT,
  `app_name` varchar(20) COLLATE utf8_bin NOT NULL,
  `url_server_update` varchar(50) COLLATE utf8_bin NOT NULL,
  `xml_list_file` varchar(20) COLLATE utf8_bin NOT NULL,
  `cur_version` varchar(20) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`version_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Data for Table `version`
--

/*!40000 ALTER TABLE `version` DISABLE KEYS */;
INSERT INTO `version` (`version_id`,`app_name`,`url_server_update`,`xml_list_file`,`cur_version`) VALUES ('1','Pestest','','list_versions.xml','2.3');
/*!40000 ALTER TABLE `version` ENABLE KEYS */;

SET FOREIGN_KEY_CHECKS=1;
-- EOB

